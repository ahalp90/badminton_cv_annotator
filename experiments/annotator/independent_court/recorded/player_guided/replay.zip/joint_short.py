"""Private diagnostic: compare a fixed court across the three short-clip anchors."""
import argparse
from pathlib import Path

import cv2
import numpy as np

from experiments.annotator.independent_court import detector,evaluate,player_guided
from camera_diagnostic import net_segments
from fit_windows import read,write,choose_pairs
from refine_fits import refine


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--no-overlays',action='store_true')
    args=parser.parse_args()
    root=args.run
    source=read(root/'fits_short_all/results.json.gz')['records']
    lines={row['id']:np.asarray(row['segments_px']) for row in read(root/'lines_short/deeplsd_md_default.json.gz')['cases']}
    references=read(root/'references.json.gz')
    results=[]
    output=root/'joint_short'
    output.mkdir(exist_ok=True)
    settings=detector.Settings(wide_families=True,min_supported_lines=3)
    for window in read(root/'people_short/manifest.json.gz')['windows']:
        record=read(root/'people_short'/window['record'])
        size=tuple(record['dimensions'].values())
        scale=min(1,960/max(size))
        working_size=tuple(round(value*scale) for value in size)
        native_scale=np.array(size)/working_size
        pair=choose_pairs(record)['central']
        if pair is None:
            raise RuntimeError('short-window diagnostic requires a persistent pair')
        inputs=[]
        all_segments=[]
        for anchor in record['anchor_images']:
            image_id=f"{record['id']}_frame_{anchor['frame_index']}"
            segments=lines[image_id]
            families=detector._wide_line_families(segments/np.tile(native_scale,2))
            merged=tuple(detector._merge_lines(family,settings) for family in families)
            maps=detector._distance_maps(families,working_size)
            all_maps=detector._distance_maps((segments/np.tile(native_scale,2),)*2,working_size)
            inputs.append((maps,merged,all_maps))
            all_segments.append(segments)
        pooled=np.concatenate(all_segments)
        candidates=[]
        for row in source:
            if row['window']!=record['id'] or row['id'].endswith('_median'):
                continue
            for rank,candidate in enumerate(row['candidates']):
                corners=np.asarray(candidate['corners_px'])
                if any(np.linalg.norm(corners-np.asarray(previous['corners_px']),axis=1).max()<12
                       for previous in candidates):
                    continue
                candidates.append({**candidate,'source_image':row['id'],'source_rank':rank})
        for stage in ['floor_only','initial','refined']:
            scored=[]
            for candidate in candidates:
                corners=np.asarray(candidate['corners_px'])
                if stage=='refined':
                    corners,_=refine(corners,pooled,size)
                transform=cv2.getPerspectiveTransform(detector.CORNER_COURT_M,(corners/native_scale).astype(np.float32))
                native_transform=cv2.getPerspectiveTransform(detector.CORNER_COURT_M,corners.astype(np.float32))
                one,two=player_guided.player_fractions(native_transform[None],pair['feet'])
                if one[0]<1 or two[0]<.5:
                    continue
                net,error,focal=net_segments(corners,size)
                net_points,visible=detector._visible_samples((net/native_scale)[None],working_size,48)
                x=np.clip(net_points[...,0],0,working_size[0]-1).astype(int)
                y=np.clip(net_points[...,1],0,working_size[1]-1).astype(int)
                floor_scores=[]
                net_scores=[]
                for maps,merged,all_maps in inputs:
                    _,scores,_,_=detector._score(transform[None],maps,settings,merged)
                    floor_scores.append(float(scores[0]) if len(scores) else -1.)
                    distances=all_maps[0,y,x]
                    support=np.exp(-.5*(distances/4.)**2).mean(axis=-1)*visible
                    net_scores.append(float(support.sum()/max(visible.sum(),1)))
                floor_score=float(np.median(floor_scores))
                if floor_score<0:
                    continue
                net_score=float(np.median(net_scores))
                score=floor_score if stage=='floor_only' else (3*floor_score+net_score)/4
                metrics={key:evaluate._metrics(corners,ref,*size) for key,ref in references[record['id']].items()}
                scored.append({'corners_px':corners.tolist(),'score':score,'floor_scores':floor_scores,
                               'net_scores':net_scores,'camera_error':error,'metrics':metrics,
                               'source_image':candidate['source_image'],'source_rank':candidate['source_rank']})
            scored.sort(key=lambda candidate:-candidate['score'])
            results.append({'window':record['id'],'stage':stage,'candidates':scored})
            top=scored[0]
            print(record['id'],stage,'max',max(m['corner_max_error_px'] for m in top['metrics'].values()),
                  'source',top['source_image'],top['source_rank'],flush=True)
            if not args.no_overlays:
                image=cv2.imread(str(root/'people_short'/record['anchor_images'][1]['image']))
                key=str(record['anchor_images'][1]['frame_index'])
                evaluate._overlay(image,np.asarray(top['corners_px']),references[record['id']][key],
                                  output/f"{record['id']}__{stage}.jpg")
    write(output/'results.json.gz',{'records':results})


if __name__=='__main__':
    main()
