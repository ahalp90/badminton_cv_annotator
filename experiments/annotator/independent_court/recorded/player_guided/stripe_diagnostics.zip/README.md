# Stripe evidence replay

The report is `stripes.md` in the published `player_guided` directory. The
separate `stripe_results.json.gz` holds the frozen four-way scoring comparison.
All accuracy values use worst-corner error at 1280×720, with a 15-pixel cutoff.
The twenty frames are development data. No automatic acceptance rule is tested.

From the repository root, with this archive extracted to `/tmp/court-stripe-replay`:

```bash
PYTHONPATH=src:. python /tmp/court-stripe-replay/replay_stripes.py \
  --recorded experiments/annotator/independent_court/recorded/player_guided \
  --output /tmp/court-stripe-replay/fresh
```

This reruns stripe scores, junction observations, junction selection, fixed
refits, and selection with renewed evidence. It extracts unchanged helper
scripts from `marking_refit_replay.zip` to the output's `legacy/` directory.
NumPy, OpenCV and SciPy are required; no video inference or accelerator is used.
The stages take several minutes on a CPU. Saved timing values can differ.

`fixed_refit_v1.json.gz` is the first completed run. Version 2 changes exact
optimiser-state reuse: 1,364 requests become 1,090 unique states. Every fit result
entry is identical across versions. `refit_selection_v2.json.gz` is the completed
renewed-evidence run. The first attempt stopped at an exact net-score control
before producing an output; restoring the archived OpenCV thread count fixed it.

The following diagnostics read labels after the frozen comparisons. They do
not insert reference courts into the selector:

```bash
PYTHONPATH=src:. python /tmp/court-stripe-replay/reference_probe.py \
  --replay experiments/annotator/independent_court/recorded/player_guided/marking_refit_replay.zip \
  --legacy-dir /tmp/court-stripe-replay/fresh/legacy \
  --output /tmp/court-stripe-replay/reference_probe_fresh.json.gz

PYTHONPATH=src:. python /tmp/court-stripe-replay/check_refit_deltas.py \
  --replay experiments/annotator/independent_court/recorded/player_guided/marking_refit_replay.zip \
  --refits /tmp/court-stripe-replay/fixed_refit_v2.json.gz \
  --stripes experiments/annotator/independent_court/recorded/player_guided/stripe_results.json.gz \
  --output /tmp/court-stripe-replay/refit_deltas_fresh.json.gz
```

`refit_deltas.json.gz` retains paired corner and visible-landmark error changes,
plus ten strict-tolerance solver checks sampled from unique states with seed
20260909. `error_decomposition.json.gz` distinguishes visible and off-screen
reference corners for the selected junction fits.

`proposal_trace/full_trace_v2.json.gz` records four unchanged proposal runs.
Version 2 corrects instrumentation metadata from the completed run: native-pixel
errors become 1280×720 errors, and final player-validation calls are separated
from generated proposals. The correction evidence is embedded in that result.
The trace reports stage minima using labels; it does not rank with them.
A fresh four-case trace takes about ten minutes on the original CPU:

```bash
PYTHONPATH=src:. python /tmp/court-stripe-replay/proposal_trace/trace_proposals.py \
  --replay experiments/annotator/independent_court/recorded/player_guided/marking_refit_replay.zip \
  --legacy-dir /tmp/court-stripe-replay/fresh/legacy \
  --output /tmp/court-stripe-replay/proposals_fresh.json.gz \
  --execution /tmp/court-stripe-replay/proposals_execution.json.gz
```

`best_rejected_probe.json.gz` separately rescores the 8.75-pixel amateur 2
proposal through the archived evidence function.

The two plotting scripts in `figure/` accept explicit input/output paths; use
`--help` for their arguments. `am3_frame_17174.png` is the native source image
for the floor-texture counterexample. The yellow plot uses packed raw segments.
`frozen_replay_checks.json.gz` records the full frozen comparison check. Its
input locations are expressed as public filenames; measurements are unchanged.
