"""Label-guided reference-geometry probe; never inserts a reference into a ranking."""
from __future__ import annotations

import argparse
import gzip
import importlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np

from experiments.annotator.independent_court import junction_observations as junctions
from experiments.annotator.independent_court import stripe_observations as stripes
from experiments.annotator.independent_court.assignment import prepare_observations
from experiments.annotator.independent_court.detector import CORNER_COURT_M
from experiments.annotator.independent_court.run_assignment import read_replay


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replay', type=Path, required=True)
    parser.add_argument('--legacy-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.legacy_dir.resolve()))
    legacy = importlib.import_module('run_alignment')
    cv2.setNumThreads(1)
    inputs, _ = read_replay(args.replay)
    records = []
    for case in inputs['cases']:
        corners = np.asarray(inputs['references'][case['id']]['corners_px'])
        construction = next((candidate for candidate in case['candidates'] if not candidate['extra_gallery_probe']),
                            {'source_variant': 'all_people_net'})
        prepared = legacy.prepare_case(case)
        observed = legacy.evidence(corners, case, prepared, construction)
        scale, size = prepared['native_scale'], prepared['size']
        observations = prepare_observations(prepared['segments'], size)
        homography = cv2.getPerspectiveTransform(CORNER_COURT_M, (corners / scale).astype(np.float32))
        stripe = stripes.score_model(stripes.measure(homography, observations, size),
                                     stripes.fragment_weights(observations), 3)
        sites = junctions.measure(homography, observations, prepared['boxes'], size)
        eligible = bool(observed['eligible'] and observed['scheme_eligible']['original'])
        score = None if 'net_score' not in observed else (3 * stripe['exclusive']['score'] + observed['net_score']) / 4
        records.append({'id': case['id'], 'corners_px': corners.tolist(), 'eligible': eligible,
                        'source_variant': construction['source_variant'], 'gate_evidence': observed,
                        'stripe': stripe, 'stripe_score': score, 'junctions': sites})
        print(case['id'], 'eligible', eligible, 'floor', observed.get('old_floor_score'),
              'complete', sum(len(site['agreements']) == 2 for site in sites['sites']),
              'disagree', sites['disagreements'], flush=True)
    output = {'schema': 'reference-geometry-probe/1', 'label_guided': True,
              'added_to_candidate_pool': False, 'records': records}
    args.output.write_bytes(gzip.compress(json.dumps(output, allow_nan=False).encode(), mtime=0))


if __name__ == '__main__':
    main()
