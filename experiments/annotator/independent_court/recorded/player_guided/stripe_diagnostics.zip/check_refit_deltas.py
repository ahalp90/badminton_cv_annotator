"""Summarise paired refit errors and check ten unique states with tighter solver tolerances."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Any

import numpy as np

from experiments.annotator.independent_court import fixed_stripe_refit as fitting
from experiments.annotator.independent_court.assignment import prepare_observations
from experiments.annotator.independent_court.run_assignment import read_replay


def read(path: Path) -> dict:
    return json.loads(gzip.decompress(path.read_bytes()))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replay', type=Path, required=True)
    parser.add_argument('--refits', type=Path, required=True)
    parser.add_argument('--stripes', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    inputs, _ = read_replay(args.replay)
    cases = {case['id']: case for case in inputs['cases']}
    frozen = {case['id']: case for case in read(args.stripes)['records']}
    records = read(args.refits)['records']
    deltas = {'nominal_centre': [], 'fixed_position': []}
    unique, seen = [], set()
    for record in records:
        case = cases[record['id']]
        size = np.array(frozen[record['id']]['working_size'])
        native_size = np.array([case['dimensions']['width'], case['dimensions']['height']])
        scale = native_size / size
        metric_scale = np.array([1280, 720]) / native_size
        reference = np.asarray(inputs['references'][record['id']]['corners_px'])
        visible = ((reference >= 0) & (reference < native_size)).all(axis=1)
        for entry in record['entries']:
            before = np.linalg.norm((np.asarray(entry['corners_px']) - reference) * metric_scale, axis=1)
            initial = fitting.initial_parameters(np.asarray(entry['corners_px']) / scale, tuple(size))
            provenance = entry['fit_samples']
            parts = tuple(np.asarray(provenance[field]).tobytes() for field in
                          ('fragment_ids', 'sample_ids', 'intervals', 'positions'))
            for model, model_deltas in deltas.items():
                fit = entry['fits'][model]
                after = np.linalg.norm((np.asarray(fit['corners_px']) - reference) * metric_scale, axis=1)
                model_deltas.append({'case': record['id'], 'id': entry['id'],
                                     'landmark_rms_delta': fit['metrics']['landmark_rms_px'] - entry['metrics']['landmark_rms_px'],
                                     'corner_error_deltas': (after - before).tolist(),
                                     'reference_corner_visible': visible.tolist()})
                key = (record['id'], model, initial.tobytes(), *parts)
                if key not in seen:
                    seen.add(key)
                    unique.append((record['id'], entry, model))
    summary = {}
    for model, rows in deltas.items():
        rms = np.array([row['landmark_rms_delta'] for row in rows])
        summary[model] = {'entries': len(rows), 'landmark_improved': int((rms < 0).sum()),
                          'landmark_worsened': int((rms > 0).sum()), 'landmark_equal': int((rms == 0).sum()),
                          'median_landmark_rms_delta': float(np.median(rms))}
        for visibility, name in ((True, 'visible_corners'), (False, 'offscreen_corners')):
            values = []
            for row in rows:
                mask = np.asarray(row['reference_corner_visible']) == visibility
                values.extend(np.asarray(row['corner_error_deltas'])[mask])
            values = np.asarray(values)
            summary[model][name] = {'count': len(values), 'improved': int((values < 0).sum()),
                                    'worsened': int((values > 0).sum()), 'median_delta': float(np.median(values))}
    original_solver = fitting.least_squares

    def tighter_solver(*solver_args: Any, **kwargs: Any) -> Any:
        return original_solver(*solver_args, **kwargs, ftol=1e-12, xtol=1e-12, gtol=1e-12)

    fitting.least_squares = tighter_solver
    probes = []
    draws = np.random.default_rng(20260909).choice(len(unique), size=10, replace=False)
    for draw in draws:
        identifier, entry, model = unique[draw]
        case = cases[identifier]
        size = tuple(frozen[identifier]['working_size'])
        scale = np.array([case['dimensions']['width'] / size[0], case['dimensions']['height'] / size[1]])
        observations = prepare_observations(np.asarray(case['segments_px']) / np.tile(scale, 2), size)
        provenance = entry['fit_samples']
        indices = {int(value): index for index, value in enumerate(observations.fragment_ids)}
        points = np.asarray([observations.samples[indices[fragment], sample] for fragment, sample in
                             zip(provenance['fragment_ids'], provenance['sample_ids'])])
        constraints = fitting.Constraints(points, np.asarray(provenance['intervals']),
                                          np.asarray(provenance['positions']), np.asarray(provenance['weights']),
                                          np.asarray(provenance['fragment_ids']), np.asarray(provenance['sample_ids']))
        strict = fitting.refine(np.asarray(entry['corners_px']) / scale, constraints, size, model == 'fixed_position')
        ordinary = entry['fits'][model]
        change = (np.asarray(strict['corners_px']) * scale - np.asarray(ordinary['corners_px']))
        change *= np.array([1280 / case['dimensions']['width'], 720 / case['dimensions']['height']])
        probes.append({'draw': int(draw), 'case': identifier, 'id': entry['id'], 'model': model,
                       'maximum_corner_change_px': float(np.linalg.norm(change, axis=1).max()),
                       'default_objective': ordinary['objective_after'], 'strict_objective': strict['objective_after'],
                       'strict_status': strict['status'], 'strict_nfev': strict['nfev']})
    output = {'schema': 'paired-refit-error-and-convergence-check/1', 'seed': 20260909,
              'unique_population': len(unique), 'summary': summary, 'paired_deltas': deltas, 'strict_solver_probes': probes}
    args.output.write_bytes(gzip.compress(json.dumps(output, allow_nan=False).encode(), mtime=0))
    print(json.dumps(summary, indent=2))
    print('Maximum corner change with stricter tolerances:', max(row['maximum_corner_change_px'] for row in probes))
    print('Strict statuses:', [row['strict_status'] for row in probes])


if __name__ == '__main__':
    main()
