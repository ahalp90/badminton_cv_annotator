"""Recompute the numerical stripe, junction and fixed-refit comparisons from cached inputs."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from zipfile import ZipFile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--recorded', type=Path, required=True, help='Published player_guided evidence directory')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    recorded = args.recorded.resolve()
    replay = recorded / 'marking_refit_replay.zip'
    baseline = recorded / 'assignment_results.json.gz'
    legacy = output / 'legacy'
    legacy.mkdir(exist_ok=True)
    with ZipFile(replay) as archive:
        for name in archive.namelist():
            if name.endswith('.py'):
                if Path(name).name != name:
                    raise ValueError(f'Expected a top-level replay script: {name}')
                (legacy / name).write_bytes(archive.read(name))
    stripe = output / 'stripe_results.json.gz'
    junctions = output / 'junctions.json.gz'
    selection = output / 'junction_selection.json.gz'
    refits = output / 'fixed_refit.json.gz'
    renewed = output / 'refit_selection.json.gz'
    stages = [
        ('run_stripes', ['--replay', replay, '--baseline', baseline, '--output', stripe]),
        ('run_junctions', ['--replay', replay, '--stripes', stripe, '--output', junctions]),
        ('run_junction_selection', ['--stripes', stripe, '--junctions', junctions, '--output', selection]),
        ('run_fixed_refit', ['--replay', replay, '--stripes', stripe, '--selection', selection, '--output', refits]),
        ('run_refit_selection', ['--replay', replay, '--legacy-dir', legacy, '--stripes', stripe,
                                '--refits', refits, '--output', renewed]),
    ]
    for module, arguments in stages:
        command = [sys.executable, '-m', f'experiments.annotator.independent_court.{module}']
        subprocess.run(command + [str(argument) for argument in arguments], check=True)
    print(f'Numerical comparisons written to {output}')


if __name__ == '__main__':
    main()
