#!/usr/bin/env python3
"""Trace cached all-people proposal stages without changing their outputs."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import math
import sys
import time
import zipfile
from collections import defaultdict, deque
from collections.abc import Callable
from pathlib import Path
from typing import Any

import cv2
import numpy as np

PRIMARY_METRIC_SIZE = np.asarray([1280.0, 720.0])

CASE_IDS = (
    "am2_window_01_frame_28019",
    "am3_window_02_frame_17174",
    "am3_window_03_frame_24515",
    "am4_window_00_frame_0",
)


def read_gzip_json(path: Path) -> dict[str, Any]:
    with gzip.open(path, "rt", encoding="utf-8") as source:
        return json.load(source)


def write_gzip_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(value, allow_nan=False, separators=(",", ":")).encode("utf-8")
    path.write_bytes(gzip.compress(encoded, mtime=0))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalised_homography_key(homography: np.ndarray) -> bytes:
    normalised = np.asarray(homography, dtype=np.float64) / float(homography[2, 2])
    return np.ascontiguousarray(normalised).tobytes()


def corner_key(corners: np.ndarray) -> bytes:
    return np.ascontiguousarray(np.asarray(corners, dtype=np.float64)).tobytes()


def corner_error(
    corners_native: np.ndarray,
    reference: dict[str, Any],
    metric_scale: np.ndarray | None = None,
) -> dict[str, Any]:
    reference_corners = np.asarray(reference["corners_px"], dtype=np.float64)
    native_corners = np.asarray(corners_native, dtype=np.float64)
    native_errors = np.linalg.norm(native_corners - reference_corners, axis=1)
    scale = np.ones(2, dtype=np.float64) if metric_scale is None else np.asarray(metric_scale)
    metric_errors = np.linalg.norm((native_corners - reference_corners) * scale, axis=1)
    return {
        "corner_max_error_px": float(metric_errors.max()),
        "corner_mean_error_px": float(metric_errors.mean()),
        "corner_max_error_native_px": float(native_errors.max()),
        "corner_mean_error_native_px": float(native_errors.mean()),
        "corners_px": native_corners.tolist(),
    }


def best_hypothesis(
    homographies: np.ndarray,
    generation_indices: list[int],
    native_scale: np.ndarray,
    metric_scale: np.ndarray,
    reference: dict[str, Any],
    *,
    one_fraction: np.ndarray | None = None,
    two_fraction: np.ndarray | None = None,
    scores: np.ndarray | None = None,
    label: str,
    project_homographies: bool = True,
) -> dict[str, Any] | None:
    if not len(homographies):
        return None
    if project_homographies:
        corners_working, _ = TRACE_DETECTOR.project(homographies, TRACE_DETECTOR.CORNER_COURT_M)
    else:
        corners_working = np.asarray(homographies)
    corners_native = corners_working * native_scale
    errors = np.asarray([
        corner_error(corners, reference, metric_scale)["corner_max_error_px"] for corners in corners_native
    ])
    best_index = int(np.argmin(errors))
    result = {
        "stage": label,
        "generation_index": int(generation_indices[best_index]),
        **corner_error(corners_native[best_index], reference, metric_scale),
    }
    if one_fraction is not None:
        result["one_fraction"] = float(one_fraction[best_index])
    if two_fraction is not None:
        result["two_fraction"] = float(two_fraction[best_index])
    if scores is not None:
        result["score"] = float(scores[best_index])
    return result


def best_candidates(
    candidates: list[Any],
    native_scale: np.ndarray,
    metric_scale: np.ndarray,
    reference: dict[str, Any],
    provenance: dict[bytes, deque[int]],
    label: str,
) -> dict[str, Any] | None:
    if not candidates:
        return None
    rows = []
    for candidate_index, candidate in enumerate(candidates):
        corners_native = np.asarray(candidate.corners_px) * native_scale
        metrics = corner_error(corners_native, reference, metric_scale)
        source_indices = provenance.get(corner_key(candidate.corners_px), deque())
        rows.append({
            "candidate_index": candidate_index,
            "generation_index": None if not source_indices else int(source_indices[0]),
            "score": float(candidate.score),
            "stage": label,
            **metrics,
        })
    return min(rows, key=lambda row: row["corner_max_error_px"])


def recursive_differences(expected: Any, actual: Any, path: str = "") -> list[dict[str, Any]]:
    differences: list[dict[str, Any]] = []
    if type(expected) is not type(actual):
        return [{"path": path, "expected": expected, "actual": actual}]
    if isinstance(expected, dict):
        for key in sorted(set(expected) | set(actual)):
            child = f"{path}.{key}" if path else key
            if key not in expected or key not in actual:
                differences.append({"path": child, "expected": expected.get(key), "actual": actual.get(key)})
            else:
                differences.extend(recursive_differences(expected[key], actual[key], child))
        return differences
    if isinstance(expected, list):
        if len(expected) != len(actual):
            differences.append({"path": f"{path}.length", "expected": len(expected), "actual": len(actual)})
        for index, (expected_item, actual_item) in enumerate(zip(expected, actual)):
            differences.extend(recursive_differences(expected_item, actual_item, f"{path}[{index}]"))
        return differences
    if expected != actual:
        differences.append({"path": path, "expected": expected, "actual": actual})
    return differences


def trace_case(
    case: dict[str, Any],
    reference: dict[str, Any],
    expected_candidates: list[dict[str, Any]],
    zone_net: Any,
    detector: Any,
) -> dict[str, Any]:
    width, height = case["dimensions"]["width"], case["dimensions"]["height"]
    native_scale = np.asarray([width / 960, height / 540], dtype=np.float64)
    metric_scale = PRIMARY_METRIC_SIZE / np.asarray([width, height], dtype=np.float64)
    settings = detector.Settings(wide_families=True, min_supported_lines=3)
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    feet = np.asarray(case["all_feet_px"], dtype=np.float64)
    segments = np.asarray(case["segments_px"], dtype=np.float64)
    trace: dict[str, Any] = {
        "id": case["id"],
        "dimensions": case["dimensions"],
        "settings": {
            "wide_families": settings.wide_families,
            "min_supported_lines": settings.min_supported_lines,
            "max_rectangles": settings.max_rectangles,
            "max_dimension": settings.max_dimension,
            "template_transform_count": len(detector.TEMPLATE_TRANSFORMS),
        },
        "error_metric": {
            "width_px": int(PRIMARY_METRIC_SIZE[0]),
            "height_px": int(PRIMARY_METRIC_SIZE[1]),
            "native_to_metric_scale": metric_scale.tolist(),
        },
        "rectangle_count": None,
        "homographies": {
            "generated": 0,
            "unique": 0,
            "duplicates": 0,
            "budget": settings.max_rectangles * len(detector.TEMPLATE_TRANSFORMS),
        },
        "player_fractions": {
            "calls": 0,
            "generated": 0,
            "with_players": 0,
            "final_validation_calls": 0,
            "final_validation_with_players": 0,
            "final_validation_fractions": [],
            "best_generated": None,
            "best_with_players": None,
        },
        "score": {
            "calls": 0,
            "geometry_valid": 0,
            "nonnegative_floor_scores": 0,
            "best_geometry_valid": None,
            "best_nonnegative_floor": None,
            "validity_diagnostic_mismatches": [],
        },
        "retain": {
            "calls": 0,
            "incoming_post_camera_net": 0,
            "incoming_with_existing": 0,
            "best_before_retention": None,
            "calls_detail": [],
        },
        "final": {},
    }
    seen_homographies: set[bytes] = set()
    pending_score_indices: dict[bytes, deque[int]] = defaultdict(deque)
    corner_provenance: dict[bytes, deque[int]] = defaultdict(deque)
    generated_homographies: dict[bytes, deque[int]] = defaultdict(deque)

    original_player_fractions: Callable[..., tuple[np.ndarray, np.ndarray]] = zone_net.player_fractions
    original_score = detector._score
    original_retain = detector._retain
    original_rectangles = detector._image_rectangles

    def traced_rectangles(*args: Any, **kwargs: Any) -> np.ndarray:
        rectangles = original_rectangles(*args, **kwargs)
        trace["rectangle_count"] = len(rectangles)
        return rectangles

    def traced_player_fractions(
        homographies: np.ndarray, feet_px: np.ndarray, margin: float = 0.15,
    ) -> tuple[np.ndarray, np.ndarray]:
        one_fraction, two_fraction = original_player_fractions(homographies, feet_px, margin)
        player_trace = trace["player_fractions"]
        if len(homographies) < len(detector.TEMPLATE_TRANSFORMS):
            supported = (one_fraction == 1.0) & (two_fraction >= 0.5)
            player_trace["final_validation_calls"] += len(homographies)
            player_trace["final_validation_with_players"] += int(supported.sum())
            player_trace["final_validation_fractions"].extend(
                {
                    "one_fraction": float(one_fraction[index]),
                    "two_fraction": float(two_fraction[index]),
                    "with_players": bool(supported[index]),
                }
                for index in range(len(homographies))
            )
            return one_fraction, two_fraction
        start_index = trace["homographies"]["generated"]
        generation_indices = list(range(start_index, start_index + len(homographies)))
        for local_index, homography in enumerate(homographies):
            key = normalised_homography_key(homography)
            generation_index = generation_indices[local_index]
            trace["homographies"]["generated"] += 1
            generated_homographies[key].append(generation_index)
            if key in seen_homographies:
                trace["homographies"]["duplicates"] += 1
            else:
                seen_homographies.add(key)
                trace["homographies"]["unique"] += 1
        supported = (one_fraction == 1.0) & (two_fraction >= 0.5)
        selected_indices = np.flatnonzero(supported)
        pending_score_indices.clear()
        for local_index in selected_indices:
            key = normalised_homography_key(homographies[local_index])
            pending_score_indices[key].append(generation_indices[local_index])
        player_trace["calls"] += 1
        player_trace["generated"] += len(homographies)
        player_trace["with_players"] += int(supported.sum())
        player_trace["best_generated"] = _best_update(
            player_trace["best_generated"],
            best_hypothesis(
                homographies, generation_indices, native_scale, reference,
                metric_scale,
                one_fraction=one_fraction, two_fraction=two_fraction,
                label="player_fractions/generated",
            ),
        )
        player_trace["best_with_players"] = _best_update(
            player_trace["best_with_players"],
            best_hypothesis(
                homographies[supported], [generation_indices[index] for index in selected_indices],
                native_scale, metric_scale, reference, one_fraction=one_fraction[supported],
                two_fraction=two_fraction[supported], label="player_fractions/with_players",
            ),
        )
        return one_fraction, two_fraction

    def traced_score(*args: Any, **kwargs: Any) -> tuple[np.ndarray, ...]:
        homographies = np.asarray(args[0] if args else kwargs["homographies"])
        maps = args[1] if len(args) > 1 else kwargs["maps"]
        result = original_score(*args, **kwargs)
        corners, scores, _means, _counts = result
        generation_indices = []
        for homography in homographies:
            key = normalised_homography_key(homography)
            queue = pending_score_indices.get(key)
            if queue:
                generation_indices.append(queue.popleft())
            else:
                generation_indices.append(-1)
        width_working, height_working = maps.shape[2], maps.shape[1]
        projected, denominator = detector.project(homographies, detector.CORNER_COURT_M)
        valid = np.isfinite(projected).all(axis=(1, 2)) & np.all(denominator > 1e-6, axis=1)
        edges = np.roll(projected, -1, axis=1) - projected
        turns = edges[..., 0] * np.roll(edges[..., 1], -1, axis=1) - edges[..., 1] * np.roll(edges[..., 0], -1, axis=1)
        valid &= np.all(turns > 0, axis=1)
        visible_lower = np.maximum(projected.min(axis=1), 0)
        visible_upper = np.minimum(projected.max(axis=1), np.array([width_working, height_working]) - 1)
        valid &= np.all((visible_upper - visible_lower) / np.array([width_working, height_working]) >= settings.min_visible_span_fraction, axis=1)
        valid_indices = np.flatnonzero(valid)
        if len(valid_indices) != len(corners):
            trace["score"]["validity_diagnostic_mismatches"].append({
                "input_count": len(homographies),
                "replicated_valid_count": len(valid_indices),
                "returned_corner_count": len(corners),
            })
        score_trace = trace["score"]
        score_trace["calls"] += 1
        score_trace["geometry_valid"] += len(corners)
        nonnegative = scores >= 0
        score_trace["nonnegative_floor_scores"] += int(nonnegative.sum())
        returned_indices = [generation_indices[index] for index in valid_indices[:len(corners)]]
        for corner, generation_index in zip(corners, returned_indices):
            corner_provenance[corner_key(corner)].append(generation_index)
        score_trace["best_geometry_valid"] = _best_update(
            score_trace["best_geometry_valid"],
            best_hypothesis(
                corners, returned_indices, native_scale, metric_scale, reference, scores=scores,
                label="score/geometry_valid", project_homographies=False,
            ),
        )
        score_trace["best_nonnegative_floor"] = _best_update(
            score_trace["best_nonnegative_floor"],
            best_hypothesis(
                corners[nonnegative], [returned_indices[index] for index in np.flatnonzero(nonnegative)],
                native_scale, metric_scale, reference, scores=scores[nonnegative],
                label="score/nonnegative_floor", project_homographies=False,
            ),
        )
        return result

    def traced_retain(candidates: list[Any], proposed: list[Any], settings_arg: Any) -> list[Any]:
        retain_trace = trace["retain"]
        retain_trace["calls"] += 1
        retain_trace["incoming_post_camera_net"] += len(proposed)
        retain_trace["incoming_with_existing"] += len(candidates) + len(proposed)
        best = best_candidates(proposed, native_scale, metric_scale, reference, corner_provenance, "retain/proposed")
        retain_trace["best_before_retention"] = _best_update(retain_trace["best_before_retention"], best)
        retain_trace["calls_detail"].append({
            "existing_count": len(candidates),
            "proposed_count": len(proposed),
            "incoming_count": len(candidates) + len(proposed),
            "best_proposed": best,
        })
        return original_retain(candidates, proposed, settings_arg)

    def _best_update(current: dict[str, Any] | None, candidate: dict[str, Any] | None) -> dict[str, Any] | None:
        if candidate is None:
            return current
        if current is None or candidate["corner_max_error_px"] < current["corner_max_error_px"]:
            return candidate
        return current

    old_functions = (zone_net.player_fractions, detector._score, detector._retain, detector._image_rectangles)
    zone_net.player_fractions = traced_player_fractions
    detector._score = traced_score
    detector._retain = traced_retain
    detector._image_rectangles = traced_rectangles
    started = time.perf_counter()
    try:
        result = zone_net.detect(frame, feet, settings, segments_px=segments)
    finally:
        zone_net.player_fractions, detector._score, detector._retain, detector._image_rectangles = old_functions
    trace["elapsed_seconds"] = time.perf_counter() - started
    trace["homographies"]["within_budget"] = trace["homographies"]["generated"] <= trace["homographies"]["budget"]
    actual_candidates = [
        {
            "corners_px": np.asarray(candidate.corners_px).tolist(),
            "score": float(candidate.score),
            "family_support": list(candidate.family_support),
            "supported_lines": list(candidate.supported_lines),
            "oracle": corner_error(np.asarray(candidate.corners_px), reference, metric_scale),
        }
        for candidate in result.detection.candidates
    ]
    trace["final"] = {
        "accepted": result.detection.accepted,
        "reason": result.detection.reason,
        "gap": result.detection.score_gap,
        "count": len(actual_candidates),
        "best": None if not actual_candidates else min(actual_candidates, key=lambda row: row["oracle"]["corner_max_error_px"]),
        "candidates": actual_candidates,
    }
    trace["retain"]["best_final"] = trace["final"]["best"]
    expected = [
        {"corners_px": candidate["corners_px"], "score": candidate["original_score"]}
        for candidate in expected_candidates
    ]
    actual = [{"corners_px": row["corners_px"], "score": row["score"]} for row in actual_candidates]
    trace["comparison"] = {
        "expected_count": len(expected),
        "actual_count": len(actual),
        "exact_match": expected == actual,
        "differences": recursive_differences(expected, actual, "candidates"),
    }
    return trace


def load_zone_net(path: Path) -> tuple[Any, Any]:
    scratch_directory = str(path.parent)
    sys.path.insert(0, scratch_directory)
    try:
        import zone_net  # type: ignore[import-not-found]
    finally:
        sys.path.pop(0)
    from experiments.annotator.independent_court import detector

    return zone_net, detector


def generation_indices(value: Any) -> list[int]:
    if isinstance(value, dict):
        found = []
        if isinstance(value.get("generation_index"), int):
            found.append(value["generation_index"])
        for child in value.values():
            found.extend(generation_indices(child))
        return found
    if isinstance(value, list):
        found = []
        for child in value:
            found.extend(generation_indices(child))
        return found
    return []


def correct_error_metrics(value: Any, reference: dict[str, Any], metric_scale: np.ndarray) -> None:
    if isinstance(value, dict):
        if "corner_max_error_px" in value and "corners_px" in value:
            corrected = corner_error(np.asarray(value["corners_px"]), reference, metric_scale)
            value.update({
                "corner_max_error_px": corrected["corner_max_error_px"],
                "corner_mean_error_px": corrected["corner_mean_error_px"],
                "corner_max_error_native_px": corrected["corner_max_error_native_px"],
                "corner_mean_error_native_px": corrected["corner_mean_error_native_px"],
            })
        for child in value.values():
            correct_error_metrics(child, reference, metric_scale)
    elif isinstance(value, list):
        for child in value:
            correct_error_metrics(child, reference, metric_scale)


def correct_trace_v1(
    raw: dict[str, Any],
    packed: dict[str, Any],
    zone_net: Any,
    detector: Any,
) -> dict[str, Any]:
    corrected = copy.deepcopy(raw)
    corrected["schema"] = "cached-all-people-proposal-trace/2"
    cases = {case["id"]: case for case in packed["cases"]}
    correction_records = []
    for record in corrected["records"]:
        case = cases[record["id"]]
        reference = packed["references"][record["id"]]
        width, height = case["dimensions"]["width"], case["dimensions"]["height"]
        metric_scale = PRIMARY_METRIC_SIZE / np.asarray([width, height], dtype=np.float64)
        rectangle_count = int(record["rectangle_count"])
        transform_count = int(record["settings"]["template_transform_count"])
        corrected_generated = rectangle_count * transform_count
        raw_generated = int(record["homographies"]["generated"])
        final_count = int(record["final"]["count"])
        raw_player = record["player_fractions"]
        search_calls = math.ceil(rectangle_count / 8)
        if raw_generated - corrected_generated != final_count:
            raise ValueError(f"{record['id']}: raw generation tail is not final-count sized")
        if raw_player["calls"] - search_calls != final_count:
            raise ValueError(f"{record['id']}: raw player callback tail is not final-count sized")

        feet = np.asarray(case["all_feet_px"], dtype=np.float64)
        final_validation_fractions = []
        for candidate in record["final"]["candidates"]:
            corners = np.asarray(candidate["corners_px"], dtype=np.float32)
            transform = cv2.getPerspectiveTransform(detector.CORNER_COURT_M, corners)
            one_fraction, two_fraction = zone_net.player_fractions(transform[None], feet)
            one = float(one_fraction[0])
            two = float(two_fraction[0])
            final_validation_fractions.append({
                "one_fraction": one,
                "two_fraction": two,
                "with_players": bool(one == 1.0 and two >= 0.5),
            })
        final_validation_with_players = sum(
            item["with_players"] for item in final_validation_fractions
        )
        if raw_player["with_players"] - final_validation_with_players < 0:
            raise ValueError(f"{record['id']}: final callback support exceeds raw support")
        raw_unique = int(record["homographies"]["unique"])
        if raw_unique - corrected_generated != final_count:
            raise ValueError(f"{record['id']}: unique count cannot be corrected from raw keys")
        raw_final_payload = [
            {"corners_px": candidate["corners_px"], "score": candidate["score"]}
            for candidate in record["final"]["candidates"]
        ]
        indices = generation_indices(record["player_fractions"])
        indices.extend(generation_indices(record["score"]))
        indices.extend(generation_indices(record["retain"]))
        if indices and max(indices) >= corrected_generated:
            raise ValueError(f"{record['id']}: a retained best index is in the removed callback tail")

        record["error_metric"] = {
            "width_px": int(PRIMARY_METRIC_SIZE[0]),
            "height_px": int(PRIMARY_METRIC_SIZE[1]),
            "native_to_metric_scale": metric_scale.tolist(),
        }
        record["homographies"]["generated"] = corrected_generated
        record["homographies"]["unique"] = corrected_generated
        record["homographies"]["within_budget"] = corrected_generated <= record["homographies"]["budget"]
        raw_player["calls"] = search_calls
        raw_player["generated"] = corrected_generated
        raw_player["with_players"] -= final_validation_with_players
        raw_player["final_validation_calls"] = final_count
        raw_player["final_validation_with_players"] = final_validation_with_players
        raw_player["final_validation_fractions"] = final_validation_fractions
        correct_error_metrics(record["player_fractions"], reference, metric_scale)
        correct_error_metrics(record["score"], reference, metric_scale)
        correct_error_metrics(record["retain"], reference, metric_scale)
        correct_error_metrics(record["final"], reference, metric_scale)
        corrected_final_payload = [
            {"corners_px": candidate["corners_px"], "score": candidate["score"]}
            for candidate in record["final"]["candidates"]
        ]
        final_payload_preserved = raw_final_payload == corrected_final_payload
        if not final_payload_preserved:
            raise ValueError(f"{record['id']}: correction changed final coordinates or scores")
        record["correction_provenance"] = {
            "raw_v1_generated": raw_generated,
            "corrected_search_generated": corrected_generated,
            "removed_final_validation_calls": final_count,
            "raw_v1_unique": raw_unique,
            "corrected_unique": corrected_generated,
            "raw_v1_duplicates": int(record["homographies"]["duplicates"]),
            "search_calls": search_calls,
            "best_generation_indices": {
                "max": None if not indices else max(indices),
                "all_before_corrected_generation": all(index < corrected_generated for index in indices),
            },
            "final_validation_fractions_recomputed_from_cached_feet": final_validation_fractions,
            "native_to_primary_error_scale": metric_scale.tolist(),
            "final_coordinates_scores_preserved": final_payload_preserved,
        }
        correction_records.append({
            "id": record["id"],
            "raw_generated": raw_generated,
            "corrected_generated": corrected_generated,
            "removed_final_validation_calls": final_count,
            "final_validation_with_players": final_validation_with_players,
            "max_best_generation_index": None if not indices else max(indices),
            "all_best_indices_before_corrected_generation": all(index < corrected_generated for index in indices),
            "final_coordinates_scores_preserved": final_payload_preserved,
        })
    corrected["correction_provenance"] = {
        "from_schema": raw["schema"],
        "method": "metadata-only correction; no zone_net.detect replay",
        "search_generation_formula": "rectangle_count * template_transform_count",
        "final_validation_calls_excluded": "single-homography player_fractions callbacks after retention",
        "primary_error_metric": "1280x720 pixel coordinates",
        "records": correction_records,
        "validation": validate_corrected_trace(corrected),
    }
    return corrected


def validate_corrected_trace(trace: dict[str, Any]) -> dict[str, Any]:
    checks = []
    for record in trace["records"]:
        expected_generated = record["rectangle_count"] * record["settings"]["template_transform_count"]
        checks.extend([
            record["homographies"]["generated"] == expected_generated,
            record["homographies"]["unique"] == expected_generated,
            record["homographies"]["duplicates"] == 0,
            record["player_fractions"]["calls"] == math.ceil(record["rectangle_count"] / 8),
            record["player_fractions"]["final_validation_calls"] == record["final"]["count"],
            record["comparison"]["exact_match"],
        ])
    return {"passed": all(checks), "check_count": len(checks)}


def run(args: argparse.Namespace) -> dict[str, Any]:
    replay_path = args.replay.expanduser().resolve()
    zone_path = args.legacy_dir.expanduser().resolve() / "zone_net.py"
    output_path = args.output.expanduser().resolve()
    execution_path = args.execution.expanduser().resolve()
    with zipfile.ZipFile(replay_path) as archive:
        packed = json.loads(gzip.decompress(archive.read("marking_inputs.json.gz")))
    cases = {case["id"]: case for case in packed["cases"]}
    requested = args.ids or list(CASE_IDS)
    unknown = sorted(set(requested) - set(cases))
    if unknown:
        raise ValueError(f"unknown case IDs: {unknown}")
    zone_net, detector = load_zone_net(zone_path)
    cv2.setNumThreads(1)
    global TRACE_DETECTOR
    TRACE_DETECTOR = detector
    started = time.perf_counter()
    records = []
    for case_id in requested:
        case = cases[case_id]
        records.append(trace_case(case, packed["references"][case_id], case["candidates"], zone_net, detector))
    output = {
        "schema": "cached-all-people-proposal-trace/2",
        "source_zone_net": zone_path.name,
        "source_zone_net_sha256": sha256(zone_path),
        "source_replay": replay_path.name,
        "source_replay_sha256": sha256(replay_path),
        "opencv_threads": cv2.getNumThreads(),
        "references_diagnostic_only": True,
        "records": records,
    }
    write_gzip_json(output_path, output)
    execution = {
        "schema": "cached-all-people-proposal-trace-execution/2",
        "case_ids": requested,
        "output_name": output_path.name,
        "source_zone_net": zone_path.name,
        "source_zone_net_sha256": sha256(zone_path),
        "source_replay": replay_path.name,
        "source_replay_sha256": sha256(replay_path),
        "opencv_threads": cv2.getNumThreads(),
        "status": "pass" if all(record["comparison"]["exact_match"] for record in records) else "differences",
        "elapsed_seconds": time.perf_counter() - started,
        "records": [
            {
                "id": record["id"],
                "generated": record["homographies"]["generated"],
                "unique": record["homographies"]["unique"],
                "duplicates": record["homographies"]["duplicates"],
                "budget": record["homographies"]["budget"],
                "final_count": record["final"]["count"],
                "exact_match": record["comparison"]["exact_match"],
                "difference_count": len(record["comparison"]["differences"]),
            }
            for record in records
        ],
    }
    write_gzip_json(execution_path, execution)
    print(json.dumps(execution, indent=2))
    return output


def correct_existing(args: argparse.Namespace) -> dict[str, Any]:
    replay_path = args.replay.expanduser().resolve()
    zone_path = args.legacy_dir.expanduser().resolve() / "zone_net.py"
    input_path = args.correct_v1.expanduser().resolve()
    output_path = args.output.expanduser().resolve()
    raw = read_gzip_json(input_path)
    with zipfile.ZipFile(replay_path) as archive:
        packed = json.loads(gzip.decompress(archive.read("marking_inputs.json.gz")))
    zone_net, detector = load_zone_net(zone_path)
    corrected = correct_trace_v1(raw, packed, zone_net, detector)
    corrected["source_zone_net"] = zone_path.name
    corrected["source_replay"] = replay_path.name
    corrected["source_replay_sha256"] = sha256(replay_path)
    corrected["source_zone_net_sha256"] = sha256(zone_path)
    corrected["correction_provenance"]["raw_v1_sha256"] = sha256(input_path)
    write_gzip_json(output_path, corrected)
    print(json.dumps(corrected["correction_provenance"], indent=2))
    return corrected


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--legacy-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--execution", type=Path)
    parser.add_argument("--correct-v1", type=Path)
    parser.add_argument("--ids", nargs="*")
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    if arguments.correct_v1 is not None:
        correct_existing(arguments)
    else:
        if arguments.execution is None:
            raise SystemExit("--execution is required for a fresh trace")
        run(arguments)
