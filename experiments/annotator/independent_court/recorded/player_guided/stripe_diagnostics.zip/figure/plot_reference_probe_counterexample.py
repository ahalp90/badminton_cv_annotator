"""Plot a recorded near-baseline response against the reference image context.

The right panel overlays only detector fragments and the finite diagnostic ray
on native image coordinates. The ray marks a template-required empty region;
it does not identify a physical endpoint or classify the visible surface.
"""

from __future__ import annotations

import argparse
import gzip
import json
import zipfile
from pathlib import Path
from typing import Any

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np

from experiments.annotator.independent_court.detector import (
    CORNER_COURT_M,
    SEGMENTS_M,
    project,
)

CASE_ID = "am3_window_02_frame_17174"
FRAGMENT_ID = 458
WORKING_SIZE = np.array([960.0, 540.0])
PLOT_CROP = (1600.0, 1850.0, 820.0, 970.0)
ARM_START_M = 0.04
ARM_END_M = 0.24
POSITION_OFFSET_M = 0.02
EXPECTED_RESPONSE = 0.8389301134
EXPECTED_FRAGMENT = np.array([[1686.03588867, 889.88769531], [1765.58972168, 915.28509521]])
EXPECTED_JUNCTION = np.array([1665.46, 878.996])
RAW_COLOUR = "#4d4d4d"
FRAGMENT_COLOUR = "#2166ac"
EMPTY_COLOUR = "#e69f00"


def read_json_gz(path: Path) -> dict[str, Any]:
    """Read one UTF-8 JSON gzip object."""
    with gzip.open(path, "rt", encoding="utf-8") as source:
        value = json.load(source)
    if not isinstance(value, dict):
        raise TypeError(f"expected a JSON object in {path}")
    return value


def read_replay_inputs(path: Path) -> dict[str, Any]:
    """Read the packed marking inputs without extracting or changing the archive."""
    with zipfile.ZipFile(path) as archive:
        name = next((item for item in archive.namelist() if item.endswith("marking_inputs.json.gz")), None)
        if name is None:
            raise ValueError(f"{path} has no marking_inputs.json.gz")
        value = json.loads(gzip.decompress(archive.read(name)))
    if not isinstance(value, dict):
        raise TypeError(f"expected a JSON object in {path}:marking_inputs.json.gz")
    return value


def unique_record(records: list[dict[str, Any]], key: str, expected: str, source: str) -> dict[str, Any]:
    """Return one record with an exact key match."""
    matches = [record for record in records if record.get(key) == expected]
    if len(matches) != 1:
        raise ValueError(f"expected one {expected!r} {key} in {source}, found {len(matches)}")
    return matches[0]


def project_native(homography_work: np.ndarray, points_m: np.ndarray, scale: np.ndarray) -> np.ndarray:
    """Project court-metre points through a working-image homography to native pixels."""
    projected_work, denominator = project(homography_work[None], points_m)
    if not np.isfinite(denominator).all() or not np.isfinite(projected_work).all():
        raise ValueError("diagnostic projection crosses the homography horizon")
    return projected_work[0] * scale


def load_records(
    image_path: Path, replay_path: Path, probe_path: Path,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any], dict[str, Any], float, np.ndarray, np.ndarray]:
    """Load and cross-check the source image, raw fragments, probe, and ray geometry."""
    image = mpimg.imread(image_path)
    replay = read_replay_inputs(replay_path)
    probe = read_json_gz(probe_path)
    case = unique_record(replay["cases"], "id", CASE_ID, f"{replay_path}:cases")
    probe_record = unique_record(probe["records"], "id", CASE_ID, f"{probe_path}:records")
    dimensions = case["dimensions"]
    expected_shape = (dimensions["height"], dimensions["width"])
    if image.shape[:2] != expected_shape:
        raise ValueError(f"source image shape {image.shape[:2]} does not match case dimensions {expected_shape}")
    if np.asarray(image).shape[:2] != (1080, 1920):
        raise ValueError(f"expected native 1920x1080 source image, found {image.shape[:2]}")

    segments_native = np.asarray(case["segments_px"], dtype=float).reshape(-1, 2, 2)
    if FRAGMENT_ID >= len(segments_native):
        raise ValueError(f"fragment ID {FRAGMENT_ID} is outside {len(segments_native)} replay fragments")
    fragment = segments_native[FRAGMENT_ID]
    fragment_mismatch = float(np.max(np.abs(fragment - EXPECTED_FRAGMENT)))
    if fragment_mismatch > 1e-5:
        raise ValueError(f"fragment {FRAGMENT_ID} differs from supplied endpoints by {fragment_mismatch:.9f} px")

    site = unique_record(probe_record["junctions"]["sites"], "marking", "near_baseline", "reference junction sites")
    response = float(site["arms"]["near"])
    if abs(response - EXPECTED_RESPONSE) > 1e-9:
        raise ValueError(f"near-arm response differs from supplied value by {abs(response - EXPECTED_RESPONSE):.12f}")

    native_corners = np.asarray(probe_record["corners_px"], dtype=np.float32)
    scale = np.asarray([dimensions["width"], dimensions["height"]], dtype=float) / WORKING_SIZE
    working_corners = (native_corners / scale).astype(np.float32)
    homography_work = cv2.getPerspectiveTransform(CORNER_COURT_M.astype(np.float32), working_corners)
    junction_court = np.array([[SEGMENTS_M[2, 0, 0], SEGMENTS_M[11, 0, 1]]], dtype=float)
    direction_near = np.array([0.0, 1.0])
    normal = np.array([-direction_near[1], direction_near[0]])
    offset_junction_court = junction_court + POSITION_OFFSET_M * normal
    ray_court = offset_junction_court + np.array([ARM_START_M, ARM_END_M])[:, None] * direction_near
    junction_native = project_native(homography_work, junction_court, scale)[0]
    ray_native = project_native(homography_work, ray_court, scale)
    junction_mismatch = float(np.max(np.abs(junction_native - EXPECTED_JUNCTION)))
    if junction_mismatch > 0.02:
        raise ValueError(f"reference junction differs from supplied value by {junction_mismatch:.6f} px")
    return image, segments_native, probe_record, site, response, fragment, np.vstack((junction_native, ray_native))


def draw_axes(
    axis: Any,
    *,
    image: np.ndarray | None,
    segments_native: np.ndarray,
    fragment: np.ndarray,
    geometry: np.ndarray,
    response: float,
) -> None:
    """Draw one panel in native image coordinates."""
    if image is not None:
        height, width = image.shape[:2]
        axis.imshow(image, extent=(0.0, width, height, 0.0), interpolation="none")
    else:
        for segment in segments_native:
            axis.plot(segment[:, 0], segment[:, 1], color=RAW_COLOUR, linewidth=0.6, alpha=0.45, zorder=1)
        axis.plot(
            fragment[:, 0], fragment[:, 1], color=FRAGMENT_COLOUR, linewidth=2.4,
            solid_capstyle="round", zorder=3,
        )
        axis.plot(
            geometry[1:, 0], geometry[1:, 1], color=EMPTY_COLOUR, linewidth=2.0,
            linestyle="--", dash_capstyle="round", zorder=4,
        )
        axis.scatter(
            geometry[0, 0], geometry[0, 1], s=64, facecolors="none", edgecolors=EMPTY_COLOUR,
            linewidths=2.0, zorder=5,
        )

    axis.set_xlim(PLOT_CROP[0], PLOT_CROP[1])
    axis.set_ylim(PLOT_CROP[3], PLOT_CROP[2])
    axis.set_aspect("equal", adjustable="box")
    axis.set_xlabel("image x (px)", fontsize=9)
    axis.set_ylabel("image y (px)", fontsize=9)
    axis.tick_params(labelsize=8)
    axis.grid(color="#d9d9d9", linewidth=0.5, alpha=0.6)


def build_figure(image_path: Path, replay_path: Path, probe_path: Path, output_path: Path) -> dict[str, Any]:
    """Build the contextual source/raster comparison and return checked facts."""
    image, segments, probe_record, site, response, fragment, geometry = load_records(
        image_path, replay_path, probe_path,
    )
    figure, axes = plt.subplots(1, 2, figsize=(12.0, 5.4), sharex=True, sharey=True)
    draw_axes(
        axes[0], image=image, segments_native=segments, fragment=fragment,
        geometry=geometry, response=response,
    )
    draw_axes(
        axes[1], image=None, segments_native=segments, fragment=fragment,
        geometry=geometry, response=response,
    )
    axes[0].set_title(CASE_ID, fontsize=10.5, pad=8)
    axes[1].set_title(f"{CASE_ID} · response {response:.2f}", fontsize=10.5, pad=8)
    figure.suptitle("Line response outside the reference court", fontsize=14, y=0.98)

    raw_handle = plt.Line2D([], [], color=RAW_COLOUR, linewidth=1.0, label="raw detector fragments")
    fragment_handle = plt.Line2D([], [], color=FRAGMENT_COLOUR, linewidth=2.2, label="fragment 458 (detector response)")
    empty_handle = plt.Line2D(
        [], [], color=EMPTY_COLOUR, linewidth=2.0, linestyle="--", label="template-required empty near arm",
    )
    junction_handle = plt.Line2D(
        [], [], color=EMPTY_COLOUR, marker="o", markerfacecolor="none", linestyle="none",
        markersize=7, markeredgewidth=1.7, label="reference junction",
    )
    figure.legend(
        handles=[raw_handle, fragment_handle, empty_handle, junction_handle],
        loc="lower center", bbox_to_anchor=(0.5, 0.005), ncol=4, fontsize=8.5, frameon=False,
    )
    figure.subplots_adjust(left=0.07, right=0.99, top=0.86, bottom=0.20, wspace=0.14)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output_path, dpi=220, facecolor="white")
    plt.close(figure)

    junction = geometry[0]
    return {
        "output": str(output_path),
        "case_id": CASE_ID,
        "response": response,
        "response_rounded": round(response, 2),
        "fragment_id": FRAGMENT_ID,
        "fragment_native": fragment.tolist(),
        "reference_junction_native": junction.tolist(),
        "diagnostic_ray_native": geometry[1:].tolist(),
        "crop_px": list(PLOT_CROP),
        "probe_source_variant": probe_record["source_variant"],
        "reference_site_expected": site["expected"],
    }


def parse_args() -> argparse.Namespace:
    """Parse the four reproducibility paths."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True, type=Path, help="native source frame PNG")
    parser.add_argument("--replay", required=True, type=Path, help="marking-refit replay ZIP")
    parser.add_argument("--probe", required=True, type=Path, help="reference_probe.json.gz")
    parser.add_argument("--output", required=True, type=Path, help="PNG output path")
    return parser.parse_args()


def main() -> int:
    """Run the bounded plot and print checked source facts."""
    args = parse_args()
    print(json.dumps(build_figure(args.image, args.replay, args.probe, args.output), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
