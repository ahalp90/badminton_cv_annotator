"""Plot the yellow frame's two recorded centre-line junction diagnostics.

The figure uses original 1280 x 720 image pixels. It reads the frozen raw
DeepLSD fragments and candidate corners from the marking-refit replay, then
uses the saved stripe and junction records for the selected candidate metrics.
The two panels show finite diagnostic arms, not physical endpoint estimates.
"""

from __future__ import annotations

import argparse
import gzip
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from experiments.annotator.independent_court.detector import (
    CORNER_COURT_M,
    SEGMENTS_M,
    project,
)

CASE_ID = "yellow_short_frame_156"
ARM_START_M = 0.04
ARM_END_M = 0.24
CENTRE_X_M = float(SEGMENTS_M[2, 0, 0])
MARKING_SEGMENT_INDEX = {"near_long_service": 10, "near_baseline": 11}
ARM_DIRECTIONS = {
    "left": np.array([-1.0, 0.0]),
    "right": np.array([1.0, 0.0]),
    "far": np.array([0.0, -1.0]),
    "near": np.array([0.0, 1.0]),
}
DEFAULT_CROP = (600.0, 720.0, 640.0, 720.0)
RAW_COLOUR = "#4d4d4d"
PAINTED_COLOUR = "#2166ac"
ABSENT_COLOUR = "#e69f00"


@dataclass(frozen=True)
class PanelSpec:
    """One candidate and interpreted marking to render."""

    candidate_id: str
    marking: str


PANEL_SPECS = (
    PanelSpec("0003:refit", "near_long_service"),
    PanelSpec("0001:original", "near_baseline"),
)


def read_json_gz(path: Path) -> dict[str, Any]:
    """Read one UTF-8 JSON gzip file."""
    with gzip.open(path, "rt", encoding="utf-8") as source:
        value = json.load(source)
    if not isinstance(value, dict):
        raise TypeError(f"expected a JSON object in {path}")
    return value


def read_replay_inputs(path: Path) -> dict[str, Any]:
    """Read ``marking_inputs.json.gz`` from the frozen replay archive."""
    with zipfile.ZipFile(path) as archive:
        name = next((item for item in archive.namelist() if item.endswith("marking_inputs.json.gz")), None)
        if name is None:
            raise ValueError(f"{path} has no marking_inputs.json.gz")
        decoded = gzip.decompress(archive.read(name))
    value = json.loads(decoded)
    if not isinstance(value, dict):
        raise TypeError(f"expected a JSON object in {path}:marking_inputs.json.gz")
    return value


def record_by_field(
    records: list[dict[str, Any]], field: str, expected: str, source: str,
) -> dict[str, Any]:
    """Return one record with a uniquely matching field."""
    matches = [record for record in records if record.get(field) == expected]
    if len(matches) != 1:
        raise ValueError(f"expected one {expected!r} {field} in {source}, found {len(matches)}")
    return matches[0]


def record_by_id(records: list[dict[str, Any]], record_id: str, source: str) -> dict[str, Any]:
    """Return one uniquely identified record."""
    return record_by_field(records, "id", record_id, source)


def candidate_by_id(record: dict[str, Any], candidate_id: str, source: str) -> dict[str, Any]:
    """Return one candidate entry from a saved record."""
    matches = [entry for entry in record["entries"] if entry.get("id") == candidate_id]
    if len(matches) != 1:
        raise ValueError(f"expected one {candidate_id!r} entry in {source}, found {len(matches)}")
    return matches[0]


def homography_for(candidate: dict[str, Any]) -> np.ndarray:
    """Build the court-metre to original-pixel homography for one candidate."""
    corners = np.asarray(candidate["corners_px"], dtype=np.float32)
    return cv2.getPerspectiveTransform(CORNER_COURT_M.astype(np.float32), corners)


def project_points(homography: np.ndarray, points_m: np.ndarray) -> np.ndarray:
    """Project court-metre points to image pixels with the repository helper."""
    projected, denominator = project(homography[None], np.asarray(points_m, dtype=float))
    if not np.isfinite(denominator).all() or not np.isfinite(projected).all():
        raise ValueError("candidate homography projects a diagnostic point at the horizon")
    return projected[0]


def marking_y(marking: str) -> float:
    """Return a named marking's court y coordinate from the metric template."""
    try:
        segment = SEGMENTS_M[MARKING_SEGMENT_INDEX[marking]]
    except KeyError as error:
        raise ValueError(f"unsupported junction marking: {marking}") from error
    return float(segment[0, 1])


def vertical_arm_is_painted(marking_y_m: float, arm: str) -> bool:
    """Read whether a finite vertical arm lies inside the painted template."""
    if arm not in ("far", "near"):
        return True
    sign = -1.0 if arm == "far" else 1.0
    query_y = marking_y_m + sign * (ARM_START_M + ARM_END_M) / 2.0
    lower = np.minimum(SEGMENTS_M[2:4, 0, 1], SEGMENTS_M[2:4, 1, 1])
    upper = np.maximum(SEGMENTS_M[2:4, 0, 1], SEGMENTS_M[2:4, 1, 1])
    return bool(np.any((lower < query_y) & (query_y < upper)))


def arm_endpoints(homography: np.ndarray, marking: str, arm: str) -> np.ndarray:
    """Project one finite 0.04--0.24 metre arm around a junction."""
    centre = np.array([CENTRE_X_M, marking_y(marking)], dtype=float)
    direction = ARM_DIRECTIONS[arm]
    points_m = centre[None] + np.array([ARM_START_M, ARM_END_M])[:, None] * direction
    return project_points(homography, points_m)


def crop_for_junctions(junctions: list[np.ndarray], requested: tuple[float, float, float, float]) -> tuple[
    tuple[float, float, float, float], str
]:
    """Keep the requested crop unless a projected junction falls outside it."""
    x_min, x_max, y_min, y_max = requested
    inside = all(x_min <= point[0] <= x_max and y_min <= point[1] <= y_max for point in junctions)
    if inside:
        return requested, "none; both projected junctions are inside x=600..720, y=640..720"

    width, height = x_max - x_min, y_max - y_min
    centre = np.mean(np.asarray(junctions), axis=0)
    x_min = float(centre[0] - width / 2.0)
    y_min = float(centre[1] - height / 2.0)
    return (x_min, x_min + width, y_min, y_min + height), (
        "adjusted to keep both projected junctions visible; "
        f"centre=({centre[0]:.2f}, {centre[1]:.2f})"
    )


def observed_support(site: dict[str, Any], arm: str) -> str:
    """Format one recorded arm support to two decimals."""
    value = site["arms"][arm]
    return "n/a" if value is None else f"{float(value):.2f}"


def draw_panel(
    axis: Any,
    *,
    case: dict[str, Any],
    candidate: dict[str, Any],
    junction_site: dict[str, Any],
    spec: PanelSpec,
    crop: tuple[float, float, float, float],
) -> dict[str, Any]:
    """Draw one crop and return its factual plotting summary."""
    segments = np.asarray(case["segments_px"], dtype=float).reshape(-1, 2, 2)
    homography = homography_for(candidate)
    y_m = marking_y(spec.marking)
    junction = project_points(homography, np.array([[CENTRE_X_M, y_m]], dtype=float))[0]

    for segment in segments:
        axis.plot(
            segment[:, 0],
            segment[:, 1],
            color=RAW_COLOUR,
            linewidth=0.65,
            alpha=0.45,
            solid_capstyle="round",
            zorder=1,
        )

    for arm in ARM_DIRECTIONS:
        endpoints = arm_endpoints(homography, spec.marking, arm)
        painted = vertical_arm_is_painted(y_m, arm)
        colour = PAINTED_COLOUR if painted else ABSENT_COLOUR
        axis.plot(
            endpoints[:, 0],
            endpoints[:, 1],
            color=colour,
            linewidth=2.4 if painted else 2.1,
            linestyle="-" if painted else "--",
            solid_capstyle="round",
            dash_capstyle="round",
            zorder=3,
        )
        if arm in ("far", "near"):
            midpoint = endpoints.mean(axis=0)
            axis.annotate(
                f"{arm} support {observed_support(junction_site, arm)}",
                xy=midpoint,
                xytext=(7, -8 if arm == "far" else 8),
                textcoords="offset points",
                fontsize=7.6,
                color="#222222",
                ha="left",
                va="center",
                bbox={"boxstyle": "round,pad=0.18", "facecolor": "white", "alpha": 0.82, "linewidth": 0},
                zorder=5,
            )

    axis.scatter([junction[0]], [junction[1]], s=18, color="#222222", zorder=4)
    axis.set_xlim(crop[0], crop[1])
    axis.set_ylim(crop[3], crop[2])
    axis.set_aspect("equal", adjustable="box")
    axis.set_xlabel("image x (px)", fontsize=8.5)
    axis.set_ylabel("image y (px)", fontsize=8.5)
    axis.tick_params(labelsize=8)
    axis.grid(color="#d9d9d9", linewidth=0.5, alpha=0.6)
    axis.set_title(f"{spec.candidate_id} | {spec.marking}", fontsize=11, pad=13)
    axis.text(
        0.5,
        1.01,
        f"worst-corner error: {float(candidate['metrics']['corner_max_error_px']):.2f} px",
        transform=axis.transAxes,
        ha="center",
        va="bottom",
        fontsize=8.5,
        color="#333333",
    )

    return {
        "candidate_id": spec.candidate_id,
        "marking": spec.marking,
        "junction_px": [round(float(value), 2) for value in junction],
        "observed_support": {
            "far": observed_support(junction_site, "far"),
            "near": observed_support(junction_site, "near"),
        },
        "expected_arms": {
            arm: vertical_arm_is_painted(y_m, arm) for arm in ARM_DIRECTIONS if arm in ("far", "near")
        },
        "worst_corner_error_px": float(candidate["metrics"]["corner_max_error_px"]),
    }


def build_figure(
    *,
    replay_path: Path,
    stripes_path: Path,
    junctions_path: Path,
    output_path: Path,
    case_id: str = CASE_ID,
    crop: tuple[float, float, float, float] = DEFAULT_CROP,
) -> dict[str, Any]:
    """Load frozen records, render both panels, and save the PNG."""
    replay = read_replay_inputs(replay_path)
    stripes = read_json_gz(stripes_path)
    junctions = read_json_gz(junctions_path)
    case = record_by_id(replay["cases"], case_id, f"{replay_path}:cases")
    stripe_record = record_by_id(stripes["records"], case_id, f"{stripes_path}:records")
    junction_record = record_by_id(junctions["records"], case_id, f"{junctions_path}:records")
    if case["dimensions"] != {"width": 1280, "height": 720}:
        raise ValueError(f"expected original 1280x720 case dimensions, found {case['dimensions']}")

    candidates = {
        spec.candidate_id: candidate_by_id(stripe_record, spec.candidate_id, f"{stripes_path}:{case_id}")
        for spec in PANEL_SPECS
    }
    sites = {}
    for spec in PANEL_SPECS:
        candidate_site = candidate_by_id(junction_record, spec.candidate_id, f"{junctions_path}:{case_id}")
        sites[spec.candidate_id] = record_by_field(candidate_site["sites"], "marking", spec.marking, "junction sites")

    homographies = {candidate_id: homography_for(candidate) for candidate_id, candidate in candidates.items()}
    junction_points = [
        project_points(homographies[spec.candidate_id], np.array([[CENTRE_X_M, marking_y(spec.marking)]]))[0]
        for spec in PANEL_SPECS
    ]
    actual_crop, crop_adjustment = crop_for_junctions(junction_points, crop)

    figure, axes = plt.subplots(1, 2, figsize=(12.5, 4.9), sharex=True, sharey=True)
    summaries = []
    for axis, spec in zip(axes, PANEL_SPECS):
        summaries.append(
            draw_panel(
                axis,
                case=case,
                candidate=candidates[spec.candidate_id],
                junction_site=sites[spec.candidate_id],
                spec=spec,
                crop=actual_crop,
            )
        )

    raw_handle = plt.Line2D([], [], color=RAW_COLOUR, linewidth=1.1, label="raw DeepLSD fragment")
    painted_handle = plt.Line2D([], [], color=PAINTED_COLOUR, linewidth=2.1, label="expected painted arm")
    absent_handle = plt.Line2D(
        [], [], color=ABSENT_COLOUR, linewidth=2.0, linestyle="--", label="expected absent vertical arm",
    )
    figure.legend(
        handles=[raw_handle, painted_handle, absent_handle],
        loc="lower center",
        bbox_to_anchor=(0.5, 0.005),
        ncol=3,
        fontsize=8.5,
        frameon=False,
    )
    figure.subplots_adjust(left=0.07, right=0.99, top=0.86, bottom=0.22, wspace=0.16)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output_path, dpi=220, facecolor="white")
    plt.close(figure)

    return {
        "output": str(output_path),
        "case_id": case_id,
        "crop_px": [float(value) for value in actual_crop],
        "crop_adjustment": crop_adjustment,
        "panels": summaries,
    }


def parse_args() -> argparse.Namespace:
    """Parse paths and the optional case/crop controls."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replay", required=True, type=Path, help="marking-refit replay ZIP")
    parser.add_argument("--stripes", required=True, type=Path, help="frozen stripe results_v1.json.gz")
    parser.add_argument("--junctions", required=True, type=Path, help="frozen junctions_v1.json.gz")
    parser.add_argument("--output", required=True, type=Path, help="PNG output path")
    parser.add_argument("--case-id", default=CASE_ID, help="case ID to plot")
    parser.add_argument(
        "--crop",
        nargs=4,
        type=float,
        metavar=("X_MIN", "X_MAX", "Y_MIN", "Y_MAX"),
        default=DEFAULT_CROP,
        help="original-pixel crop; defaults to 600 720 640 720",
    )
    return parser.parse_args()


def main() -> int:
    """Run the plotter and print a compact factual summary."""
    args = parse_args()
    summary = build_figure(
        replay_path=args.replay,
        stripes_path=args.stripes,
        junctions_path=args.junctions,
        output_path=args.output,
        case_id=args.case_id,
        crop=tuple(args.crop),
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
