# Fixed-court directional evidence replay

Read the adjacent fixed_court_matching.md report. This is a development
measurement, not an automatic detector or a calibrated acceptance rule.

## Contents and provenance

- inputs.json.gz: 25 previously frozen GX courts on seven frames. Source fragments
  come from extension_diagnostics.zip:gx/inputs.json.gz. Court selections come
  from gx_proposal_diagnostics.zip, including references, saved boundary-selected
  starts, saved random geometry, the floor survivor and complete-search examples.
  The frame-0 legacy refit is preserved as well. Selection descriptions and prior
  evidence remain attached; labels never enter the measurement function.
- controls.json.gz: 38 courts on 15 older frames. Four amateur references and
  their saved stripe winners use marking_refit_replay.zip:marking_inputs.json.gz
  and stripe_diagnostics.zip members junction_selection_v1.json.gz and
  fixed_refit_v1.json.gz. Two broadcast references/stripe winners and one wrong
  junction winner use extension_diagnostics.zip:broadcast inputs/results.
  One Amateur-3 reference retains the known fragment-458 continuation control.
  Eight non-court frames use followup_replay.zip:control_pack.json.gz. Each has
  three fixed synthetic placements, dimension-normalised from GX frame 5,
  broadcast scene 0017 and Amateur-3 frame 0 references. These are not generated
  candidates. Input fields omit original operational/image metadata.
- gx_results.json.gz and control_results.json.gz: full per-interval measurements.
- run_fixed_matching.py: standalone runner using the repository measurement module.
- check_results.py and check.json.gz: frozen court identity, saved support/count
  arithmetic, threshold decisions and directional/all-fragment inclusion checks.
  For passing GX references it also independently counts original-family lines
  while holding directional point support fixed.
- render_matches.py: selected correspondence figures from saved results only.

The earlier detector checkpoint is 3ee675e. The new measurement module is
experiments/annotator/independent_court/fixed_floor_evidence.py. Input packs record
MD5 identity for it, detector.py and assignment.py; these matched the experiment
host. Python 3.11.13, NumPy 2.4.6 and OpenCV 5.0.0 produced the saved outputs.
Use the project's numerical environment; SciPy and Pillow are needed for imports
and figure generation. No new inference or video decoding is needed.

## Measurement contract

Corners and cached fragments in inputs are native-image pixels. Results name
working-image size and native_scale. All matching distances, projected intervals,
samples and merged-line coefficients use working pixels. Images have maximum
dimension 960. Geometry never changes within this comparison.

All arms retain the original twelve intervals, visibility and aggregation, 24
samples, 4 px support distance, 0.55 support thresholds and 3 distinct lines/family.
Nearest merged lines must lie within 8 px at both sample endpoints. Original
merging uses 8 px/3 degrees and keeps 32 lines. These GX settings are applied to
older controls for this comparison; they do not assert historical eligibility.

Original/family uses raster distances. Finite/family isolates the distance-method
change using the original family pools. Finite/projected applies relative five-degree
compatibility; finite/all supplies unrestricted evidence. The last two share an
all-fragment merged pool. Replacing a family pool can change which lines survive
its cap even though the merging algorithm/settings are unchanged.

Raw support and rejection reasons are retained, including geometry status.
All 63 tested courts pass the separate geometry check. Their reconstructed
raster/family score exactly matches detector._score at the same homography.
The detector itself may never reach the camera stage for a floor-rejected court.
No downstream stage or emission decision is simulated here.

Fragment IDs index the original input segments_px array. Nearest fragment IDs
are present only for finite-distance arms: raster pixels do not identify the
source fragment. Nearest merged-line IDs index either family_lines[family] or
all_lines in the same case result. counted_line_ids applies support and residual
thresholds before distinct counting. -1 means no compatible nearest fragment,
no finite residual, or an uncounted line, depending on the named field. nearest
IDs may describe unsupported samples; covered_samples states actual support.
The split centre intervals can reuse one merged line and count it once per family.

## Replay

From the repository root:

```bash
matching_recorded=experiments/annotator/independent_court/recorded/player_guided &&
matching_replay=$(mktemp -d /tmp/fixed-court-matching.XXXXXX) &&
unzip -q "$matching_recorded/fixed_court_matching.zip" -d "$matching_replay"

OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=src:. \
  python "$matching_replay/run_fixed_matching.py" \
  --inputs "$matching_replay/inputs.json.gz" \
  --output "$matching_replay/gx_results.json.gz"

OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=src:. \
  python "$matching_replay/run_fixed_matching.py" \
  --inputs "$matching_replay/controls.json.gz" \
  --output "$matching_replay/control_results.json.gz"

PYTHONPATH=src:. python "$matching_replay/check_results.py" \
  --directory "$matching_replay"

PYTHONPATH=src:. python "$matching_replay/render_matches.py" \
  --inputs "$matching_replay/inputs.json.gz" \
  --results "$matching_replay/gx_results.json.gz" \
  --frames "$matching_recorded/extension_overlays/gx" \
  --output "$matching_replay/gallery"
```

To check the saved arithmetic without rerunning measurements, extract the
archive and invoke check_results.py immediately. Runtime totals are sums of
per-case measurements, including preparation and baseline comparisons, excluding
imports and transfers. The checker does not independently recreate every pixel
raster or merged pool; independent technical review has its own stated coverage.
