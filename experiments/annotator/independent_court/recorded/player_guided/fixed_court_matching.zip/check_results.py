"""Check frozen court identity, saved support accounting and paired comparisons."""
from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

ARMS = ('raster_family', 'finite_family', 'finite_projected', 'finite_all')


def read(path: Path) -> dict:
    return json.loads(gzip.decompress(path.read_bytes()))


def original_pool_counts(entry: dict, record: dict, settings: dict, angle_deg: float) -> list[int]:
    """Independently count original lines while holding directional support fixed."""
    samples = np.asarray(entry['samples_working_px'])
    endpoints = np.asarray(entry['projected_intervals_working_px'])
    vectors = endpoints[:, 1] - endpoints[:, 0]
    directions = vectors / np.linalg.norm(vectors, axis=1)[:, None]
    support = entry['arms']['finite_projected']['interval_support']
    counts = []
    for family, lines in enumerate(record['family_lines']):
        used = set()
        for interval in range(6 * family, 6 * (family + 1)):
            if support[interval] < settings['min_family_support']:
                continue
            candidates = []
            for line_id, line in enumerate(lines):
                normal = np.asarray(line[:2])
                direction = np.array([line[1], -line[0]])
                if abs(directions[interval] @ direction) < np.cos(np.deg2rad(angle_deg)):
                    continue
                residual = max(abs(point @ normal + line[2]) for point in samples[interval][[0, -1]])
                candidates.append((residual, line_id))
            if candidates:
                distance, line_id = min(candidates)
                if distance <= settings['support_distance'] * 2:
                    used.add(line_id)
        counts.append(len(used))
    return counts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    args = parser.parse_args()
    groups = defaultdict(lambda: [0, 0, 0, 0, 0])
    pool_checks = []
    runtime = 0.0
    total = 0
    for input_name, result_name in (('inputs.json.gz', 'gx_results.json.gz'),
                                    ('controls.json.gz', 'control_results.json.gz')):
        source = read(args.directory / input_name)
        result = read(args.directory / result_name)
        assert source['source_identity'] == result['source_identity']
        assert [case['id'] for case in source['cases']] == [case['id'] for case in result['cases']]
        for case, record in zip(source['cases'], result['cases']):
            assert case['settings'] == record['settings']
            assert [court['id'] for court in case['courts']] == [court['id'] for court in record['entries']]
            settings = case['settings']
            runtime += record['runtime_s']
            for court, entry in zip(case['courts'], record['entries']):
                assert court['corners_px'] == entry['corners_px']
                assert entry['original_score_control_exact']
                visible = np.asarray(entry['visible'])
                for arm_name in ARMS:
                    arm = entry['arms'][arm_name]
                    support = np.asarray(arm['covered_samples']).mean(axis=1)
                    np.testing.assert_array_equal(support, arm['interval_support'])
                    means = [support[:6].sum() / max(visible[:6].sum(), 1),
                             support[6:].sum() / max(visible[6:].sum(), 1)]
                    np.testing.assert_array_equal(means, arm['family_means'])
                    ids = np.asarray(arm['counted_line_ids'])
                    counts = [len(np.unique(ids[:6][ids[:6] >= 0])), len(np.unique(ids[6:][ids[6:] >= 0]))]
                    assert counts == arm['distinct_line_counts']
                    passed = min(means) >= settings['min_family_support'] and min(counts) >= settings['min_supported_lines']
                    assert passed == (arm['floor_score'] >= 0) == (not arm['rejection_reasons'])
                    if arm_name != 'raster_family':
                        distance = np.asarray(arm['nearest_fragment_distances_px'])
                        covered = (distance >= 0) & (distance <= settings['support_distance']) & visible[:, None]
                        np.testing.assert_array_equal(covered, arm['covered_samples'])
                projected = np.asarray(entry['arms']['finite_projected']['covered_samples'])
                unrestricted = np.asarray(entry['arms']['finite_all']['covered_samples'])
                assert not np.any(projected & ~unrestricted)
                row = groups[court['role']]
                row[0] += 1
                for index, arm_name in enumerate(ARMS, 1):
                    row[index] += entry['arms'][arm_name]['floor_score'] >= 0
                total += 1
                if court['role'] == 'gx_reference' and entry['arms']['finite_projected']['floor_score'] >= 0:
                    original_counts = original_pool_counts(entry, record, settings, result['match_angle_deg'])
                    pool_checks.append({'id': case['id'],
                                        'original_pools': original_counts,
                                        'all_pool': entry['arms']['finite_projected']['distinct_line_counts']})
    summary = {'court_count': total, 'sum_case_runtime_s': runtime, 'arms': ARMS, 'role_counts': dict(groups),
               'projected_support_pool_comparison': pool_checks,
               'checks': 'fixed corners, exact baseline flag, raw support/count/threshold arithmetic and access inclusion'}
    print(json.dumps(summary, indent=2))
    (args.directory / 'check.json.gz').write_bytes(gzip.compress(json.dumps(summary).encode(), mtime=0))


if __name__ == '__main__':
    main()
