"""Show observed fragments supporting one fixed projected marking in two arms."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ARM_LABELS = {'finite_family': 'Finite/family', 'finite_projected': 'Finite/directional',
              'finite_all': 'Finite/all'}


def read(path: Path) -> dict:
    return json.loads(gzip.decompress(path.read_bytes()))


def render(inputs: dict, results: dict, frames: Path, output: Path, case_id: str,
           court_id: str, interval: int, arms: tuple[str, str]) -> None:
    source = next(case for case in inputs['cases'] if case['id'] == case_id)
    case = next(case for case in results['cases'] if case['id'] == case_id)
    entry = next(row for row in case['entries'] if row['id'] == court_id)
    size = np.asarray(case['working_size'])
    scale = np.array([1280, 720]) / size
    native_scale = np.array([1280 / source['dimensions']['width'], 720 / source['dimensions']['height']])
    fragments = np.asarray(source['segments_px']).reshape(-1, 2, 2) * native_scale
    samples = np.asarray(entry['samples_working_px'])[interval] * scale
    endpoints = np.asarray(entry['projected_intervals_working_px'])[interval] * scale
    with Image.open(frames / f'{case_id}.png') as image:
        frame = image.convert('RGB').resize((1280, 720), Image.Resampling.LANCZOS)
    figure = Image.new('RGB', (2560, 840), 'white')
    font = ImageFont.truetype('DejaVuSans.ttf', 20)
    small = ImageFont.truetype('DejaVuSans.ttf', 16)
    for column, arm_name in enumerate(arms):
        arm = entry['arms'][arm_name]
        panel = frame.copy()
        draw = ImageDraw.Draw(panel)
        ids = np.asarray(arm['nearest_fragment_ids'])[interval]
        covered = np.asarray(arm['covered_samples'])[interval]
        for fragment_id in np.unique(ids[covered]):
            points = [tuple(point) for point in fragments[fragment_id]]
            draw.line(points, fill='black', width=7)
            draw.line(points, fill='#ffcc33', width=4)
            centre = fragments[fragment_id].mean(axis=0)
            draw.text(tuple(centre), str(fragment_id), font=small, fill='white', stroke_width=2, stroke_fill='black')
        draw.line([tuple(point) for point in endpoints], fill='#cc00cc', width=2)
        for point, present in zip(samples, covered):
            x, y = point
            draw.ellipse((x-3, y-3, x+3, y+3), fill='#2288ff' if present else 'white', outline='black')
        figure.paste(panel, (1280 * column, 120))
        label = ImageDraw.Draw(figure)
        left = 1280 * column + 12
        label.text((left, 8), f'{case_id} / {court_id} / {entry["interval_names"][interval]}', font=font, fill='black')
        label.text((left, 37), f'{ARM_LABELS[arm_name]}: support {covered.sum()}/{len(covered)}; marking angle '
                   f'{entry["projected_angles_deg"][interval]:.1f} degrees', font=font, fill='black')
        label.text((left, 68), 'Magenta: fixed marking. Gold: supporting cached fragments (raw IDs).', font=small, fill='black')
        label.text((left, 94), 'Blue: supported sample. White: unsupported. Same fixed geometry in both panels.',
                   font=small, fill='black')
    output.mkdir(parents=True, exist_ok=True)
    name = f'{case_id}__{court_id}__{entry["interval_names"][interval]}.jpg'
    figure.save(output / name, quality=94)
    print(name)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--frames', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    inputs, results = read(args.inputs), read(args.results)
    for interval in (4, 11):
        render(inputs, results, args.frames, args.output, 'gxBQ_window_00_frame_5', 'reference', interval,
               ('finite_family', 'finite_projected'))
    render(inputs, results, args.frames, args.output, 'gxBQ_window_00_frame_0', 'reference', 2,
           ('finite_all', 'finite_projected'))


if __name__ == '__main__':
    main()
