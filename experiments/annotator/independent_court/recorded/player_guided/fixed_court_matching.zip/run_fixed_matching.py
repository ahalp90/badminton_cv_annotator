"""Measure fixed-court evidence arms from a frozen, explicitly selected input pack."""
from __future__ import annotations

import argparse
import gzip
import json
import platform
import time
from dataclasses import asdict
from pathlib import Path

import cv2
import numpy as np

from experiments.annotator.independent_court import detector
from experiments.annotator.independent_court import fixed_floor_evidence as evidence


def read(path: Path) -> dict:
    return json.loads(gzip.decompress(path.read_bytes()))


def write(path: Path, data: dict) -> None:
    path.write_bytes(gzip.compress(json.dumps(data, allow_nan=False).encode(), mtime=0))


def run_case(case: dict) -> dict:
    started = time.perf_counter()
    settings = detector.Settings(**case['settings'])
    dimensions = case['dimensions']
    native_size = np.array([dimensions['width'], dimensions['height']])
    factor = min(1, settings.max_dimension / native_size.max())
    size = tuple(round(value * factor) for value in native_size)
    scale = native_size / size
    fragments = np.asarray(case['segments_px']) / np.tile(scale, 2)
    observations = evidence.prepare(fragments, size, settings)
    entries = []
    for candidate in case['courts']:
        corners = np.asarray(candidate['corners_px'])
        homography = cv2.getPerspectiveTransform(detector.CORNER_COURT_M, (corners / scale).astype(np.float32))
        result = evidence.measure(homography, observations, size, settings)
        entries.append({**candidate, **result})
    return {'id': case['id'], 'source': case['source'], 'settings': asdict(settings),
            'working_size': size, 'native_scale': scale.tolist(),
            'family_fragment_ids': [ids.tolist() for ids in observations.family_ids],
            'family_lines': [lines.tolist() for lines in observations.family_lines],
            'all_lines': observations.all_lines.tolist(), 'entries': entries,
            'runtime_s': time.perf_counter() - started}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--ids', nargs='*')
    args = parser.parse_args()
    cv2.setNumThreads(1)
    packed = read(args.inputs)
    results = []
    for case in packed['cases']:
        if args.ids and case['id'] not in args.ids:
            continue
        result = run_case(case)
        results.append(result)
        print(result['id'], len(result['entries']), round(result['runtime_s'], 3), flush=True)
    output = {'schema': 'fixed-court-directional-evidence/1', 'match_angle_deg': evidence.MATCH_ANGLE_DEG,
              'runtime': {'python': platform.python_version(), 'numpy': np.__version__, 'opencv': cv2.__version__},
              'source_identity': packed['source_identity'], 'population': packed['population'], 'cases': results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    write(args.output, output)


if __name__ == '__main__':
    main()
