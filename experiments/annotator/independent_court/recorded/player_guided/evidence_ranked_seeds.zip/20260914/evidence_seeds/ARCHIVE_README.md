# Evidence-ranked court seed replay

This archive records one fixed-budget selector experiment. The neighbouring
evidence_ranked_seeds.md report states its results and limitations. Nothing here
changes the production detector. Input fragments and person observations are
frozen; no video decoding or model inference is needed.

New scripts and measurements are under 20260914/evidence_seeds/. The preserved
prior selector and comparison runner are under 20260913/seed_selection/ so the
synthetic smoke test retains its original relative import. Original random and
simple-spread result records remain in the adjacent seed_selection.zip archive.

Required existing packs, beside this archive:

- gx_proposal_diagnostics.zip: run_trace.py and rectangle_cap.json.gz
- marking_refit_replay.zip: Python legacy helpers and marking_inputs.json.gz
- extension_diagnostics.zip: gx/inputs.json.gz and broadcast/inputs.json.gz
- seed_selection.zip: original baseline result records

Use the repository source at checkpoint 1b75435. The recorded environment uses
Python 3.11.13, NumPy 2.4.6, OpenCV 5.0.0 and SciPy 1.17.1. Extract this archive
to a temporary directory and the dependency packs into separate directories.
From the repository root, use extracted paths as arguments:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=src:. \
  python REPLAY/20260914/evidence_seeds/run_sweep.py \
  --inputs INPUTS/gx/inputs.json.gz --legacy LEGACY \
  --trace-directory TRACE --comparison-directory REPLAY/20260913/seed_selection \
  --id gxBQ_window_00_frame_5 --output fresh-gx5.json.gz
```

The default weights are the three declared pilot values, 0.25/0.5/1.0. For the
five extension frames pass --weights 1. For Amateur-2 use marking_inputs.json.gz,
--id am2_window_00_frame_150 and --click-inset-m 0. For broadcast use its input
pack, --id shuttleset_03_scene_0019 and --broadcast. Broadcast has no boundary
landmarks, so its results contain stage counts and retained-court errors but no
boundary or generated-population error minima.

The original trace checks direct versus instrumented final outputs. The smoke
script checks random/zero-weight selection against the prior implementation:

```bash
PYTHONPATH=src:. python REPLAY/20260914/evidence_seeds/smoke_check.py
```

The seed-loss script traces two label-selected targets without altering the
sampler. It expects old baseline GX5 at OLD/results/gxBQ_window_00_frame_5.json.gz
and Amateur-2 at OLD/controls/results/am2_window_00_frame_150.json.gz. These two
records can be placed there from seed_selection.zip. Then run:

```bash
PYTHONPATH=src:. python REPLAY/20260914/evidence_seeds/inspect_seed_loss.py \
  --gx-inputs INPUTS/gx/inputs.json.gz --amateur-inputs LEGACY/marking_inputs.json.gz \
  --caps TRACE/rectangle_cap.json.gz --old-comparison-dir OLD \
  --new-results-dir REPLAY/20260914/evidence_seeds \
  --prior-selector-dir REPLAY/20260913/seed_selection --trace-directory TRACE \
  --output fresh-seed-loss.json.gz
```

GX/amateur coverage maxima are stored in native 1920×1080 pixels; multiply by
2/3 for 1280×720. Boundary fields and selected_max_corner_1280_px are already at
1280×720. A retained-court error is not an emitted result when accepted is false.
All cases are development comparisons, not held-out validation.
