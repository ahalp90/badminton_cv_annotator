"""Measure the predeclared covered-length rank cue with unchanged court gates."""

from __future__ import annotations

import argparse
import importlib
import sys
from functools import partial
from pathlib import Path
from time import perf_counter

import cv2
import numpy as np
from select_evidence_seeds import select_rectangles

from experiments.annotator.independent_court import detector


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--trace-directory", type=Path, required=True)
    parser.add_argument("--comparison-directory", type=Path, required=True)
    parser.add_argument("--id", required=True)
    parser.add_argument("--weights", type=float, nargs="+", default=[0.25, 0.5, 1.0])
    parser.add_argument("--click-inset-m", type=float, default=0.005)
    parser.add_argument("--broadcast", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path[:0] = [str(path.resolve()) for path in
                   (args.comparison_directory, args.trace_directory, args.legacy)]
    comparison = importlib.import_module("run_comparison")
    trace = importlib.import_module("run_trace")
    zone = importlib.import_module("zone_net")
    packed = trace.read(args.inputs)
    source = next(case for case in packed["cases"] if case["id"] == args.id)
    reference = packed["references"][args.id]
    cv2.setNumThreads(1)
    records = []
    for weight in args.weights:
        selector = partial(select_rectangles, evidence_weight=weight)
        if args.broadcast:
            selections = []

            def rectangles(x_lines: np.ndarray, y_lines: np.ndarray, size: tuple, settings: detector.Settings,
                           *, arm_selector=selector, arm_selections=selections) -> np.ndarray:
                selected, details = arm_selector(x_lines, y_lines, size, settings, "stratified")
                arm_selections.append(details)
                return selected

            original = detector._image_rectangles
            detector._image_rectangles = rectangles
            started = perf_counter()
            try:
                record, rows = trace.capture(source, zone, detector.Settings(wide_families=True, min_supported_lines=3))
            finally:
                detector._image_rectangles = original
            record["timing"] = {"direct_and_traced_s": perf_counter() - started}
            record["seed_selection"] = selections[0]
            record["counts"] = {
                "geometry_before_players": len(rows),
                "players_and_geometry": int(np.isfinite(rows["floor_score"]).sum()),
                "floor_survivors": int((rows["floor_score"] >= 0).sum()),
                "camera_survivors": int((rows["camera_error"] <= 0.1).sum()),
            }
            record["boundary_metrics"] = "unavailable: reference has no boundary landmarks"
        else:
            comparison.select_rectangles = selector
            record = comparison.run_arm(source, reference, "stratified", zone, trace, args.click_inset_m)
        record["evidence_weight"] = weight
        selected_error = None
        if record["final"]["candidates"]:
            selected = np.asarray(record["final"]["candidates"][0]["corners_px"])
            dimensions = source["dimensions"]
            scale = [1280 / dimensions["width"], 720 / dimensions["height"]]
            selected_error = float(np.linalg.norm((selected - reference["corners_px"]) * scale, axis=1).max())
        record["selected_max_corner_1280_px"] = selected_error
        records.append(record)
        print(args.id, "alpha", weight, "accepted", record["final"]["accepted"],
              "selected error", selected_error, "counts", record["counts"], flush=True)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        trace.write(args.output, {"schema": "evidence-ranked-seeds/1", "case_id": args.id,
                                 "labels_used_only_after_generation": True, "arms": records})


if __name__ == "__main__":
    main()
