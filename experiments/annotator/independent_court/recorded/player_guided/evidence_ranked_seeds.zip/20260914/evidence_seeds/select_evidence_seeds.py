"""Diagnostic rectangle selection with an optional line-evidence priority."""

from __future__ import annotations

from itertools import combinations

import cv2
import numpy as np

from experiments.annotator.independent_court import detector

_SELECTION_MODES = ("random", "stratified")
_EVIDENCE_CUE = "mean incoming covered-length rank"
_LINE_RANK_STATS_LIMIT = 4096


def select_rectangles(
    x_lines: np.ndarray,
    y_lines: np.ndarray,
    size: tuple[int, int],
    settings: detector.Settings,
    mode: str,
    evidence_weight: float = 0.0,
) -> tuple[np.ndarray, dict]:
    """Enumerate and select diagnostic court rectangles.

    The input line families are ranked by decreasing covered fragment length.
    Centre sorting and pair-product enumeration retain the original detector
    geometry.  ``evidence_weight`` blends the original within-bin distance
    with each rectangle's mean normalised incoming line rank.

    :param x_lines: Merged lines in the x family, ranked by covered length.
    :param y_lines: Merged lines in the y family, ranked by covered length.
    :param size: Image width and height.
    :param settings: Detector bounds and random seed.
    :param mode: ``"random"`` or ``"stratified"`` selection.
    :param evidence_weight: Blend from spatial distance (0) to line rank (1).
    :return: Perspective transforms and selection statistics.
    """
    if mode not in _SELECTION_MODES:
        raise ValueError(f"unknown rectangle selection mode: {mode}")
    if not np.isfinite(evidence_weight) or not 0.0 <= evidence_weight <= 1.0:
        raise ValueError("evidence_weight must be finite and in [0, 1]")
    alpha = evidence_weight

    width, height = size
    x_order = np.argsort(-(x_lines[:, 1] * height / 2 + x_lines[:, 2]) / x_lines[:, 0])
    y_order = np.argsort(-(y_lines[:, 0] * width / 2 + y_lines[:, 2]) / y_lines[:, 1])
    x_lines, y_lines = x_lines[x_order], y_lines[y_order]
    intersections = np.cross(x_lines[:, None], y_lines[None, :])
    with np.errstate(divide="ignore", invalid="ignore"):
        points = intersections[..., :2] / intersections[..., 2:]
    x_pairs = np.asarray(list(combinations(range(len(x_lines)), 2)))
    y_pairs = np.asarray(list(combinations(range(len(y_lines)), 2)))
    x_slots = x_pairs[:, [0, 1, 1, 0]][:, None, :]
    y_slots = y_pairs[:, [0, 0, 1, 1]][None, :, :]
    quads = points[x_slots, y_slots].reshape(-1, 4, 2)
    edges = np.roll(quads, -1, axis=1) - quads
    turns = edges[..., 0] * np.roll(edges[..., 1], -1, axis=1) - edges[..., 1] * np.roll(edges[..., 0], -1, axis=1)
    valid = np.isfinite(quads).all(axis=(1, 2)) & np.all(turns > 0, axis=1)
    pair_product_ids = np.arange(len(quads), dtype=np.int64)
    line_ranks = np.concatenate(
        (np.repeat(x_order[x_pairs], len(y_pairs), axis=0), np.tile(y_order[y_pairs], (len(x_pairs), 1))),
        axis=1,
    )
    quads = quads[valid]
    pair_product_ids = pair_product_ids[valid]
    line_ranks = line_ranks[valid]

    # Incoming family order is the covered-length rank. Centre sorting changes
    # geometric positions, so retain the original indices for evidence only.
    x_line_weakness = x_order.astype(np.float64) / (len(x_lines) - 1)
    y_line_weakness = y_order.astype(np.float64) / (len(y_lines) - 1)
    x_pair_weakness = x_line_weakness[x_pairs].mean(axis=1)
    y_pair_weakness = y_line_weakness[y_pairs].mean(axis=1)
    quad_weakness = (
        np.repeat(x_pair_weakness, len(y_pairs)) + np.tile(y_pair_weakness, len(x_pairs))
    ) / 2
    quad_weakness = quad_weakness[valid]

    available_convex_quads = len(quads)
    capped = available_convex_quads > settings.max_rectangles
    occupied_bins: int | None = None
    if not capped:
        selected_indices = np.arange(available_convex_quads)
    elif mode == "random":
        generator = np.random.default_rng(settings.seed)
        selected_indices = generator.choice(available_convex_quads, settings.max_rectangles, replace=False)
    elif mode == "stratified":
        bin_count = max(1, int(np.floor(settings.max_rectangles ** 0.25)))
        x_normalised = x_pairs / (len(x_lines) - 1)
        y_normalised = y_pairs / (len(y_lines) - 1)
        x_features = np.column_stack((x_normalised.mean(axis=1), np.diff(x_normalised, axis=1)[:, 0]))
        y_features = np.column_stack((y_normalised.mean(axis=1), np.diff(y_normalised, axis=1)[:, 0]))
        features = np.concatenate(
            (np.repeat(x_features, len(y_pairs), axis=0), np.tile(y_features, (len(x_pairs), 1))),
            axis=1,
        )[valid]
        bin_indices = np.clip(np.floor(features * bin_count).astype(int), 0, bin_count - 1)
        bin_keys = np.ravel_multi_index(bin_indices.T, (bin_count,) * 4)
        centres = (bin_indices + 0.5) / bin_count
        distances = np.sum((features - centres) ** 2, axis=1)
        if alpha == 0.0:
            # Preserve the prior selector's float64 distance ordering and its
            # computed-distance tie behaviour exactly at the baseline.
            order = np.lexsort((pair_product_ids, distances, bin_keys))
        else:
            priority = (1.0 - alpha) * (distances * bin_count**2) + alpha * quad_weakness
            order = np.lexsort((pair_product_ids, priority, bin_keys))
        ordered_keys = bin_keys[order]
        group_starts = np.r_[0, np.flatnonzero(np.diff(ordered_keys)) + 1]
        group_sizes = np.diff(np.r_[group_starts, len(order)])
        within_bin_rank = np.arange(len(order)) - np.repeat(group_starts, group_sizes)
        round_robin = np.lexsort((ordered_keys, within_bin_rank))
        selected_indices = order[round_robin[:settings.max_rectangles]]
        occupied_bins = len(group_starts)

    selected_quads = quads[selected_indices]
    selected_pair_product_ids = pair_product_ids[selected_indices]
    selected_line_ranks = line_ranks[selected_indices]
    selected_line_ranks_stats = (
        selected_line_ranks.tolist() if len(selected_line_ranks) <= _LINE_RANK_STATS_LIMIT else None
    )
    rectangles = []
    retained_pair_product_ids: list[int] = []
    for pair_product_id, quad in zip(selected_pair_product_ids, selected_quads, strict=True):
        if cv2.contourArea(quad.astype(np.float32)) >= 100:
            retained_pair_product_ids.append(int(pair_product_id))
            rectangles.append(cv2.getPerspectiveTransform(detector.UNIT_CORNERS, quad.astype(np.float32)))

    stats = {
        "available_convex_quads": available_convex_quads,
        "selected_quads": len(selected_quads),
        "area_retained_rectangles": len(rectangles),
        "occupied_bins": occupied_bins,
        "selected_pair_product_ids": selected_pair_product_ids.tolist(),
        "retained_pair_product_ids": retained_pair_product_ids,
        "mode": mode,
        "evidence_weight": alpha,
        "cue": _EVIDENCE_CUE,
        "selected_line_ranks": selected_line_ranks_stats,
    }
    return np.asarray(rectangles).reshape(-1, 3, 3), stats
