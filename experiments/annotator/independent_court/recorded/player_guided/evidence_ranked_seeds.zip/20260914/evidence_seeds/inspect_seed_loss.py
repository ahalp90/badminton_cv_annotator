"""Trace the two declared evidence-seed targets through saved selector lists."""

from __future__ import annotations

import argparse
import importlib
import sys
from dataclasses import replace
from itertools import combinations
from pathlib import Path

import numpy as np

from experiments.annotator.independent_court import detector

TEMPLATE_COUNT = len(detector.TEMPLATE_TRANSFORMS)
GX_ID = "gxBQ_window_00_frame_5"
AMATEUR_ID = "am2_window_00_frame_150"
GX_GENERATION = 6_476_322
AMATEUR_GENERATION = 214_039


def merged_lines(source: dict, settings: detector.Settings) -> tuple[tuple[np.ndarray, np.ndarray], tuple[int, int], np.ndarray]:
    """Rebuild detector working dimensions, scaled fragments and merged families."""
    width, height = source["dimensions"]["width"], source["dimensions"]["height"]
    resize = min(1.0, settings.max_dimension / max(width, height))
    size = (round(width * resize), round(height * resize))
    scale = np.asarray([width, height], dtype=np.float64) / size
    segments = np.asarray(source["segments_px"], dtype=np.float64) / np.tile(scale, 2)
    family_fn = detector._wide_line_families if settings.wide_families else detector._line_families
    families = family_fn(segments)
    lines = tuple(detector._merge_lines(family, settings) for family in families)
    return lines, size, scale


def corners(rectangles: np.ndarray, generation: int, scale: np.ndarray) -> np.ndarray:
    """Project one saved generation into native source pixels."""
    rectangle_index, template_index = divmod(generation, TEMPLATE_COUNT)
    assert 0 <= rectangle_index < len(rectangles)
    transform = rectangles[rectangle_index] @ detector.TEMPLATE_TRANSFORMS[template_index]
    projected, denominator = detector.project(transform[None], detector.CORNER_COURT_M)
    assert np.isfinite(projected).all() and np.all(denominator > 1e-6)
    return projected[0] * scale


def ranks(lines: tuple[np.ndarray, np.ndarray], size: tuple[int, int], pair_id: int) -> dict:
    """Calculate incoming covered-length ranks from centre-sorted line pairs."""
    x_lines, y_lines = lines
    width, height = size
    x_order = np.argsort(-(x_lines[:, 1] * height / 2 + x_lines[:, 2]) / x_lines[:, 0])
    y_order = np.argsort(-(y_lines[:, 0] * width / 2 + y_lines[:, 2]) / y_lines[:, 1])
    x_pairs, y_pairs = list(combinations(range(len(x_lines)), 2)), list(combinations(range(len(y_lines)), 2))
    x_pair, y_pair = divmod(pair_id, len(y_pairs))
    line_ranks = [int(x_order[index]) for index in x_pairs[x_pair]] + [int(y_order[index]) for index in y_pairs[y_pair]]
    counts = (len(x_lines), len(y_lines))
    normalised = [rank / (counts[0] - 1) for rank in line_ranks[:2]]
    normalised += [rank / (counts[1] - 1) for rank in line_ranks[2:]]
    return {
        "incoming_line_ranks": line_ranks,
        "x_line_ranks": line_ranks[:2],
        "y_line_ranks": line_ranks[2:],
        "family_line_counts": list(counts),
        "mean_normalised_rank": float(np.mean(normalised)),
    }


def memberships(arms: list[dict], pair_id: int) -> dict:
    """Report membership in every saved selected and area-retained list."""
    result = {}
    for arm in arms:
        selection = arm["seed_selection"]
        alpha = selection.get("evidence_weight", arm.get("evidence_weight"))
        name = f"new_alpha_{float(alpha):g}" if alpha is not None else f"old_{arm['mode']}"
        result[name] = {
            "selected": pair_id in selection["selected_pair_product_ids"],
            "area_retained": pair_id in selection["retained_pair_product_ids"],
        }
    return result


def main() -> None:
    """Reconstruct both fixed targets and save a path-free trace."""
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("gx-inputs", "amateur-inputs", "caps", "old-comparison-dir", "new-results-dir",
                   "prior-selector-dir", "trace-directory", "output"):
        parser.add_argument(f"--{option}", type=Path, required=True)
    args = parser.parse_args()

    sys.path.insert(0, str(args.trace_directory.resolve()))
    trace = importlib.import_module("run_trace")
    sys.path.insert(0, str(args.prior_selector_dir.resolve()))
    prior_select_rectangles = importlib.import_module("select_seeds").select_rectangles
    caps = trace.read(args.caps)
    cases = ((args.gx_inputs, GX_ID, True, "results"), (args.amateur_inputs, AMATEUR_ID, False, "controls/results"))
    records = []
    for input_path, case_id, full_gx, old_subdirectory in cases:
        source = next(case for case in trace.read(input_path)["cases"] if case["id"] == case_id)
        old = trace.read(args.old_comparison_dir / old_subdirectory / f"{case_id}.json.gz")
        new = trace.read(args.new_results_dir / "results" / f"{case_id}.json.gz")
        old_arms, new_arms = old["arms"], new["arms"]
        settings = detector.Settings(**old_arms[0]["settings"])
        lines, size, scale = merged_lines(source, settings)
        if full_gx:
            cap = next(record for record in caps["records"] if record["id"] == case_id)
            best = cap["all_pairs"]["best"]["max_corner_native_px"]
            generation, saved = GX_GENERATION, best["corners_px"]
            assert best["generation_id"] == generation
            uncapped = replace(settings, max_rectangles=settings.max_family_lines**4)
            rectangles, details = prior_select_rectangles(*lines, size, uncapped, "random")
            rectangle_index = generation // TEMPLATE_COUNT
            pair_id = int(details["retained_pair_product_ids"][rectangle_index])
        else:
            generation, saved = AMATEUR_GENERATION, old_arms[0]["final"]["candidates"][0]["corners_px"]
            rectangles, _ = prior_select_rectangles(*lines, size, settings, "random")
            rectangle_index = generation // TEMPLATE_COUNT
            pair_id = int(old_arms[0]["seed_selection"]["retained_pair_product_ids"][rectangle_index])
        reconstructed = corners(rectangles, generation, scale)
        np.testing.assert_allclose(reconstructed, saved, atol=1e-5, rtol=0)
        records.append({
            "case_id": case_id,
            "dimensions": source["dimensions"],
            "target_source": "caps all_pairs best max_corner_native_px" if full_gx else "old random final.candidates[0]",
            "generation_id": generation,
            "rectangle_index": rectangle_index,
            "template_index": generation % TEMPLATE_COUNT,
            "pair_product_id": pair_id,
            "corners_px": reconstructed.tolist(),
            **ranks(lines, size, pair_id),
            "presence": memberships(old_arms + new_arms, pair_id),
        })
    trace.write(args.output, {
        "schema": "evidence-seed-loss-trace/1", "labels_used_only_to_choose_targets": True,
        "template_count": TEMPLATE_COUNT,
        "corner_tolerance_px": 1e-5,
        "targets": records,
    })


if __name__ == "__main__":
    main()
