"""Exactness and evidence-priority smoke checks for diagnostic seed selection."""

from __future__ import annotations

import importlib.util
from itertools import combinations
from pathlib import Path

import numpy as np
from select_evidence_seeds import select_rectangles

from experiments.annotator.independent_court import detector

_PRIOR_SELECTOR_PATH = (
    Path(__file__).parents[2] / "20260913" / "seed_selection" / "select_seeds.py"
)


def _load_prior_selector():
    module_spec = importlib.util.spec_from_file_location("prior_select_seeds", _PRIOR_SELECTOR_PATH)
    if module_spec is None or module_spec.loader is None:
        raise RuntimeError(f"cannot load prior selector from {_PRIOR_SELECTOR_PATH}")
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    return module.select_rectangles


def synthetic_lines() -> tuple[np.ndarray, np.ndarray, tuple[int, int]]:
    """Return unsorted axis-aligned lines with several sub-100-pixel quads."""
    x_positions = np.array([300, 760, 95, 500, 100, 640], dtype=np.float64)
    y_positions = np.array([350, 95, 500, 100, 200], dtype=np.float64)
    x_lines = np.column_stack((np.ones(len(x_positions)), np.zeros(len(x_positions)), -x_positions))
    y_lines = np.column_stack((np.zeros(len(y_positions)), np.ones(len(y_positions)), -y_positions))
    return x_lines, y_lines, (800, 600)


def _assert_prior_parity(
    prior_select_rectangles,
    x_lines: np.ndarray,
    y_lines: np.ndarray,
    size: tuple[int, int],
    settings: detector.Settings,
    mode: str,
) -> None:
    expected_rectangles, expected_stats = prior_select_rectangles(x_lines, y_lines, size, settings, mode)
    rectangles, stats = select_rectangles(x_lines, y_lines, size, settings, mode, evidence_weight=0.0)
    np.testing.assert_array_equal(rectangles, expected_rectangles)
    assert stats["selected_pair_product_ids"] == expected_stats["selected_pair_product_ids"]
    assert stats["retained_pair_product_ids"] == expected_stats["retained_pair_product_ids"]
    assert stats["selected_line_ranks"]
    if settings.max_rectangles == 16 and mode == "stratified":
        assert stats["selected_line_ranks"][0] == [4, 0, 1, 3]


def _assert_alpha_one_small_example() -> None:
    """Check alpha-one order against a separately worked four-line example."""
    x_positions = np.array([100, 200, 300, 400], dtype=np.float64)
    y_positions = np.array([100, 200, 300, 400], dtype=np.float64)
    x_lines = np.column_stack((np.ones(4), np.zeros(4), -x_positions))
    y_lines = np.column_stack((np.zeros(4), np.ones(4), -y_positions))
    settings = detector.Settings(max_rectangles=20, seed=20260914)
    _, stats = select_rectangles(x_lines, y_lines, (500, 500), settings, "stratified", evidence_weight=1.0)

    # For four already-ranked lines and cap 20, bin_count=floor(20**.25)=2.
    # Pair-product IDs enumerate x pairs first, then y pairs.  Sorting the
    # four-dimensional bins by mean input rank gives this round-robin prefix.
    expected_ids = [0, 1, 3, 2, 6, 7, 9, 8, 18, 19, 21, 20, 12, 13, 15, 14, 5, 4, 11, 10]
    assert stats["selected_pair_product_ids"] == expected_ids

    # In each bin with multiple candidates, the first selected member has the
    # lower independently calculated mean input rank (for example IDs 3 then 5).
    pair_order = list(combinations(range(4), 2))
    expected_weakness = []
    for x_pair in pair_order:
        for y_pair in pair_order:
            expected_weakness.append((sum(x_pair) + sum(y_pair)) / 12)
    assert expected_weakness[3] < expected_weakness[5]
    assert expected_weakness[2] < expected_weakness[4]
    assert stats["selected_pair_product_ids"][2:4] == [3, 2]
    assert stats["selected_pair_product_ids"][16:18] == [5, 4]


def check() -> None:
    """Run geometry parity, priority, cap and validation checks."""
    prior_select_rectangles = _load_prior_selector()
    x_lines, y_lines, size = synthetic_lines()
    capped_settings = detector.Settings(max_rectangles=16, seed=20260914)
    uncapped_settings = detector.Settings(max_rectangles=10_000, seed=20260914)
    for settings in (capped_settings, uncapped_settings):
        for mode in ("random", "stratified"):
            _assert_prior_parity(prior_select_rectangles, x_lines, y_lines, size, settings, mode)

    _assert_alpha_one_small_example()

    rectangles, stats = select_rectangles(
        x_lines, y_lines, size, capped_settings, "stratified", evidence_weight=0.5,
    )
    repeated_rectangles, repeated_stats = select_rectangles(
        x_lines, y_lines, size, capped_settings, "stratified", evidence_weight=0.5,
    )
    np.testing.assert_array_equal(rectangles, repeated_rectangles)
    assert stats == repeated_stats
    selected_ids = stats["selected_pair_product_ids"]
    assert len(selected_ids) == capped_settings.max_rectangles
    assert len(selected_ids) == len(set(selected_ids))
    assert stats["selected_quads"] <= capped_settings.max_rectangles
    assert len(stats["selected_line_ranks"]) == len(selected_ids)
    assert all(len(line_ranks) == 4 for line_ranks in stats["selected_line_ranks"])
    assert stats["evidence_weight"] == 0.5
    assert stats["cue"] == "mean incoming covered-length rank"

    # A small-area first candidate proves the area gate runs after the fixed
    # pre-area cap and does not refill from the unselected population.
    close_positions = np.array([100, 102, 300, 500], dtype=np.float64)
    close_x_lines = np.column_stack((np.ones(4), np.zeros(4), -close_positions))
    close_y_lines = np.column_stack((np.zeros(4), np.ones(4), -close_positions))
    _, area_stats = select_rectangles(
        close_x_lines, close_y_lines, (600, 600), capped_settings, "stratified", evidence_weight=1.0,
    )
    assert area_stats["selected_quads"] == capped_settings.max_rectangles
    assert area_stats["area_retained_rectangles"] < area_stats["selected_quads"]

    for invalid_alpha in (-0.01, 1.01, np.nan, np.inf, -np.inf):
        try:
            select_rectangles(x_lines, y_lines, size, capped_settings, "stratified", invalid_alpha)
        except ValueError:
            pass
        else:
            raise AssertionError(f"accepted invalid evidence_weight={invalid_alpha}")
    try:
        select_rectangles(x_lines, y_lines, size, capped_settings, "unknown", 0.0)
    except ValueError:
        pass
    else:
        raise AssertionError("accepted unknown selection mode")
    print("evidence-seed smoke passed")


if __name__ == "__main__":
    check()
