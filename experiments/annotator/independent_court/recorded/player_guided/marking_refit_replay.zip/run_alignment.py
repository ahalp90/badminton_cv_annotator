"""Compare fixed scoring rules on frozen proposals and their multi-fragment refits."""
from __future__ import annotations

import argparse
import gzip
import json
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from camera_diagnostic import net_segments
from marking_score import alignment
from refine_fits import refine
from zone_net import player_fractions

from experiments.annotator.independent_court import detector, evaluate

SCHEMES = ('original', 'continuous_family', 'direct', 'direct_occlusion')


def read(path: Path) -> dict:
    return json.loads(gzip.decompress(path.read_bytes()))


def write(path: Path, data: dict) -> None:
    path.write_bytes(gzip.compress(json.dumps(data, allow_nan=False).encode(), mtime=0))


def geometry_valid(corners: np.ndarray, transform: np.ndarray, size: tuple[int, int]) -> bool:
    _, depth = detector.project(transform[None], detector.CORNER_COURT_M)
    edges = np.roll(corners, -1, axis=0) - corners
    turns = edges[:, 0] * np.roll(edges[:, 1], -1) - edges[:, 1] * np.roll(edges[:, 0], -1)
    span = np.minimum(corners.max(axis=0), np.array(size) - 1) - np.maximum(corners.min(axis=0), 0)
    return bool(np.isfinite(corners).all() and np.all(depth > 1e-6) and np.all(turns > 0)
                and np.all(span / size >= .15))


def evidence(corners: np.ndarray, case: dict, prepared: dict, candidate: dict) -> dict:
    width, height = prepared['native_size']
    size, scale = prepared['size'], prepared['native_scale']
    working_corners = corners / scale
    transform = cv2.getPerspectiveTransform(detector.CORNER_COURT_M, working_corners.astype(np.float32))
    if not geometry_valid(working_corners, transform, size):
        return {'eligible': False, 'reason': 'geometry'}
    feet_key = 'all_feet_px' if candidate['source_variant'] == 'all_people_net' else 'selected_pair_feet'
    feet = np.array(case[feet_key], dtype=float) / scale
    one, two = player_fractions(transform[None], feet)
    net, camera_error, _ = net_segments(corners, (width, height))
    if not np.isfinite(net).all():
        return {'eligible': False, 'reason': 'net_projection'}
    endpoints = detector.project(transform[None], detector.SEGMENTS_M)[0].reshape(12, 2, 2)
    direct = alignment(endpoints, prepared['segments'], size)
    occlusion = alignment(endpoints, prepared['segments'], size, prepared['boxes'])
    _, old_scores, means, counts = detector._score(transform[None], prepared['maps'], prepared['settings'], prepared['merged'])
    old_score = float(old_scores[0])
    samples, visible = detector._visible_samples(endpoints[None], size, 64)
    pixel_x = np.clip(samples[..., 0], 0, size[0] - 1).astype(int)
    pixel_y = np.clip(samples[..., 1], 0, size[1] - 1).astype(int)
    distances = prepared['maps'][np.repeat([0, 1], 6)[None, :, None], pixel_y, pixel_x]
    smooth = np.exp(-.5 * (distances / 2.) ** 2).mean(axis=-1) * visible
    continuous = float(np.mean([smooth[:, :6].sum() / max(visible[:, :6].sum(), 1),
                                smooth[:, 6:].sum() / max(visible[:, 6:].sum(), 1)]))
    samples, visible = detector._visible_samples((net / scale)[None], size, 48)
    pixel_x = np.clip(samples[..., 0], 0, size[0] - 1).astype(int)
    pixel_y = np.clip(samples[..., 1], 0, size[1] - 1).astype(int)
    support = np.exp(-.5 * (prepared['net_map'][0, pixel_y, pixel_x] / 4.) ** 2).mean(axis=-1) * visible
    net_score = float(support.sum() / max(visible.sum(), 1))
    base = bool(one[0] == 1 and two[0] >= .5 and camera_error <= .1)
    scores = {'original': (3 * old_score + net_score) / 4,
              'continuous_family': (3 * continuous + net_score) / 4,
              'direct': (3 * direct['score'] + net_score) / 4,
              'direct_occlusion': (3 * occlusion['score'] + net_score) / 4}
    eligible = {'original': base and old_score >= 0, 'continuous_family': base and old_score >= 0,
                'direct': base and old_score >= 0,
                'direct_occlusion': base and old_score >= 0}
    return {'eligible': True, 'scores': scores, 'scheme_eligible': eligible, 'net_score': net_score,
            'camera_error': float(camera_error), 'one_fraction': float(one[0]), 'two_fraction': float(two[0]),
            'old_floor_score': old_score, 'old_family_support': means[0].tolist(),
            'old_line_counts': counts[0].tolist(), 'direct': direct, 'direct_occlusion': occlusion}


def select(entries: list[dict], scheme: str, size: tuple[int, int], scale: np.ndarray) -> dict:
    indices = [index for index, entry in enumerate(entries) if entry['evidence']['eligible']
               and entry['evidence']['scheme_eligible'][scheme] and not entry['extra_gallery_probe']]
    indices.sort(key=lambda index: -entries[index]['evidence']['scores'][scheme])
    retained = []
    for index in indices:
        corners = np.asarray(entries[index]['corners_px']) / scale
        if any(np.linalg.norm(corners - np.asarray(entries[previous]['corners_px']) / scale, axis=1).max() <= 12
               for previous in retained):
            continue
        retained.append(index)
        if len(retained) == 32:
            break
    gap = None
    if len(retained) > 1:
        gap = entries[retained[0]]['evidence']['scores'][scheme] - entries[retained[1]]['evidence']['scores'][scheme]
    candidates = [detector.Candidate(np.asarray(entries[index]['corners_px']) / scale,
                                    entries[index]['evidence']['scores'][scheme], (0., 0.), (0, 0))
                  for index in retained]
    separate = bool(candidates) and detector._separate_court(candidates, size)
    accepted = bool(candidates) and not separate and (gap is None or gap >= .035)
    return {'indices': retained, 'accepted': accepted, 'gap': gap,
            'reason': 'accepted' if accepted else 'ambiguous' if candidates else 'unsupported'}


def prepare_case(case: dict) -> dict:
    width, height = case['dimensions']['width'], case['dimensions']['height']
    factor = min(1., 960 / max(width, height))
    size = (round(width * factor), round(height * factor))
    scale = np.array([width, height]) / size
    segments = np.array(case['segments_px'])
    families = detector._wide_line_families(segments / np.tile(scale, 2))
    settings = detector.Settings(wide_families=True, min_supported_lines=3)
    prepared = {'native_size': (width, height), 'size': size, 'native_scale': scale,
                'segments': segments / np.tile(scale, 2), 'settings': settings,
                'maps': detector._distance_maps(families, size),
                'merged': tuple(detector._merge_lines(family, settings) for family in families),
                'net_map': detector._distance_maps((segments / np.tile(scale, 2),) * 2, size),
                'boxes': np.asarray(case['bbox_px'], dtype=float).reshape(-1, 4) / np.tile(scale, 2)}
    return prepared


def run_case(case: dict) -> dict:
    cv2.setNumThreads(1)
    prepared = prepare_case(case)
    width, height = prepared['native_size']
    size, scale = prepared['size'], prepared['native_scale']
    segments = np.asarray(case['segments_px'])
    entries = []
    for source_index, candidate in enumerate(case['candidates']):
        original = np.asarray(candidate['corners_px'])
        fitted, history = refine(original, segments, (width, height))
        for stage, corners in [('original', original), ('refit', fitted)]:
            entries.append({'source_index': source_index, 'original_rank': candidate['original_rank'],
                            'extra_gallery_probe': candidate['extra_gallery_probe'], 'stage': stage,
                            'corners_px': corners.tolist(), 'history': history if stage == 'refit' else [],
                            'evidence': evidence(corners, case, prepared, candidate)})
    selections = {scheme: select(entries, scheme, size, scale) for scheme in SCHEMES}
    pairs = []
    for source_index, candidate in enumerate(case['candidates']):
        original, refit_index = 2 * source_index, 2 * source_index + 1
        choices = {}
        for scheme in SCHEMES:
            after = entries[refit_index]['evidence']
            before = entries[original]['evidence']
            use_refit = after['eligible'] and after['scheme_eligible'][scheme]
            use_refit = use_refit and (not before['eligible'] or not before['scheme_eligible'][scheme]
                                      or after['scores'][scheme] > before['scores'][scheme] + 1e-9)
            choices[scheme] = refit_index if use_refit else original
        pairs.append({'source_index': source_index, 'choices': choices})
    print(case['id'], 'candidates', len(case['candidates']), 'selected',
          {key: value['indices'][:1] for key, value in selections.items()}, flush=True)
    return {'id': case['id'], 'entries': entries, 'selections': selections, 'pairs': pairs}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--ids', nargs='*')
    args = parser.parse_args()
    packed = read(args.inputs)
    cases = [case for case in packed['cases'] if not args.ids or case['id'] in args.ids]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        records = list(pool.map(run_case, cases))
    # Labels are first accessed after all geometry, scoring and selection finish.
    for record, case in zip(records, cases):
        reference = packed['references'][record['id']]
        for entry in record['entries']:
            entry['metrics'] = evaluate._metrics(np.asarray(entry['corners_px']), reference,
                                                 case['dimensions']['width'], case['dimensions']['height'])
    write(args.output, {'schemes': list(SCHEMES), 'development_data': True,
                        'acceptance_gap_is_unrecalibrated': True, 'records': records})


if __name__ == '__main__':
    main()
