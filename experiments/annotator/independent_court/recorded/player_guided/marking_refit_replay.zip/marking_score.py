"""Measure each projected marking against finite, similarly directed line pieces.

All coordinates are working-image pixels with a maximum dimension of 960.
The caller supplies projected court segments and observed fragments. No labels
or image-axis family classification enter this score.
"""
from __future__ import annotations

import numpy as np

from experiments.annotator.independent_court.detector import _visible_samples

SAMPLE_COUNT = 64
ANGLE_TOLERANCE_DEG = 5.0
DISTANCE_SIGMA = 2.0
SUPPORT_DISTANCE = 4.0
MIN_OBSERVED_SAMPLES = 8
MIN_LINE_SUPPORT = 0.55


def alignment(
    projected_segments: np.ndarray,
    observed_segments: np.ndarray,
    size: tuple[int, int],
    boxes: np.ndarray | None = None,
) -> dict:
    """Return continuous alignment and binary coverage for each court marking.

    :param projected_segments: (12, 2, 2) painted court segments in image pixels.
    :param observed_segments: (fragments, 4) finite XYXY line detections.
    :param size: Working image width and height.
    :param boxes: Optional (people, 4) observed boxes to exclude from samples.
    :return: Equal-family score, physical-line counts and per-marking evidence.
    """
    samples, in_frame = _visible_samples(projected_segments[None], size, SAMPLE_COUNT)
    samples = samples[0]
    usable = np.broadcast_to(in_frame[0, :, None], (12, SAMPLE_COUNT)).copy()
    if boxes is not None and len(boxes):
        inside = ((samples[:, :, None] >= boxes[None, None, :, :2]).all(axis=-1)
                  & (samples[:, :, None] <= boxes[None, None, :, 2:]).all(axis=-1))
        usable &= ~inside.any(axis=-1)
    observed = observed_segments.reshape(-1, 2, 2)
    observed_vectors = observed[:, 1] - observed[:, 0]
    length_squared = np.square(observed_vectors).sum(axis=1)
    directions = observed_vectors / np.sqrt(length_squared)[:, None]
    court_vectors = projected_segments[:, 1] - projected_segments[:, 0]
    court_directions = court_vectors / np.linalg.norm(court_vectors, axis=1)[:, None]
    compatible = np.abs(court_directions @ directions.T) >= np.cos(np.deg2rad(ANGLE_TOLERANCE_DEG))
    distances = np.full((12, SAMPLE_COUNT), np.inf)
    for marking_index in range(12):
        chosen = compatible[marking_index]
        if not chosen.any():
            continue
        starts = observed[chosen, 0]
        vectors = observed_vectors[chosen]
        delta = samples[marking_index, :, None] - starts[None]
        fraction = np.einsum('sfd,fd->sf', delta, vectors) / length_squared[chosen][None]
        nearest = starts[None] + np.clip(fraction, 0, 1)[..., None] * vectors[None]
        distances[marking_index] = np.linalg.norm(samples[marking_index, :, None] - nearest, axis=-1).min(axis=1)
    count = usable.sum(axis=1)
    visible = count >= MIN_OBSERVED_SAMPLES
    support = ((distances <= SUPPORT_DISTANCE) & usable).sum(axis=1) / np.maximum(count, 1)
    continuous = (np.exp(-0.5 * np.square(distances / DISTANCE_SIGMA)) * usable).sum(axis=1) / np.maximum(count, 1)
    support *= visible
    continuous *= visible
    family_scores = np.array([continuous[:6].sum() / max(visible[:6].sum(), 1),
                              continuous[6:].sum() / max(visible[6:].sum(), 1)])
    supported = support >= MIN_LINE_SUPPORT
    # The far and near centre sections share one physical x-line identity.
    physical_x = [supported[0], supported[1], supported[2] or supported[3], supported[4], supported[5]]
    physical_counts = [int(sum(physical_x)), int(supported[6:].sum())]
    medians = [float(np.median(distances[index, usable[index]])) if visible[index] else None
               for index in range(12)]
    medians = [value if value is None or np.isfinite(value) else None for value in medians]
    return {'score': float(family_scores.mean()), 'family_scores': family_scores.tolist(),
            'physical_supported_lines': physical_counts, 'visible': visible.tolist(),
            'sample_counts': count.tolist(), 'support_fraction': support.tolist(),
            'continuous_per_marking': continuous.tolist(), 'median_distance_px': medians}
