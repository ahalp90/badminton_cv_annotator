"""Score whether finite detected line fragments are explained by a court template."""
from __future__ import annotations

import numpy as np

from experiments.annotator.independent_court.detector import _visible_samples

RAW_SAMPLE_COUNT = 16
ANGLE_TOLERANCE_DEG = 5.0
DISTANCE_SIGMA_PX = 2.0
EXPLAINED_DISTANCE_PX = 4.0
COURT_X_BOUNDS_M = (-0.04, 6.14)
COURT_Y_BOUNDS_M = (-0.04, 13.44)


def reverse_alignment(
    projected_segments: np.ndarray,
    observed_segments: np.ndarray,
    homography: np.ndarray,
    size: tuple[int, int],
    boxes: np.ndarray | None = None,
) -> dict:
    """Measure how much finite observed line length the projected template explains.

    :param projected_segments: (12, 2, 2) painted markings in working-image pixels.
    :param observed_segments: (fragments, 4) finite XYXY detections in working-image pixels.
    :param homography: (3, 3) court-metres to working-image-pixels transform.
    :param size: Working image width and height.
    :param boxes: Optional (people, 4) image boxes whose samples are excluded.
    :return: Weighted score, eligible length and unexplained-fragment diagnostics.
    """
    observed = np.asarray(observed_segments).reshape(-1, 2, 2)
    raw_samples, visible = _visible_samples(observed[None], size, RAW_SAMPLE_COUNT)
    raw_samples = raw_samples[0]
    visible = visible[0]
    clipped_lengths_px = np.linalg.norm(raw_samples[:, -1] - raw_samples[:, 0], axis=1)
    sample_weights_px = clipped_lengths_px[:, None] / RAW_SAMPLE_COUNT

    inverse_homography = np.linalg.inv(homography)
    samples_h = np.concatenate((raw_samples, np.ones((*raw_samples.shape[:-1], 1))), axis=-1)
    court_h = np.einsum("ij,nkj->nki", inverse_homography, samples_h)
    homogeneous_depth = court_h[..., 2]
    with np.errstate(divide="ignore", invalid="ignore"):
        court_samples_m = court_h[..., :2] / homogeneous_depth[..., None]
    finite_world = np.isfinite(court_samples_m).all(axis=-1)
    positive_depth = homogeneous_depth > 0
    inside_court = (
        (court_samples_m[..., 0] >= COURT_X_BOUNDS_M[0])
        & (court_samples_m[..., 0] <= COURT_X_BOUNDS_M[1])
        & (court_samples_m[..., 1] >= COURT_Y_BOUNDS_M[0])
        & (court_samples_m[..., 1] <= COURT_Y_BOUNDS_M[1])
    )

    inside_boxes = np.zeros(raw_samples.shape[:2], dtype=bool)
    if boxes is not None and len(boxes):
        boxes = np.asarray(boxes)
        inside_boxes = (
            (raw_samples[:, :, None] >= boxes[None, None, :, :2])
            & (raw_samples[:, :, None] <= boxes[None, None, :, 2:])
        ).all(axis=-1).any(axis=-1)

    projected_vectors = projected_segments[:, 1] - projected_segments[:, 0]
    projected_length_squared = np.square(projected_vectors).sum(axis=1)
    projected_directions = projected_vectors / np.sqrt(projected_length_squared)[:, None]
    observed_vectors = observed[:, 1] - observed[:, 0]
    observed_length_squared = np.square(observed_vectors).sum(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        observed_directions = observed_vectors / np.sqrt(observed_length_squared)[:, None]
    compatible = (
        np.abs(observed_directions @ projected_directions.T)
        >= np.cos(np.deg2rad(ANGLE_TOLERANCE_DEG))
    )
    compatible_piece = compatible.any(axis=1)

    point_delta = raw_samples[:, :, None, :] - projected_segments[None, None, :, 0, :]
    with np.errstate(divide="ignore", invalid="ignore"):
        fraction = np.einsum("nmpd,pd->nmp", point_delta, projected_vectors) / projected_length_squared
    nearest_points = (
        projected_segments[None, None, :, 0, :]
        + np.clip(fraction, 0, 1)[..., None] * projected_vectors[None, None, :, :]
    )
    distances_px = np.linalg.norm(raw_samples[:, :, None, :] - nearest_points, axis=-1)
    distances_px = np.where(compatible[:, None, :], distances_px, np.inf)
    nearest_distance_px = distances_px.min(axis=2)
    gaussian = np.exp(-0.5 * np.square(nearest_distance_px / DISTANCE_SIGMA_PX))

    eligible = (
        visible[:, None]
        & finite_world
        & positive_depth
        & inside_court
        & ~inside_boxes
        & compatible_piece[:, None]
    )
    eligible_sample_weights_px = np.where(eligible, sample_weights_px, 0.0)
    eligible_length_px = float(eligible_sample_weights_px.sum())
    unexplained_weights_px = (eligible_sample_weights_px * (1.0 - gaussian)).sum(axis=1)
    if eligible_length_px == 0.0:
        score = 0.0
        explained_fraction = 0.0
    else:
        score = float((eligible_sample_weights_px * gaussian).sum() / eligible_length_px)
        explained_fraction = float(
            (eligible_sample_weights_px * (nearest_distance_px <= EXPLAINED_DISTANCE_PX)).sum()
            / eligible_length_px
        )

    sorted_indices = np.argsort(-unexplained_weights_px, kind="stable")
    top_indices = [
        int(index)
        for index in sorted_indices[:5]
        if unexplained_weights_px[index] > 0.0
    ]
    top_weights_px = [float(unexplained_weights_px[index]) for index in top_indices]
    return {
        "score": score,
        "eligible_length_px": eligible_length_px,
        "explained_fraction": explained_fraction,
        "top_unexplained_fragment_indices": top_indices,
        "top_unexplained_fragment_weights_px": top_weights_px,
    }
