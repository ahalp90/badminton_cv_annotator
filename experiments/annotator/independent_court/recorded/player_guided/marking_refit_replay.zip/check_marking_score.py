"""Direct synthetic smoke checks for the finite marking alignment score."""
from __future__ import annotations

import cv2
import numpy as np
from marking_score import alignment

from experiments.annotator.independent_court.detector import (
    CORNER_COURT_M,
    SEGMENTS_M,
    project,
)

IMAGE_SIZE = (960, 720)
BASE_CORNERS = np.array(
    [[120.0, 80.0], [840.0, 110.0], [780.0, 650.0], [140.0, 680.0]],
    dtype=np.float32,
)
# This quarter-turn view makes the court's constant-x lines almost horizontal.
OBLIQUE_CORNERS = np.array(
    [[100.0, 100.0], [100.0, 650.0], [850.0, 600.0], [850.0, 150.0]],
    dtype=np.float32,
)
DISPLACEMENT_PX = np.array([15.0, -8.0])
MISSING_MARKING = 0
MISSING_START = 0.40
MISSING_END = 0.60
WHOLE_MASKED_MARKING = 6
LONG_MARKING = 0
PERPENDICULAR_HALF_LENGTH_PX = 10.0


def projected_segments(corners: np.ndarray) -> np.ndarray:
    """Project the shared metre-space template into a synthetic image."""
    homography = cv2.getPerspectiveTransform(CORNER_COURT_M, corners)
    projected, _ = project(homography[None], SEGMENTS_M)
    return projected[0].reshape(12, 2, 2)


def remove_middle_chunk(
    segments: np.ndarray,
    marking_index: int,
    fraction_start: float,
    fraction_end: float,
) -> np.ndarray:
    """Replace one observed marking with two finite fragments around a gap."""
    observed: list[np.ndarray] = []
    for index, (point_a, point_b) in enumerate(segments):
        if index != marking_index:
            observed.append(np.concatenate((point_a, point_b)))
            continue
        vector = point_b - point_a
        gap_start = point_a + fraction_start * vector
        gap_end = point_a + fraction_end * vector
        observed.extend((
            np.concatenate((point_a, gap_start)),
            np.concatenate((gap_end, point_b)),
        ))
    return np.asarray(observed)


def middle_chunk_box(
    segment: np.ndarray,
    fraction_start: float,
    fraction_end: float,
) -> np.ndarray:
    """Return the tight axis-aligned box spanning the removed middle chunk."""
    point_a, point_b = segment
    vector = point_b - point_a
    gap_start = point_a + fraction_start * vector
    gap_end = point_a + fraction_end * vector
    return np.concatenate((np.minimum(gap_start, gap_end), np.maximum(gap_start, gap_end)))


def segment_box(segment: np.ndarray) -> np.ndarray:
    """Return the tight box enclosing a whole projected marking."""
    return np.concatenate((segment.min(axis=0), segment.max(axis=0)))


def perpendicular_crossings(segment: np.ndarray) -> np.ndarray:
    """Make short perpendicular fragments crossing one long projected marking."""
    point_a, point_b = segment
    direction = point_b - point_a
    perpendicular = np.array([-direction[1], direction[0]]) / np.linalg.norm(direction)
    fragments = []
    for fraction in np.linspace(0.1, 0.9, 9):
        crossing = point_a + fraction * direction
        half_fragment = PERPENDICULAR_HALF_LENGTH_PX * perpendicular
        fragments.append(np.concatenate((crossing - half_fragment, crossing + half_fragment)))
    return np.asarray(fragments)


def image_angle_from_horizontal(segments: np.ndarray) -> np.ndarray:
    """Return unoriented line angles in degrees from the horizontal axis."""
    vectors = segments[:, 1] - segments[:, 0]
    angles = np.abs(np.degrees(np.arctan2(vectors[:, 1], vectors[:, 0])))
    return np.minimum(angles, 180.0 - angles)


def main() -> None:
    projected = projected_segments(BASE_CORNERS)
    observed = projected.reshape(-1, 4)

    exact = alignment(projected, observed, IMAGE_SIZE)
    assert np.isclose(exact["score"], 1.0)
    assert exact["physical_supported_lines"] == [5, 6]

    displaced = alignment(projected + DISPLACEMENT_PX, observed, IMAGE_SIZE)
    assert displaced["score"] < exact["score"]

    reversed_observed = observed.reshape(-1, 2, 2)[:, ::-1].reshape(-1, 4)
    reversed_result = alignment(projected, reversed_observed, IMAGE_SIZE)
    for key in ("physical_supported_lines", "visible", "sample_counts"):
        assert reversed_result[key] == exact[key]
    for key in ("score", "family_scores", "support_fraction", "continuous_per_marking", "median_distance_px"):
        np.testing.assert_allclose(reversed_result[key], exact[key], rtol=0.0, atol=1e-12)

    oblique = projected_segments(OBLIQUE_CORNERS)
    oblique_result = alignment(oblique, oblique.reshape(-1, 4), IMAGE_SIZE)
    assert np.isclose(oblique_result["score"], 1.0)
    assert np.all(image_angle_from_horizontal(oblique[:6]) < 10.0)

    fragmented = remove_middle_chunk(projected, MISSING_MARKING, MISSING_START, MISSING_END)
    fragmented_result = alignment(projected, fragmented, IMAGE_SIZE)
    covered_result = alignment(
        projected,
        fragmented,
        IMAGE_SIZE,
        np.asarray([middle_chunk_box(projected[MISSING_MARKING], MISSING_START, MISSING_END)]),
    )
    assert (
        covered_result["continuous_per_marking"][MISSING_MARKING]
        > fragmented_result["continuous_per_marking"][MISSING_MARKING]
    )

    whole_masked_result = alignment(
        projected,
        observed,
        IMAGE_SIZE,
        np.asarray([segment_box(projected[WHOLE_MASKED_MARKING])]),
    )
    assert not whole_masked_result["visible"][WHOLE_MASKED_MARKING]
    assert whole_masked_result["support_fraction"][WHOLE_MASKED_MARKING] == 0.0
    assert whole_masked_result["physical_supported_lines"][1] < exact["physical_supported_lines"][1]

    crossing_result = alignment(
        projected,
        perpendicular_crossings(projected[LONG_MARKING]),
        IMAGE_SIZE,
    )
    assert crossing_result["support_fraction"][LONG_MARKING] < 0.5

    print("marking score synthetic checks: PASS")


if __name__ == "__main__":
    main()
