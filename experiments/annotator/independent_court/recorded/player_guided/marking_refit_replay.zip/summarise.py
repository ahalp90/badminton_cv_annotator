"""Summarise frozen selection results; labels are used here only for evaluation."""
from pathlib import Path

from run_alignment import read, write

ROOT = Path(__file__).parent
results = read(ROOT / 'reverse_results.json.gz')
cross = read(ROOT / 'cross_frame_reverse.json.gz')
summary = {'development_frames': 20, 'primary_candidates': 357, 'extra_gallery_probes': 1,
           'corner_cutoff_px': 15, 'visible_change_deadband_px': .1,
           'coordinate_system': '1280x720', 'acceptance_gap_unrecalibrated': .035,
           'schemes': {}, 'cross_frame': {}, 'availability': []}
for scheme in results['schemes']:
    counts = {'accurate_tops': 0, 'correct_accepts': 0, 'wrong_accepts': 0}
    paired = {population: {'better': 0, 'worse': 0, 'unchanged': 0} for population in ['tops', 'all']}
    for record in results['records']:
        selection = record['selections'][scheme]
        if selection['indices']:
            top = record['entries'][selection['indices'][0]]
            accurate = top['metrics']['corner_max_error_px'] <= 15
            counts['accurate_tops'] += accurate
            counts['correct_accepts' if accurate else 'wrong_accepts'] += selection['accepted']
        for population in ['tops', 'all']:
            pairs = record['pairs'][:1] if population == 'tops' else record['pairs']
            for pair in pairs:
                before = record['entries'][2 * pair['source_index']]
                if before['extra_gallery_probe']:
                    continue
                chosen = record['entries'][pair['choices'][scheme]]
                delta = chosen['metrics']['landmark_rms_px'] - before['metrics']['landmark_rms_px']
                key = 'better' if delta < -.1 else 'worse' if delta > .1 else 'unchanged'
                paired[population][key] += 1
    summary['schemes'][scheme] = {'pool': counts, 'paired': paired}
for record in results['records']:
    errors = [entry['metrics']['corner_max_error_px'] for entry in record['entries'] if not entry['extra_gallery_probe']]
    summary['availability'].append({'id': record['id'], 'best_corner_error_px': min(errors) if errors else None})
for window in cross['records']:
    rows = {}
    for scheme, selection in window['selections'].items():
        if selection['indices']:
            top = window['entries'][selection['indices'][0]]
            rows[scheme] = {'worst_corner_error_px': max(item['corner_max_error_px'] for item in top['metrics'].values()),
                            'worst_visible_rms_px': max(item['landmark_rms_px'] for item in top['metrics'].values()),
                            'accepted': selection['accepted']}
    summary['cross_frame'][window['window']] = rows
write(ROOT / 'summary.json.gz', summary)
print(summary['schemes'])
