"""Add observed-to-template coverage to frozen forward-alignment measurements."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import cv2
import numpy as np
from reverse_score import reverse_alignment
from run_alignment import prepare_case, read, select, write

from experiments.annotator.independent_court import detector

REVERSE_SCHEMES = ('bidirectional', 'bidirectional_occlusion')


def add_reverse_evidence(corners: np.ndarray, prepared: dict, observed: dict) -> dict:
    if not observed['eligible']:
        return observed
    transform = cv2.getPerspectiveTransform(detector.CORNER_COURT_M,
                                            (corners / prepared['native_scale']).astype(np.float32))
    segments = detector.project(transform[None], detector.SEGMENTS_M)[0].reshape(12, 2, 2)
    for name, forward_name, boxes in [('bidirectional', 'direct', None),
                                      ('bidirectional_occlusion', 'direct_occlusion', prepared['boxes'])]:
        reverse = reverse_alignment(segments, prepared['segments'], transform, prepared['size'], boxes)
        forward_score, reverse_score = observed[forward_name]['score'], reverse['score']
        total = forward_score + reverse_score
        harmonic = 2 * forward_score * reverse_score / total if total else 0.
        observed[name] = {'forward': forward_score, 'reverse': reverse, 'harmonic_score': harmonic}
        observed['scores'][name] = (3 * harmonic + observed['net_score']) / 4
        observed['scheme_eligible'][name] = observed['scheme_eligible']['original']
    return observed


def run_case(job: dict) -> dict:
    cv2.setNumThreads(1)
    case, record = job['case'], job['record']
    prepared = prepare_case(case)
    for entry in record['entries']:
        entry['evidence'] = add_reverse_evidence(np.asarray(entry['corners_px']), prepared, entry['evidence'])
    for name in REVERSE_SCHEMES:
        record['selections'][name] = select(record['entries'], name, prepared['size'], prepared['native_scale'])
        for pair in record['pairs']:
            before_index, after_index = 2 * pair['source_index'], 2 * pair['source_index'] + 1
            before, after = record['entries'][before_index]['evidence'], record['entries'][after_index]['evidence']
            keep = after['eligible'] and after['scheme_eligible'][name]
            keep = keep and (not before['eligible'] or not before['scheme_eligible'][name]
                             or after['scores'][name] > before['scores'][name] + 1e-9)
            pair['choices'][name] = after_index if keep else before_index
    print(case['id'], {name: record['selections'][name]['indices'][:1] for name in REVERSE_SCHEMES}, flush=True)
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    packed = read(args.inputs)
    cases = {case['id']: case for case in packed['cases']}
    frozen = read(args.results)
    jobs = [{'case': cases[record['id']], 'record': record} for record in frozen['records']]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        records = list(pool.map(run_case, jobs))
    write(args.output, {'schemes': frozen['schemes'] + list(REVERSE_SCHEMES),
                       'development_data': True, 'acceptance_gap_is_unrecalibrated': True, 'records': records})


if __name__ == '__main__':
    main()
