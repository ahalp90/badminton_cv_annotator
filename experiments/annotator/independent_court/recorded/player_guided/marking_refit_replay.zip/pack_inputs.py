"""Package the frozen follow-up cases for the marking-refit runner."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Any

SCORE_CUTOFF = 0.2
SHORT_EXPERIMENT = "fits_short_full_search"
ORIGINAL_EXPERIMENT = "fits_original_people_net"
AM1_EXPERIMENT = "fits_original_full_search"
SHORT_VARIANT = "motion_net"
PEOPLE_VARIANT = "all_people_net"
AM1_VARIANT = "motion_net"
EXTRA_CASE_ID = "letterboxed_short_frame_58"
EXTRA_EXPERIMENT = "fits_short_motion"
EXTRA_VARIANT = "motion_floor"


def read_json(path: Path) -> Any:
    """Read one repository JSON gzip file."""
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        return json.load(stream)


def write_json(path: Path, value: dict[str, Any]) -> None:
    """Write deterministic JSON gzip output."""
    encoded = json.dumps(value, allow_nan=False, separators=(",", ":")).encode("utf-8")
    path.write_bytes(gzip.compress(encoded, mtime=0))


def source_result(run_root: Path, experiment: str, variant: str | None = None) -> dict[str, dict[str, Any]]:
    """Index saved fit records by case ID and, when needed, variant."""
    records = read_json(run_root / experiment / "results.json.gz")["records"]
    selected: dict[str, dict[str, Any]] = {}
    for record in records:
        if variant is not None and record.get("variant") != variant:
            continue
        case_id = record["id"]
        if case_id in selected:
            raise ValueError(f"duplicate saved result for {case_id} in {experiment}")
        selected[case_id] = record
    return selected


def source_windows(run_root: Path, population: str) -> dict[str, dict[str, Any]]:
    """Load people windows from the short or original manifest."""
    directory = run_root / f"people_{population}"
    manifest = read_json(directory / "manifest.json.gz")
    windows: dict[str, dict[str, Any]] = {}
    for item in manifest["windows"]:
        record = read_json(directory / item["record"])
        window_id = record["id"]
        if window_id in windows:
            raise ValueError(f"duplicate people window {window_id}")
        windows[window_id] = record
    return windows


def choose_source_boxes(case_id: str, window: dict[str, Any]) -> dict[str, Any]:
    """Return the nearest sampled detections for one anchor case."""
    _, frame_text = case_id.rsplit("_frame_", 1)
    anchor_frame = int(frame_text)
    anchors = window["anchor_images"]
    anchor_indices = [index for index, anchor in enumerate(anchors) if anchor["frame_index"] == anchor_frame]
    if len(anchor_indices) != 1:
        raise ValueError(f"expected one anchor image for {case_id}, found {len(anchor_indices)}")
    anchor_index = anchor_indices[0]
    chosen_index, chosen_sample = min(
        enumerate(window["samples"]),
        key=lambda item: (abs(item[1]["frame_index"] - anchor_frame), item[1]["frame_index"], item[0]),
    )
    bboxes = chosen_sample["bboxes"]
    scores = chosen_sample["scores"]
    if len(bboxes) != len(scores):
        raise ValueError(f"bbox/score length mismatch for {case_id}")
    retained_boxes = []
    for bbox, score in zip(bboxes, scores):
        if score <= SCORE_CUTOFF:
            continue
        if len(bbox) != 4:
            raise ValueError(f"bbox is not XYXY for {case_id}")
        retained_boxes.append(bbox)
    return {
        "bbox_px": retained_boxes,
        "anchor_index": anchor_index,
        "anchor_frame_index": anchor_frame,
        "bbox_frame_index": chosen_sample["frame_index"],
        "bbox_sample_index": chosen_index,
    }


def candidate_rows(record: dict[str, Any], experiment: str, variant: str, extra: bool = False) -> list[dict[str, Any]]:
    """Expose every saved candidate with stable source metadata."""
    rows = []
    for original_rank, candidate in enumerate(record["candidates"]):
        corners = candidate["corners_px"]
        if len(corners) != 4 or any(len(point) != 2 for point in corners):
            raise ValueError(f"candidate corners are not 4x2 for {record['id']}")
        row = {
            "corners_px": corners,
            "original_score": candidate["score"],
            "original_rank": original_rank,
            "source_variant": variant,
            "source_experiment": experiment,
            "extra_gallery_probe": extra,
        }
        rows.append(row)
    return rows


def build_case(
    frozen_case: dict[str, Any],
    primary: dict[str, Any],
    primary_experiment: str,
    primary_variant: str,
    window: dict[str, Any],
    extra: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build one case row and its separately stored reference."""
    source_boxes = choose_source_boxes(frozen_case["id"], window)
    candidates = candidate_rows(primary, primary_experiment, primary_variant)
    if extra is not None:
        candidates.extend(candidate_rows(extra, EXTRA_EXPERIMENT, EXTRA_VARIANT, extra=True)[:1])
    case = {
        "id": frozen_case["id"],
        "dimensions": frozen_case["dimensions"],
        "segments_px": frozen_case["segments_px"],
        "all_feet_px": frozen_case["all_feet_px"],
        "selected_pair_feet": frozen_case["selected_pair_feet"],
        "bbox_px": source_boxes["bbox_px"],
        "anchor_index": source_boxes["anchor_index"],
        "anchor_frame_index": source_boxes["anchor_frame_index"],
        "bbox_frame_index": source_boxes["bbox_frame_index"],
        "bbox_sample_index": source_boxes["bbox_sample_index"],
        "candidates": candidates,
        "primary_accepted": primary["accepted"],
        "primary_reason": primary["reason"],
    }
    return case, frozen_case["reference"]


def pack(run_root: Path) -> dict[str, Any]:
    """Create the marking-refit input package in frozen follow-up order."""
    frozen = read_json(run_root / "followup_cases.json.gz")
    frozen_cases = frozen["cases"]
    if len(frozen_cases) != 20 or frozen["case_count"] != 20:
        raise ValueError("follow-up input does not contain exactly 20 cases")

    short_results = source_result(run_root, SHORT_EXPERIMENT, SHORT_VARIANT)
    people_results = source_result(run_root, ORIGINAL_EXPERIMENT, PEOPLE_VARIANT)
    am1_results = source_result(run_root, AM1_EXPERIMENT, AM1_VARIANT)
    short_windows = source_windows(run_root, "short")
    original_windows = source_windows(run_root, "original")
    extra = read_json(run_root / EXTRA_EXPERIMENT / f"{EXTRA_CASE_ID}__{EXTRA_VARIANT}.json.gz")

    cases = []
    references: dict[str, Any] = {}
    for frozen_case in frozen_cases:
        case_id = frozen_case["id"]
        is_short = frozen_case["diagnostic_population"] == "short"
        if is_short:
            primary_experiment, primary_variant = SHORT_EXPERIMENT, SHORT_VARIANT
            primary = short_results.get(case_id)
            windows = short_windows
        elif case_id in am1_results:
            primary_experiment, primary_variant = AM1_EXPERIMENT, AM1_VARIANT
            primary = am1_results[case_id]
            windows = original_windows
        else:
            primary_experiment, primary_variant = ORIGINAL_EXPERIMENT, PEOPLE_VARIANT
            primary = people_results.get(case_id)
            windows = original_windows
        if primary is None:
            raise KeyError(f"missing primary fit result for {case_id}")
        window_id = case_id.rsplit("_frame_", 1)[0]
        window = windows.get(window_id)
        if window is None:
            raise KeyError(f"missing people window for {case_id}")
        extra_record = extra if case_id == EXTRA_CASE_ID else None
        case, reference = build_case(
            frozen_case, primary, primary_experiment, primary_variant, window, extra_record
        )
        cases.append(case)
        references[case_id] = reference

    return {"schema": "marking-refit-inputs/1", "case_count": len(cases), "cases": cases, "references": references}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    default_run = Path(__file__).resolve().parent.parent
    default_output = Path(__file__).resolve().parent / "marking_inputs.json.gz"
    parser.add_argument("--run", type=Path, default=default_run, help="20260908 input directory")
    parser.add_argument("--output", type=Path, default=default_output, help="output JSON gzip path")
    args = parser.parse_args()
    packed = pack(args.run)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(args.output, packed)
    primary_count = sum(sum(not candidate["extra_gallery_probe"] for candidate in case["candidates"]) for case in packed["cases"])
    extra_count = sum(sum(candidate["extra_gallery_probe"] for candidate in case["candidates"]) for case in packed["cases"])
    print(f"packed {len(packed['cases'])} cases; primary candidates={primary_count}; extra candidates={extra_count}")


if __name__ == "__main__":
    main()
