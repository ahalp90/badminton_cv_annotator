"""Check frozen proposals and refits against other frames of each short clip."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import cv2
import numpy as np
from run_alignment import evidence, prepare_case, read, select, write
from run_reverse import add_reverse_evidence

from experiments.annotator.independent_court import evaluate


def run_window(job: dict) -> dict:
    cv2.setNumThreads(1)
    cases, records = job['cases'], job['records']
    schemes = job['schemes']
    prepared = [prepare_case(case) for case in cases]
    entries, pairs = [], []
    for source_frame, (case, record) in enumerate(zip(cases, records)):
        offset = len(entries)
        for source_entry in record['entries']:
            source_index = source_entry['source_index']
            candidate = case['candidates'][source_index]
            corners = np.asarray(source_entry['corners_px'])
            observations = []
            for target_frame, target_case in enumerate(cases):
                if target_frame == source_frame:
                    observations.append(source_entry['evidence'])
                else:
                    measured = evidence(corners, target_case, prepared[target_frame], candidate)
                    if 'bidirectional' in schemes:
                        measured = add_reverse_evidence(corners, prepared[target_frame], measured)
                    observations.append(measured)
            scores, eligible = {}, {}
            for scheme in schemes:
                values = [obs['scores'][scheme] if obs['eligible'] and obs['scheme_eligible'][scheme] else -1.
                          for obs in observations]
                scores[scheme] = float(np.median(values))
                eligible[scheme] = scores[scheme] >= 0
            entries.append({'source_frame': source_frame, 'source_index': source_index,
                            'extra_gallery_probe': source_entry['extra_gallery_probe'],
                            'stage': source_entry['stage'], 'corners_px': source_entry['corners_px'],
                            'frame_evidence': observations,
                            'evidence': {'eligible': True, 'scores': scores, 'scheme_eligible': eligible}})
        for source_index in range(len(case['candidates'])):
            before_index, after_index = offset + 2 * source_index, offset + 2 * source_index + 1
            choices = {}
            for scheme in schemes:
                gains = []
                for target in range(3):
                    if target == source_frame:
                        continue
                    before = entries[before_index]['frame_evidence'][target]
                    after = entries[after_index]['frame_evidence'][target]
                    valid = before['eligible'] and after['eligible']
                    valid = valid and before['scheme_eligible'][scheme] and after['scheme_eligible'][scheme]
                    if not valid:
                        gains = []
                        break
                    gains.append(after['scores'][scheme] - before['scores'][scheme])
                keep_refit = len(gains) == 2 and min(gains) >= -1e-9 and np.mean(gains) > 1e-9
                choices[scheme] = after_index if keep_refit else before_index
            pairs.append({'source_frame': source_frame, 'source_index': source_index, 'choices': choices,
                          'before_index': before_index, 'after_index': after_index})
    selections = {scheme: select(entries, scheme, prepared[0]['size'], prepared[0]['native_scale'])
                  for scheme in schemes}
    print(job['window'], {name: selection['indices'][:1] for name, selection in selections.items()}, flush=True)
    return {'window': job['window'], 'case_ids': [case['id'] for case in cases],
            'entries': entries, 'pairs': pairs, 'selections': selections}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    packed = read(args.inputs)
    cases = {case['id']: case for case in packed['cases']}
    frozen = read(args.results)
    records, schemes = frozen['records'], frozen['schemes']
    jobs = []
    for window in ('yellow_short', 'letterboxed_short', 'centre_short'):
        chosen = [record for record in records if record['id'].startswith(window + '_frame_')]
        jobs.append({'window': window, 'records': chosen, 'cases': [cases[row['id']] for row in chosen],
                     'schemes': schemes})
    with ProcessPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(run_window, jobs))
    # Labels are accessed after all neighbouring-frame scores and choices finish.
    for result in results:
        for entry in result['entries']:
            entry['metrics'] = {}
            for case_id in result['case_ids']:
                case = cases[case_id]
                entry['metrics'][case_id] = evaluate._metrics(np.asarray(entry['corners_px']),
                                                             packed['references'][case_id],
                                                             case['dimensions']['width'], case['dimensions']['height'])
    write(args.output, {'cross_frame_development_check': True, 'records': results})


if __name__ == '__main__':
    main()
