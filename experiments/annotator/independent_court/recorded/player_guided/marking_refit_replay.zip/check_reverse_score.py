"""Direct synthetic checks for the reverse finite-line alignment score."""
from __future__ import annotations

import cv2
import numpy as np
from reverse_score import reverse_alignment

from experiments.annotator.independent_court.detector import (
    CORNER_COURT_M,
    SEGMENTS_M,
    project,
)

IMAGE_SIZE = (960, 720)
COURT_CORNERS_PX = np.array(
    [[120.0, 80.0], [840.0, 110.0], [780.0, 650.0], [140.0, 680.0]],
    dtype=np.float32,
)
INTERIOR_LINE_X_M = 1.20
OUTSIDE_LINE_X_M = -0.80
LINE_Y_START_M = 0.30
LINE_Y_END_M = 13.10
BOX_MARGIN_PX = 1.0


def homography_and_template() -> tuple[np.ndarray, np.ndarray]:
    """Return one synthetic court-to-image transform and its projected markings."""
    homography = cv2.getPerspectiveTransform(CORNER_COURT_M, COURT_CORNERS_PX)
    projected, _ = project(homography[None], SEGMENTS_M)
    return homography, projected[0].reshape(12, 2, 2)


def project_court_line(homography: np.ndarray, x_m: float) -> np.ndarray:
    """Project a long constant-x court line into one observed XYXY fragment."""
    court_points = np.array([[x_m, LINE_Y_START_M], [x_m, LINE_Y_END_M]], dtype=np.float64)
    image_points, _ = project(homography[None], court_points)
    return image_points[0].reshape(1, 4)


def assert_float_outputs_equal(first: dict, second: dict) -> None:
    """Compare reverse-score outputs while allowing arithmetic round-off."""
    for key in ("score", "eligible_length_px", "explained_fraction"):
        np.testing.assert_allclose(first[key], second[key], rtol=0.0, atol=1e-12)
    assert first["top_unexplained_fragment_indices"] == second["top_unexplained_fragment_indices"]
    np.testing.assert_allclose(
        first["top_unexplained_fragment_weights_px"],
        second["top_unexplained_fragment_weights_px"],
        rtol=0.0,
        atol=1e-12,
    )


def main() -> None:
    homography, projected = homography_and_template()
    exact_observed = projected.reshape(-1, 4)

    exact = reverse_alignment(projected, exact_observed, homography, IMAGE_SIZE)
    assert np.isclose(exact["score"], 1.0)
    assert np.isclose(exact["explained_fraction"], 1.0)
    assert exact["eligible_length_px"] > 0.0

    empty = reverse_alignment(projected, np.empty((0, 4)), homography, IMAGE_SIZE)
    assert empty["score"] == 0.0
    assert empty["eligible_length_px"] == 0.0
    assert empty["explained_fraction"] == 0.0

    interior_line = project_court_line(homography, INTERIOR_LINE_X_M)
    with_interior = reverse_alignment(
        projected,
        np.vstack((exact_observed, interior_line)),
        homography,
        IMAGE_SIZE,
    )
    assert with_interior["score"] < exact["score"]

    outside_line = project_court_line(homography, OUTSIDE_LINE_X_M)
    with_outside = reverse_alignment(
        projected,
        np.vstack((exact_observed, outside_line)),
        homography,
        IMAGE_SIZE,
    )
    assert_float_outputs_equal(exact, with_outside)

    reversed_observed = exact_observed.reshape(-1, 2, 2)[:, ::-1].reshape(-1, 4)
    reversed_result = reverse_alignment(projected, reversed_observed, homography, IMAGE_SIZE)
    assert_float_outputs_equal(exact, reversed_result)

    first_marking = projected[0]
    box = np.concatenate((first_marking.min(axis=0) - BOX_MARGIN_PX, first_marking.max(axis=0) + BOX_MARGIN_PX))
    boxed = reverse_alignment(projected, exact_observed, homography, IMAGE_SIZE, np.asarray([box]))
    assert boxed["eligible_length_px"] < exact["eligible_length_px"]
    assert np.isclose(boxed["score"], 1.0)

    print("reverse marking score synthetic checks: PASS")


if __name__ == "__main__":
    main()
