"""Probe archived court fits against approximate net-post image readings."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from zipfile import ZipFile

import cv2
import numpy as np

from experiments.annotator.independent_court.detector import CORNER_COURT_M, project

REFERENCE_SIZE = np.array([1280.0, 720.0])
POSTS_M = np.array([[0.0, 6.7], [6.1, 6.7]])
SIDE_NAMES = ("left", "right")
SOURCE_IMAGE_ROOT = Path(
    "experiments/annotator/independent_court/recorded/player_guided/stripe_overlays",
)

# Temporary image-read points in 1280x720 image coordinates. These mark
# post ground positions, rather than support-wheel centres, and carry an
# illustrative five-pixel allowance. Displayed circle placement is visually
# confirmed; exact pixel precision remains unmeasured.
POST_BASES_REF_PX: dict[str, dict[str, list[float] | None]] = {
    "am3_window_02_frame_17174": {"left": [93.0, 383.0], "right": [722.0, 361.0]},
    "am3_window_03_frame_24515": {"left": [93.0, 383.0], "right": None},
    "am3_window_01_frame_10514": {"left": [94.0, 384.0], "right": None},
    "am4_window_00_frame_0": {"left": [191.0, 508.0], "right": None},
    "am4_window_00_frame_319": {"left": [164.0, 511.0], "right": [802.0, 516.0]},
}


def read_member(path: Path, member: str) -> dict:
    """Read one compressed JSON member without extracting the archive."""
    with ZipFile(path) as archive:
        return json.loads(gzip.decompress(archive.read(member)))


def source_image_relative(identifier: str) -> str:
    """Return the established relative source-image path for one case ID."""
    return str(SOURCE_IMAGE_ROOT / f"{identifier}__frame.jpg")


def project_posts(
    corners_px: list[list[float]], dimensions: dict[str, int]
) -> list[list[float]]:
    """Project the two ground posts and convert native pixels to 1280x720 pixels."""
    native_corners = np.asarray(corners_px, dtype=np.float32)
    homography = cv2.getPerspectiveTransform(CORNER_COURT_M, native_corners)
    native_posts, denominator = project(homography[None], POSTS_M)
    if not np.isfinite(native_posts).all() or not (denominator > 0).all():
        raise ValueError("post projection is not finite or has non-positive depth")
    native_size = np.array([dimensions["width"], dimensions["height"]], dtype=float)
    return (native_posts[0] * REFERENCE_SIZE / native_size).tolist()


def post_residuals(
    projected_posts_refpx: list[list[float]],
    observations: dict[str, list[float] | None],
) -> tuple[dict[str, float | None], float | None]:
    """Measure available side residuals and their arithmetic mean in reference pixels."""
    projected = np.asarray(projected_posts_refpx, dtype=float)
    residuals: dict[str, float | None] = {}
    available = []
    for index, side in enumerate(SIDE_NAMES):
        observed = observations[side]
        if observed is None:
            residuals[side] = None
            continue
        residual = float(
            np.linalg.norm(projected[index] - np.asarray(observed, dtype=float))
        )
        residuals[side] = residual
        available.append(residual)
    mean = None if not available else float(np.mean(available))
    return residuals, mean


def entry_row(
    entry: dict,
    dimensions: dict[str, int],
    observations: dict[str, list[float] | None],
) -> dict:
    """Add the post diagnostic while preserving archived geometry and metrics."""
    projected = project_posts(entry["corners_px"], dimensions)
    residuals, mean = post_residuals(projected, observations)
    return {
        "id": entry["id"],
        "parent_id": entry["parent_id"],
        "model": entry["model"],
        "post_error_mean_px": mean,
        "post_errors_px": residuals,
        "projected_posts_refpx": projected,
        "corners_px": entry["corners_px"],
        "metrics": entry["metrics"],
    }


def case_row(
    record: dict, reference: dict, observations: dict[str, list[float] | None]
) -> dict:
    """Build one case's diagnostic rows from eligible starts and fixed fits."""
    entries = [
        entry_row(entry, record["dimensions"], observations)
        for entry in record["entries"]
        if entry["eligible"] and entry["model"] in ("start", "fixed_position")
    ]
    post_order = sorted(
        (entry for entry in entries if entry["post_error_mean_px"] is not None),
        key=lambda entry: (entry["post_error_mean_px"], entry["id"]),
    )
    reference_projection = project_posts(reference["corners_px"], record["dimensions"])
    reference_errors, reference_mean = post_residuals(
        reference_projection, observations
    )
    fixed_orders = record["orders"]["fixed_position"]
    return {
        "id": record["id"],
        "native_dimensions": record["dimensions"],
        "source_image_relative": source_image_relative(record["id"]),
        "post_observations_refpx": observations,
        "selected_archived_winner_ids": {
            selector: order[0] if order else None
            for selector, order in fixed_orders.items()
        },
        "reference_homography_anchor": {
            "projected_posts_refpx": reference_projection,
            "post_errors_px": reference_errors,
            "post_error_mean_px": reference_mean,
        },
        "entries": entries,
        "post_only_order": [entry["id"] for entry in post_order],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recorded", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    stripe_archive = args.recorded / "stripe_diagnostics.zip"
    marking_archive = args.recorded / "marking_refit_replay.zip"
    saved = read_member(stripe_archive, "refit_selection_v2.json.gz")
    packed = read_member(marking_archive, "marking_inputs.json.gz")
    references = packed["references"]
    rows = []
    for record in saved["records"]:
        observations = POST_BASES_REF_PX.get(
            record["id"], {"left": None, "right": None}
        )
        rows.append(case_row(record, references[record["id"]], observations))

    output = {
        "schema": "temporary-post-ground-probe/2",
        "diagnostic_only": True,
        "operational_score": False,
        "selectors_under_test": "archived fixed_position winners; gallery uses complete_agreements_first",
        "reference_source": "marking_refit_replay.zip:marking_inputs.json.gz",
        "units_and_limits": {
            "court_post_coordinates_m": POSTS_M.tolist(),
            "projection_coordinate_system": "1280x720 reference pixels",
            "stored_corners_coordinate_system": "native image pixels, copied from archived entries",
            "residual_definition": "Euclidean pixel norm per available side; mean over available sides only",
            "observation_source": "Approximate visual reading of saved frames; pole ground points, not wheel centres",
            "illustrative_reading_allowance_px": 5.0,
            "observation_limit": "Displayed observed post circles confirmed in visual review; exact pixel precision and support offset remain unmeasured; occluded predictions are uncertain",
            "method_limit": "No new weights, gates, candidate refits or operational ranking are introduced",
        },
        "visual_review": {
            "am3_window_02_frame_17174": "Observed circle placement confirmed. Alternative predicted post cross correct; existing gallery prediction misplaced.",
            "am3_window_03_frame_24515": "Left observed circle correct; left predicted cross incorrect. Right predicted cross occluded, looks correct but uncertain.",
            "am4_window_00_frame_0": "Left observed circles correct in both panels; both left predictions incorrect. Existing right prediction incorrect; alternative right prediction looks correct but is occluded.",
            "am3_window_01_frame_10514": "Left observed circle and predicted cross correct in both panels. Right predictions occluded, look correct but uncertain.",
            "am4_window_00_frame_319": "Observed circles and predicted crosses correct on both sides in both panels.",
        },
        "source_image_path_root": str(SOURCE_IMAGE_ROOT),
        "records": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(output, allow_nan=False).encode()
    args.output.write_bytes(gzip.compress(encoded, mtime=0))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
