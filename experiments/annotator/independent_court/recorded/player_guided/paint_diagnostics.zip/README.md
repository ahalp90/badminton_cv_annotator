# Paint-control and post diagnostics

This bundle accompanies `paint_geometry.md` and `paint_results.json.gz`.
It contains development diagnostics, not an automatic post detector or an
acceptance evaluation. Run commands from the repository root in an environment
with the project's experimental dependencies installed.

Contents:

- `post_probe.py`: replay the approximate image-read post-base diagnostic.
- `post_probe.json.gz`: all saved alternatives, both archived selectors, post
  projections and residuals. Visual review confirmed the displayed observed circles;
  a five-pixel allowance is illustrative, not measured uncertainty. Missing sides
  remain null.
- `control_checks.json.gz`: same-process old/current scoring comparison, archive
  population/eligibility checks, fitting identity/weight checks, assignment
  differences and runtime dependency versions.
- `junction_choice_trace.json`: exact saved winner and junction-site evidence
  for frame 17174 and two controls. No new scoring or fitting.
- `historical_stripes.py`: exact `stripe_observations.py` source from a8c13ab.
  It imports the current detector and assignment modules, which are unchanged
  from that revision in this experiment. Preserve that condition for replay.

Extract this bundle to `/tmp/court-paint-diagnostics`, then run:

```bash
PYTHONPATH=src:. python /tmp/court-paint-diagnostics/post_probe.py \
  --recorded experiments/annotator/independent_court/recorded/player_guided \
  --output /tmp/court-post-replay.json.gz

PYTHONPATH=src:. python -m experiments.annotator.independent_court.check_paint_control \
  --results experiments/annotator/independent_court/recorded/player_guided/paint_results.json.gz \
  --recorded experiments/annotator/independent_court/recorded/player_guided \
  --historical-stripes /tmp/court-paint-diagnostics/historical_stripes.py \
  --output /tmp/court-paint-control.json.gz
```

The control checks recorded tolerance-enabled scores exactly. Different numerical
libraries can change endpoint rounding, so a replay elsewhere can fail that check.
The accompanying record gives the versions used. Compare the reported assignment
differences as well as exit status; zero were observed in the saved experiment.
