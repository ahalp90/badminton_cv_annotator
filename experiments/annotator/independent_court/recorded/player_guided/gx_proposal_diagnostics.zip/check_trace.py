"""Verify saved GX generation traces against the frozen extension outputs.

The checker validates trace accounting and independently recomputes the small
labelled example set. Full trace populations are intentionally unavailable to
this helper, so it does not recompute population rankings or minima.
"""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Any

import numpy as np

from experiments.annotator.independent_court import boundary_metrics

EXPECTED_CASE_COUNT = 7
RANK_FIELDS = {
    "max_corner_native_px": "max_corner_native_px",
    "boundary_proxy_1280_px": "boundary_proxy_1280_px",
}
COUNT_FIELDS = (
    "geometry_before_players",
    "players_and_geometry",
    "floor_survivors",
    "camera_survivors",
)
BOUNDARY_METRIC_FIELDS = (
    "clicked_corner_count",
    "clicked_corner_rms_px",
    "clicked_corner_max_px",
    "boundary_landmark_count",
    "boundary_landmark_rms_px",
    "boundary_landmark_max_px",
)


def read_gzip_json(path: Path) -> dict[str, Any]:
    """Read one compressed JSON object."""
    with gzip.open(path, "rt", encoding="utf-8") as source:
        value = json.load(source)
    if not isinstance(value, dict):
        raise TypeError("compressed JSON must contain an object")
    return value


def write_gzip_json(path: Path, value: dict[str, Any]) -> None:
    """Write deterministic compressed JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(value, allow_nan=False, separators=(",", ":")).encode()
    path.write_bytes(gzip.compress(encoded, mtime=0))


def _integer(value: Any, where: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise TypeError(f"{where} must be an integer")
    return int(value)


def _finite(value: Any, where: str) -> float:
    parsed = float(value)
    if not np.isfinite(parsed):
        raise ValueError(f"{where} must be finite")
    return parsed


def _allclose(actual: Any, expected: Any, where: str) -> None:
    actual_array = np.asarray(actual, dtype=np.float64)
    expected_array = np.asarray(expected, dtype=np.float64)
    if not np.allclose(actual_array, expected_array, rtol=0.0, atol=1e-8):
        raise ValueError(f"{where} differs from its independent recomputation")


def _unique_case_ids(cases: Any, label: str) -> list[str]:
    if not isinstance(cases, list):
        raise TypeError(f"{label} cases/records must be a list")
    identifiers: list[str] = []
    seen: set[str] = set()
    for index, case in enumerate(cases):
        if not isinstance(case, dict) or not isinstance(case.get("id"), str):
            raise TypeError(f"{label} item {index} must contain a string id")
        identifier = case["id"]
        if identifier in seen:
            raise ValueError(f"{label} contains duplicate case id {identifier!r}")
        seen.add(identifier)
        identifiers.append(identifier)
    return identifiers


def _load_trace_records(result_directories: list[Path]) -> dict[str, dict[str, Any]]:
    records: dict[str, dict[str, Any]] = {}
    files: list[Path] = []
    for directory in result_directories:
        if not directory.is_dir():
            raise NotADirectoryError(directory)
        files.extend(sorted(directory.glob("*.json.gz")))
    for path in files:
        record = read_gzip_json(path)
        identifier = record.get("id")
        if not isinstance(identifier, str):
            raise TypeError("each trace file must contain a string id")
        if identifier in records:
            raise ValueError(f"trace records contain duplicate case id {identifier!r}")
        records[identifier] = record
    if len(records) != EXPECTED_CASE_COUNT:
        raise ValueError(f"expected exactly {EXPECTED_CASE_COUNT} unique trace records")
    return records


def _expected_generation(expected: dict[str, Any]) -> dict[str, Any]:
    records = expected.get("records")
    _unique_case_ids(records, "expected")
    expected_by_id = {record["id"]: record for record in records}
    if len(expected_by_id) != EXPECTED_CASE_COUNT:
        raise ValueError(f"expected exactly {EXPECTED_CASE_COUNT} unique expected records")
    return expected_by_id


def _check_final_output(
    trace: dict[str, Any], expected: dict[str, Any], case_id: str
) -> dict[str, int | str]:
    if trace.get("exact_output_control") is not True:
        raise ValueError(f"{case_id}: exact_output_control is not true")
    final = trace.get("final")
    generation = expected.get("generation")
    if not isinstance(final, dict) or not isinstance(generation, dict):
        raise TypeError(f"{case_id}: final and expected generation must be objects")

    generated = _integer(final["generated"], f"{case_id} final generated")
    with_players = _integer(final["with_players"], f"{case_id} final with_players")
    if not isinstance(final.get("candidates"), list):
        raise TypeError(f"{case_id}: final candidates must be a list")
    candidate_count = len(final["candidates"])
    reason = final["reason"]
    expected_values = {
        "generated": _integer(generation["hypotheses_generated"], f"{case_id} expected generated"),
        "with_players": _integer(generation["hypotheses_with_players"], f"{case_id} expected with_players"),
        "candidate_count": _integer(generation["retained_candidates"], f"{case_id} expected candidates"),
        "reason": generation["reason"],
    }
    actual_values = {
        "generated": generated,
        "with_players": with_players,
        "candidate_count": candidate_count,
        "reason": reason,
    }
    if actual_values != expected_values:
        raise ValueError(f"{case_id}: final output differs from expected generation")
    scored = _integer(final["scored"], f"{case_id} final scored")
    return {
        "generated": generated,
        "with_players": with_players,
        "candidate_count": candidate_count,
        "scored": scored,
        "reason": reason,
    }


def _check_counts(trace: dict[str, Any], case_id: str, scored: int) -> dict[str, int]:
    counts = trace.get("counts")
    if not isinstance(counts, dict):
        raise TypeError(f"{case_id}: counts must be an object")
    parsed = {
        name: _integer(counts[name], f"{case_id} count {name}") for name in COUNT_FIELDS
    }
    if not (
        parsed["geometry_before_players"]
        >= parsed["players_and_geometry"]
        >= parsed["floor_survivors"]
        >= parsed["camera_survivors"]
    ):
        raise ValueError(f"{case_id}: gate counts are not monotonic")
    if scored != parsed["players_and_geometry"]:
        raise ValueError(f"{case_id}: final scored count differs from players-and-geometry count")
    return parsed


def _check_examples(
    trace: dict[str, Any], source: dict[str, Any], reference: dict[str, Any], case_id: str
) -> dict[int, dict[str, Any]]:
    examples = trace.get("examples")
    if not isinstance(examples, list):
        raise TypeError(f"{case_id}: examples must be a list")
    by_generation: dict[int, dict[str, Any]] = {}
    source_dimensions = source["dimensions"]
    dimensions = (int(source_dimensions["width"]), int(source_dimensions["height"]))
    clicked = reference.get("clicked_corner_indices", [0, 1, 2, 3])
    click_inset = _finite(trace["click_inset_m"], f"{case_id} click_inset_m")
    reference_corners = np.asarray(reference["corners_px"], dtype=np.float64)
    if reference_corners.shape != (4, 2) or not np.isfinite(reference_corners).all():
        raise ValueError(f"{case_id}: reference corners are not finite (4, 2)")
    for example_index, example in enumerate(examples):
        if not isinstance(example, dict):
            raise TypeError(f"{case_id}: example {example_index} must be an object")
        generation_id = _integer(example["generation_id"], f"{case_id} example generation_id")
        if generation_id in by_generation:
            raise ValueError(f"{case_id}: duplicate example generation id {generation_id}")
        corners = np.asarray(example["corners_px"], dtype=np.float64)
        if corners.shape != (4, 2) or not np.isfinite(corners).all():
            raise ValueError(f"{case_id}: example {generation_id} corners are not finite (4, 2)")
        max_corner = float(np.linalg.norm(corners - reference_corners, axis=1).max())
        _finite(example["max_corner_native_px"], f"{case_id} example max corner")
        _finite(example["boundary_proxy_1280_px"], f"{case_id} example boundary proxy")
        _allclose(example["max_corner_native_px"], max_corner, f"{case_id} example max corner")

        recomputed_boundary = boundary_metrics.measure(
            corners,
            reference,
            dimensions,
            clicked,
            click_inset,
        )
        saved_boundary = example.get("boundary_metrics")
        if not isinstance(saved_boundary, dict):
            raise TypeError(f"{case_id} example {generation_id} boundary metrics must be an object")
        for field in BOUNDARY_METRIC_FIELDS:
            expected_value = recomputed_boundary[field]
            if expected_value is None:
                raise ValueError(f"{case_id} example {generation_id} boundary {field} is not finite")
            _finite(saved_boundary[field], f"{case_id} example {generation_id} boundary {field}")
            _allclose(saved_boundary[field], expected_value, f"{case_id} example {generation_id} boundary {field}")
        by_generation[generation_id] = example
    return by_generation


def _check_rankings(
    trace: dict[str, Any], examples: dict[int, dict[str, Any]], generated: int, case_id: str
) -> dict[str, dict[str, dict[str, Any] | None]]:
    rankings = trace.get("diagnostic_rankings")
    if not isinstance(rankings, dict):
        raise TypeError(f"{case_id}: diagnostic_rankings must be an object")
    best: dict[str, dict[str, dict[str, Any] | None]] = {}
    for phase, phase_rankings in rankings.items():
        if not isinstance(phase_rankings, dict):
            raise TypeError(f"{case_id}: rankings for {phase} must be an object")
        best[phase] = {}
        for metric, entries in phase_rankings.items():
            if metric not in RANK_FIELDS or not isinstance(entries, list):
                raise ValueError(f"{case_id}: unsupported or malformed ranking {phase}/{metric}")
            saved_best: dict[str, Any] | None = None
            for entry in entries:
                if not isinstance(entry, dict):
                    raise TypeError(f"{case_id}: ranking {phase}/{metric} entry must be an object")
                generation_id = _integer(entry["generation_id"], f"{case_id} ranking generation id")
                if generation_id < 0 or generation_id >= generated:
                    raise ValueError(f"{case_id}: ranking generation id is outside generated range")
                example = examples.get(generation_id)
                if example is None:
                    raise ValueError(f"{case_id}: ranking generation id is absent from examples")
                rank_value = _finite(entry["value"], f"{case_id} ranking value")
                example_value = _finite(example[RANK_FIELDS[metric]], f"{case_id} ranked example value")
                _allclose(rank_value, example_value, f"{case_id} ranking {phase}/{metric}")
                if saved_best is None:
                    saved_best = {"generation_id": generation_id, "value": rank_value}
            best[phase][metric] = saved_best
    return best


def check_case(
    trace: dict[str, Any], expected: dict[str, Any], source: dict[str, Any], reference: dict[str, Any]
) -> dict[str, Any]:
    case_id = trace["id"]
    final = _check_final_output(trace, expected, case_id)
    counts = _check_counts(trace, case_id, final["scored"])
    examples = _check_examples(trace, source, reference, case_id)
    best_rankings = _check_rankings(trace, examples, final["generated"], case_id)
    return {
        "id": case_id,
        "counts": counts,
        "final": final,
        "best_saved_ranking_values": best_rankings,
        "example_count": len(examples),
        "verified": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--expected", type=Path, required=True)
    parser.add_argument("--results", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()

    inputs = read_gzip_json(arguments.inputs)
    input_cases = inputs.get("cases")
    input_ids = _unique_case_ids(input_cases, "input")
    if len(input_ids) != EXPECTED_CASE_COUNT:
        raise ValueError(f"expected exactly {EXPECTED_CASE_COUNT} unique input cases")
    references = inputs.get("references")
    if not isinstance(references, dict):
        raise TypeError("input references must be an object")
    expected_by_id = _expected_generation(read_gzip_json(arguments.expected))
    trace_by_id = _load_trace_records(arguments.results)
    if set(trace_by_id) != set(input_ids):
        raise ValueError("trace record IDs do not exactly match original input IDs")
    if set(expected_by_id) != set(input_ids):
        raise ValueError("expected record IDs do not exactly match original input IDs")
    sources = {case["id"]: case for case in input_cases}

    summaries = []
    for case_id in input_ids:
        if case_id not in references:
            raise KeyError(f"missing reference for {case_id}")
        summaries.append(
            check_case(trace_by_id[case_id], expected_by_id[case_id], sources[case_id], references[case_id])
        )
    output = {
        "schema": "gx-generation-gate-check/1",
        "verified": True,
        "case_count": len(summaries),
        "full_populations_recomputed": False,
        "rank_minima_recomputed": False,
        "population_limit": (
            "Full populations and rank minima were not recomputed because trace arrays are unavailable."
        ),
        "records": summaries,
    }
    write_gzip_json(arguments.output, output)


if __name__ == "__main__":
    main()
