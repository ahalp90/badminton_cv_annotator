"""Refine reference-selected GX proposals while preserving their original starts.

The selected starting court is label-guided. Optimisation uses cached image
fragments and fixed marking/paint-position assignments, without reference labels.
"""
from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from run_trace import read, write

from experiments.annotator.independent_court import (
    boundary_metrics,
    fixed_stripe_refit,
    run_paint_refit,
)
from experiments.annotator.independent_court import stripe_observations as stripes
from experiments.annotator.independent_court.assignment import prepare_observations
from experiments.annotator.independent_court.detector import CORNER_COURT_M


def run_case(source: dict, trace: dict, reference: dict, legacy: Any) -> dict:
    generation_id = trace["diagnostic_rankings"]["players_and_geometry"]["boundary_proxy_1280_px"][0]["generation_id"]
    selected = next(example for example in trace["examples"] if example["generation_id"] == generation_id)
    corners = np.asarray(selected["corners_px"])
    case = dict(source)
    case["all_feet_px"] = [[[np.nan, np.nan] if foot is None else foot for foot in sample]
                           for sample in source["all_feet_px"]]
    prepared = legacy.prepare_case(case)
    size, scale = prepared["size"], prepared["native_scale"]
    dimensions = (source["dimensions"]["width"], source["dimensions"]["height"])
    observations = prepare_observations(prepared["segments"], size)
    weights = stripes.fragment_weights(observations)
    homography = cv2.getPerspectiveTransform(CORNER_COURT_M, (corners / scale).astype(np.float32))
    initial = fixed_stripe_refit.initial_parameters(corners / scale, size)
    entries = []

    def describe(coordinates: np.ndarray, frozen: dict, fresh: dict) -> dict:
        evidence = legacy.evidence(coordinates, case, prepared, {"source_variant": "all_people_net"})
        return {"corners_px": coordinates.tolist(), "gate_evidence": evidence,
                "stripe_frozen": frozen, "stripe_fresh": fresh,
                "boundary_metrics": boundary_metrics.measure(coordinates, reference, dimensions,
                                                               reference["clicked_corner_indices"], 0.005)}

    for model, centres in run_paint_refit.MODELS.items():
        starting_score = run_paint_refit.score(corners, observations, weights, size, scale, centres)
        assigned = starting_score["assignments"]
        constraints = fixed_stripe_refit.prepare(homography, observations, assigned, weights, centres)
        fit = fixed_stripe_refit.refine(corners / scale, constraints, size, True, initial, centres)
        # Solver coordinates are working pixels; retain failed attempts in the same
        # native coordinate system as successful fits and starting courts.
        if fit["corners_px"] is not None:
            fit["corners_px"] = (np.asarray(fit["corners_px"]) * scale).tolist()
        start = {"model": model, "stage": "start", **describe(corners, starting_score, starting_score),
                 "attempt": fit, "fixed_sample_count": len(constraints.points)}
        entries.append(start)
        if fit["successful"]:
            changed = np.asarray(fit["corners_px"])
            frozen = run_paint_refit.score(changed, observations, weights, size, scale, centres, assigned)
            fresh = run_paint_refit.score(changed, observations, weights, size, scale, centres)
            entries.append({"model": model, "stage": "refit", **describe(changed, frozen, fresh), "fit": fit})
    return {"schema": "gx-rejected-proposal-refit/1", "id": source["id"],
            "generation_id": generation_id, "label_guided_start_selection": True,
            "labels_supplied_to_optimisation": False, "automatic_selection_evaluated": False,
            "click_inset_m": 0.005, "entries": entries}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--traces", type=Path, nargs="+", required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ids", nargs="*")
    args = parser.parse_args()
    cv2.setNumThreads(1)
    sys.path.insert(0, str(args.legacy.resolve()))
    legacy = importlib.import_module("run_alignment")
    packed = read(args.inputs)
    traces = {}
    for directory in args.traces:
        for path in directory.glob("*.json.gz"):
            trace = read(path)
            if trace["id"] in traces:
                raise ValueError(f"duplicate trace {trace['id']}")
            traces[trace["id"]] = trace
    if set(traces) != {source["id"] for source in packed["cases"]}:
        raise ValueError("trace/input case IDs must match")
    args.output.mkdir(parents=True, exist_ok=True)
    for source in packed["cases"]:
        if args.ids and source["id"] not in args.ids:
            continue
        result = run_case(source, traces[source["id"]], packed["references"][source["id"]], legacy)
        write(args.output / f"{source['id']}.json.gz", result)
        for entry in result["entries"]:
            print(source["id"], entry["model"], entry["stage"], entry["boundary_metrics"]["boundary_landmark_rms_px"], flush=True)


if __name__ == "__main__":
    main()
