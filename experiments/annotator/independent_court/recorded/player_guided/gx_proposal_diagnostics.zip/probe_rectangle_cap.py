"""Compare proposal coverage before/after the seed-rectangle cap, without fitting.

Both arms use the cached fragments and unchanged merging/template assignments.
Reference labels select diagnostic examples after each proposal batch exists.
Player, camera and floor checks are applied only to the saved examples, so this
is a coverage diagnostic rather than an expanded detector or runtime benchmark.
"""
from __future__ import annotations

import argparse
import importlib
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from run_trace import boundary_proxy, geometry, read, write

from experiments.annotator.independent_court import boundary_metrics, detector


def examine(source: dict, reference: dict, zone: Any, exhaustive: bool) -> dict:
    width, height = source["dimensions"]["width"], source["dimensions"]["height"]
    settings = detector.Settings(wide_families=True, min_supported_lines=3)
    factor = min(1., settings.max_dimension / max(width, height))
    size = (round(width * factor), round(height * factor))
    scale = np.array([width, height]) / size
    segments = np.asarray(source["segments_px"]) / np.tile(scale, 2)
    families = detector._wide_line_families(segments)
    lines = tuple(detector._merge_lines(family, settings) for family in families)
    if exhaustive:
        # With at most 32 lines per family, this exceeds every possible pair product.
        settings = replace(settings, max_rectangles=settings.max_family_lines**4)
    rectangles = detector._image_rectangles(*lines, size, settings)
    generated, valid_count = 0, 0
    best = {"max_corner_native_px": None, "boundary_proxy_1280_px": None}
    for offset in range(0, len(rectangles), 8):
        homographies = (rectangles[offset:offset + 8, None] @ detector.TEMPLATE_TRANSFORMS).reshape(-1, 3, 3)
        valid, corners = geometry(homographies, size, settings)
        indices = np.flatnonzero(valid)
        native = corners[valid] * scale
        values = {
            "max_corner_native_px": np.linalg.norm(native - reference["corners_px"], axis=2).max(axis=1),
            "boundary_proxy_1280_px": boundary_proxy(native, reference, source["dimensions"]),
        }
        for metric, distances in values.items():
            if not len(distances):
                continue
            index = int(np.argmin(distances))
            previous = best[metric]
            if previous is None or distances[index] < previous["value"]:
                generation_id = generated + int(indices[index])
                best[metric] = {"value": float(distances[index]), "generation_id": generation_id,
                                "rectangle_index": generation_id // len(detector.TEMPLATE_TRANSFORMS),
                                "template_index": generation_id % len(detector.TEMPLATE_TRANSFORMS),
                                "corners_px": native[index].tolist(),
                                "homography_working": homographies[indices[index]].tolist()}
        generated += len(homographies)
        valid_count += len(indices)
    feet = np.asarray([[[np.nan, np.nan] if foot is None else foot for foot in sample]
                       for sample in source["all_feet_px"]], dtype=float) / scale
    maps = detector._distance_maps(families, size)
    for example in best.values():
        if example is None:
            continue
        homography = np.asarray(example["homography_working"])[None]
        corners = np.asarray(example["corners_px"])
        one, two = zone.player_fractions(homography, feet)
        _, camera_error, _ = zone.net_segments(corners, (width, height))
        _, scores, means, counts = detector._score(homography, maps, settings, lines)
        example.update({"one_fraction": float(one[0]), "two_fraction": float(two[0]),
                        "camera_error": camera_error, "floor_score": float(scores[0]),
                        "family_support": means[0].tolist(), "line_counts": counts[0].tolist(),
                        "boundary_metrics": boundary_metrics.measure(corners, reference, (width, height),
                                                                       reference["clicked_corner_indices"], 0.005)})
    return {"exhaustive_seed_pairs": exhaustive, "rectangles": len(rectangles),
            "generated": generated, "geometry_valid": valid_count, "best": best}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--trace-results", type=Path, nargs="+", required=True)
    args = parser.parse_args()
    cv2.setNumThreads(1)
    sys.path.insert(0, str(args.legacy.resolve()))
    zone = importlib.import_module("zone_net")
    packed = read(args.inputs)
    traces = {}
    for directory in args.trace_results:
        for path in directory.glob("*.json.gz"):
            record = read(path)
            traces[record["id"]] = record
    records = []
    for source in packed["cases"]:
        if source["id"] not in args.ids:
            continue
        reference = packed["references"][source["id"]]
        baseline = examine(source, reference, zone, False)
        trace = traces[source["id"]]
        if baseline["generated"] != trace["final"]["generated"] or baseline["geometry_valid"] != trace["counts"]["geometry_before_players"]:
            raise ValueError("baseline proposal population differs from full detector trace")
        for metric, example in baseline["best"].items():
            expected = trace["diagnostic_rankings"]["geometry_before_players"][metric][0]
            if example["value"] != expected["value"] or example["generation_id"] != expected["generation_id"]:
                raise ValueError("baseline diagnostic selection differs from full detector trace")
        expanded = examine(source, reference, zone, True)
        record = {"id": source["id"], "baseline_control_exact": True, "baseline": baseline, "all_pairs": expanded}
        records.append(record)
        print(source["id"], "rectangles", baseline["rectangles"], expanded["rectangles"],
              "max-corner minima", baseline["best"]["max_corner_native_px"]["value"],
              expanded["best"]["max_corner_native_px"]["value"], flush=True)
    if {record["id"] for record in records} != set(args.ids):
        raise ValueError("requested case IDs must exist")
    write(args.output, {"schema": "gx-seed-cap-probe/1", "label_guided_diagnostic": True,
                        "automatic_selection_evaluated": False, "records": records})


if __name__ == "__main__":
    main()
