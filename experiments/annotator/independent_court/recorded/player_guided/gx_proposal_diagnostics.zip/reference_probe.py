"""Score GX reference courts against controlled line-family diagnostics.

This labelled oracle probe never supplies a reference court to the detector. It
only projects each manually annotated court into the detector's working image,
then measures the existing floor scorer under named line-map and merge arms.
"""

from __future__ import annotations

import argparse
import gzip
import json
import platform
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from experiments.annotator.independent_court import detector

MAX_DIMENSION = 960
MIN_SUPPORTED_LINES = 3
MERGE_DISTANCE_PROBE = 2.0

ARM_ORIGINAL = "original_wide"
ARM_ALL_MAPS = "all_fragment_maps_original_lines"
ARM_ALL_LINES = "original_maps_all_fragment_lines"
ARM_ALL = "all_fragment_maps_all_fragment_lines"
ARM_MERGE2_ORIGINAL = "merge2_original_wide"
ARM_MERGE2_ALL = "merge2_all_fragment_maps_lines"

ARM_DESCRIPTIONS = {
    ARM_ORIGINAL: "wide families, their maps and their merged lines",
    ARM_ALL_MAPS: "all fragments in both maps, original wide-family merged lines",
    ARM_ALL_LINES: "original wide-family maps, merged lines from the same all-fragment pool",
    ARM_ALL: "all fragments in both maps and merged-line pools",
    ARM_MERGE2_ORIGINAL: "original wide-family maps and merge distance 2 lines",
    ARM_MERGE2_ALL: "all-fragment maps and merge distance 2 lines from the all-fragment pool",
}


def read_gzip_json(path: Path) -> dict[str, Any]:
    """Read one compressed JSON object."""
    with gzip.open(path, "rt", encoding="utf-8") as source:
        value = json.load(source)
    if not isinstance(value, dict):
        raise TypeError("inputs must contain a JSON object")
    return value


def write_gzip_json(path: Path, value: dict[str, Any]) -> None:
    """Write deterministic compressed JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(value, allow_nan=False, separators=(",", ":")).encode()
    path.write_bytes(gzip.compress(encoded, mtime=0))


def _dimensions(case: dict[str, Any]) -> tuple[int, int]:
    dimensions = case["dimensions"]
    width, height = int(dimensions["width"]), int(dimensions["height"])
    if width <= 0 or height <= 0:
        raise ValueError(f"{case['id']}: dimensions must be positive")
    return width, height


def _working_inputs(
    case: dict[str, Any], reference: dict[str, Any]
) -> tuple[tuple[int, int], np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return working size, scale, fragments, working reference corners and H."""
    width, height = _dimensions(case)
    resize = min(1.0, MAX_DIMENSION / max(width, height))
    size = (round(width * resize), round(height * resize))
    native_scale = np.asarray([width / size[0], height / size[1]], dtype=np.float64)

    native_segments = np.asarray(case["segments_px"], dtype=np.float64)
    if native_segments.ndim != 2 or native_segments.shape[1] != 4 or not np.isfinite(native_segments).all():
        raise ValueError(f"{case['id']}: segments_px must contain finite XYXY rows")
    if np.any(np.linalg.norm(native_segments[:, 2:] - native_segments[:, :2], axis=1) == 0):
        raise ValueError(f"{case['id']}: segments_px must have positive length")
    working_segments = native_segments / np.tile(native_scale, 2)

    native_corners = np.asarray(reference["corners_px"], dtype=np.float64)
    if native_corners.shape != (4, 2) or not np.isfinite(native_corners).all():
        raise ValueError(f"{case['id']}: reference corners must be finite (4, 2) points")
    working_corners = native_corners / native_scale
    reference_h = cv2.getPerspectiveTransform(
        detector.CORNER_COURT_M.astype(np.float32), working_corners.astype(np.float32)
    )
    if not np.isfinite(reference_h).all():
        raise ValueError(f"{case['id']}: reference homography is non-finite")
    return size, native_scale, working_segments, working_corners, reference_h


def _normalised_angles(segments: np.ndarray) -> list[float]:
    vectors = segments[:, 1] - segments[:, 0]
    angles = np.arctan2(vectors[:, 1], vectors[:, 0])
    angles = (angles + np.pi / 2) % np.pi - np.pi / 2
    return np.degrees(angles).tolist()


def _reference_geometry(
    reference_h: np.ndarray, size: tuple[int, int], settings: detector.Settings
) -> dict[str, Any]:
    projected, _ = detector.project(reference_h[None], detector.SEGMENTS_M)
    projected_segments = projected[0].reshape(12, 2, 2)
    _, visible = detector._visible_samples(
        projected_segments[None], size, settings.samples_per_line
    )
    return {
        "projected_template_angles_deg": _normalised_angles(projected_segments),
        "projected_template_visible": visible[0].tolist(),
    }


def _merge_counts(lines: tuple[np.ndarray, np.ndarray]) -> list[int]:
    return [len(lines[0]), len(lines[1])]


def _normalised_line(start: np.ndarray, end: np.ndarray) -> np.ndarray:
    points = np.array([[*start, 1.0], [*end, 1.0]], dtype=np.float64)
    line = np.cross(points[0], points[1])
    norm = np.linalg.norm(line[:2])
    if norm <= 1e-12:
        raise ValueError("oracle seed line has coincident endpoints")
    return line / norm


def _oracle_seed_control(
    working_corners: np.ndarray, size: tuple[int, int], settings: detector.Settings
) -> dict[str, Any]:
    """Build one exact four-boundary seed and inspect its rectangle construction."""
    sidelines = np.asarray(
        [_normalised_line(working_corners[start], working_corners[end]) for start, end in ((0, 3), (1, 2))]
    )
    baselines = np.asarray(
        [_normalised_line(working_corners[start], working_corners[end]) for start, end in ((0, 1), (3, 2))]
    )
    rectangles = detector._image_rectangles(sidelines, baselines, size, settings)
    projected, _ = detector.project(rectangles, detector.UNIT_CORNERS)
    centre_x, centre_y = np.asarray(size, dtype=np.float64) / 2
    sideline_x = [float(-(line[1] * centre_y + line[2]) / line[0]) for line in sidelines]
    baseline_y = [float(-(line[0] * centre_x + line[2]) / line[1]) for line in baselines]
    return {
        "rectangle_count": len(rectangles),
        "projected_unit_corners_working_px": projected.tolist(),
        "normalised_sideline_lines": sidelines.tolist(),
        "normalised_baseline_lines": baselines.tolist(),
        "image_centre_working_px": [float(centre_x), float(centre_y)],
        "sideline_x_at_centre_y": sideline_x,
        "baseline_y_at_centre_x": baseline_y,
    }


def _score_arm(
    reference_h: np.ndarray,
    maps: np.ndarray,
    lines: tuple[np.ndarray, np.ndarray],
    settings: detector.Settings,
    name: str,
    map_family_counts: list[int],
) -> dict[str, Any]:
    corners, scores, means, counts = detector._score(
        reference_h[None], maps, settings, lines
    )
    if len(scores) != 1:
        raise ValueError(f"reference geometry did not survive detector geometry checks in {name}")
    return {
        "description": ARM_DESCRIPTIONS[name],
        "settings": asdict(settings),
        "map_family_fragment_counts": map_family_counts,
        "merged_line_counts": _merge_counts(lines),
        "floor_score": float(scores[0]),
        "family_means": means[0].tolist(),
        "distinct_line_counts": counts[0].tolist(),
        "projected_corners_working_px": corners[0].tolist(),
    }


def _case_record(
    case: dict[str, Any], reference: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    settings = detector.Settings(
        wide_families=True,
        min_supported_lines=MIN_SUPPORTED_LINES,
    )
    merge2_settings = replace(settings, merge_distance=MERGE_DISTANCE_PROBE)
    size, native_scale, segments, working_corners, reference_h = _working_inputs(case, reference)
    original_families = detector._wide_line_families(segments)
    all_families = (segments, segments)
    original_maps = detector._distance_maps(original_families, size)
    all_maps = detector._distance_maps(all_families, size)
    original_lines = tuple(
        detector._merge_lines(family, settings) for family in original_families
    )
    all_line_pool = detector._merge_lines(segments, settings)
    all_lines = (all_line_pool, all_line_pool)
    merge2_original_lines = tuple(
        detector._merge_lines(family, merge2_settings) for family in original_families
    )
    merge2_all_line_pool = detector._merge_lines(segments, merge2_settings)
    merge2_all_lines = (merge2_all_line_pool, merge2_all_line_pool)

    original_family_counts = [len(family) for family in original_families]
    all_family_counts = [len(family) for family in all_families]
    arms = {
        ARM_ORIGINAL: _score_arm(
            reference_h, original_maps, original_lines, settings, ARM_ORIGINAL, original_family_counts
        ),
        ARM_ALL_MAPS: _score_arm(
            reference_h, all_maps, original_lines, settings, ARM_ALL_MAPS, all_family_counts
        ),
        ARM_ALL_LINES: _score_arm(
            reference_h, original_maps, all_lines, settings, ARM_ALL_LINES, original_family_counts
        ),
        ARM_ALL: _score_arm(reference_h, all_maps, all_lines, settings, ARM_ALL, all_family_counts),
        ARM_MERGE2_ORIGINAL: _score_arm(
            reference_h,
            original_maps,
            merge2_original_lines,
            merge2_settings,
            ARM_MERGE2_ORIGINAL,
            original_family_counts,
        ),
        ARM_MERGE2_ALL: _score_arm(
            reference_h,
            all_maps,
            merge2_all_lines,
            merge2_settings,
            ARM_MERGE2_ALL,
            all_family_counts,
        ),
    }
    record = {
        "id": case["id"],
        "dimensions": {"width": _dimensions(case)[0], "height": _dimensions(case)[1]},
        "working_size": list(size),
        "native_scale": native_scale.tolist(),
        "original_fragment_count": len(segments),
        "original_family_fragment_counts": original_family_counts,
        "all_fragment_family_counts": all_family_counts,
        "reference_homography_working": reference_h.tolist(),
        **_reference_geometry(reference_h, size, settings),
        "arms": arms,
    }
    return record, _oracle_seed_control(working_corners, size, settings)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()

    packed = read_gzip_json(arguments.inputs)
    cases = packed["cases"]
    references = packed["references"]
    if not isinstance(cases, list) or not isinstance(references, dict):
        raise TypeError("inputs must contain cases and references")
    records: list[dict[str, Any]] = []
    oracle_seed_controls: list[dict[str, Any]] = []
    for case in cases:
        if not isinstance(case, dict):
            raise TypeError("each case must be an object")
        case_id = case["id"]
        record, seed_control = _case_record(case, references[case_id])
        records.append(record)
        oracle_seed_controls.append({"id": case_id, **seed_control})
        print(case_id, flush=True)

    settings = detector.Settings(
        wide_families=True,
        min_supported_lines=MIN_SUPPORTED_LINES,
    )
    output = {
        "schema": "gx-reference-floor-probe/1",
        "diagnostic_only": True,
        "ranking_input": False,
        "labelled_oracle": True,
        "reference_labels_used_for_scoring": True,
        "runtime": {
            "python": platform.python_version(),
            "opencv": cv2.__version__,
            "numpy": np.__version__,
        },
        "max_dimension": MAX_DIMENSION,
        "settings": asdict(settings),
        "merge_distance_probe": MERGE_DISTANCE_PROBE,
        "arms": {
            name: {"description": description}
            for name, description in ARM_DESCRIPTIONS.items()
        },
        "records": records,
        "oracle_seed_control": oracle_seed_controls,
    }
    write_gzip_json(arguments.output, output)


if __name__ == "__main__":
    main()
