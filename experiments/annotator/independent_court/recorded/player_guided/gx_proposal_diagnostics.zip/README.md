# GX proposal and gate diagnostics

These are frozen-input development diagnostics from checkpoint d7523c1.
They do not define an automatic court detector or an acceptance threshold.
Read the adjacent gx_proposal_trace.md report for interpretation.

## Contents

- run_trace.py: uninstrumented/traced detector comparison, generation IDs and
  post-run diagnostic examples. Labels enter only after detection.
- reference_probe.py: labelled reference scoring with six evidence-access arms.
- probe_rectangle_cap.py: original/all-seed-pair coverage comparison on frames 0/5.
- render_trace.py: source and original proposal overlays from saved results.
- check_trace.py: historical accounting and independent saved-example metrics.
- traces/: the original seven summaries. Frame 0 came from the first smoke;
  the six other cases used the identical producer and settings.
- reference_probe.json.gz, rectangle_cap.json.gz: controlled diagnostics.
- check.json.gz: seven-case saved-output verification.
- am2_control/: additional original/traced control for the earlier amateur case.
- refit_examples.py: both existing paint refits from unchanged diagnostic starts.
- render_recovery.py: original/refit and sampled/complete-seed comparisons.
- refit_results/: all seven cases, including 14 starts and 14 converged fits.
- refit_check.json.gz: independent start identity and saved-metric verification.

All corner arrays and max_corner_native_px values are in native pixels.
Boundary metrics and boundary_proxy_1280_px use 1280x720 coordinates. The report
converts maximum corner error to 1280x720 as well. Reference-selected examples
are ordered by the zero-inset boundary proxy; reported boundary metrics apply
the GX 0.005m inward click convention. No useful-court cutoff is established.

The trace's support_mean_pass and distinct_line_pass counts are over rows that
already pass player and geometry checks. NaN internal fields denote gates never
run. The original JSON summaries predate explicit subgate_count_population
metadata; the producer now names that denominator and reuses captured settings.
This metadata clarification changes none of the completed runs' settings or
numerical results. The optional full-array capture writes numeric .npy.xz files;
it was not enabled in the seven original runs.

The complete seed-pair arms evaluate every geometry-valid generated proposal
for two label-distance objectives. They apply player/camera/floor checks only
to the selected examples. They are not expanded end-to-end detector runs.
Generation IDs in different seed-cap arms identify that arm's own enumeration.

All merged pools remain capped at 32 lines. The all-fragment scorer can receive
incidental background/differently oriented support; passing a labelled reference
there does not validate a matcher. The merge-distance probes also change which
lines survive that cap, so their effects need not be monotonic.

## Dependencies and replay

Python 3.11.13, NumPy 2.4.6 and OpenCV 5.0.0 produced the original trace/probes.
The repository experiment modules and SciPy/Pillow are also needed for legacy
imports and rendering. Other numerical builds may change fragment ordering or
solver rounding. Use the project's experiment environment and run from its root.
No model inference or source video decoding is required.

Set up one temporary replay directory using already-published dependencies:

```bash
gx_recorded=experiments/annotator/independent_court/recorded/player_guided &&
gx_replay=$(mktemp -d /tmp/gx-proposal-replay.XXXXXX) &&
unzip -q "$gx_recorded/gx_proposal_diagnostics.zip" -d "$gx_replay/probe" &&
unzip -q "$gx_recorded/extension_diagnostics.zip" \
  gx/inputs.json.gz gx/results.json.gz -d "$gx_replay/inputs" &&
unzip -q "$gx_recorded/marking_refit_replay.zip" \
  '*.py' marking_inputs.json.gz -d "$gx_replay/legacy"
```

Then run these dependent stages in order:

```bash
PYTHONPATH=src:. python "$gx_replay/probe/run_trace.py" \
  --inputs "$gx_replay/inputs/gx/inputs.json.gz" \
  --legacy "$gx_replay/legacy" --output "$gx_replay/fresh"

PYTHONPATH=src:. python "$gx_replay/probe/check_trace.py" \
  --inputs "$gx_replay/inputs/gx/inputs.json.gz" \
  --expected "$gx_replay/inputs/gx/results.json.gz" \
  --results "$gx_replay/fresh" --output "$gx_replay/check.json.gz"

PYTHONPATH=src:. python "$gx_replay/probe/reference_probe.py" \
  --inputs "$gx_replay/inputs/gx/inputs.json.gz" \
  --output "$gx_replay/reference_probe.json.gz"

PYTHONPATH=src:. python "$gx_replay/probe/probe_rectangle_cap.py" \
  --inputs "$gx_replay/inputs/gx/inputs.json.gz" \
  --legacy "$gx_replay/legacy" --trace-results "$gx_replay/fresh" \
  --ids gxBQ_window_00_frame_0 gxBQ_window_00_frame_5 \
  --output "$gx_replay/rectangle_cap.json.gz"

PYTHONPATH=src:. python "$gx_replay/probe/render_trace.py" \
  --results "$gx_replay/fresh" --frames "$gx_recorded/extension_overlays/gx" \
  --output "$gx_replay/gallery"
```

To reproduce the earlier Amateur-2 control, use run_trace.py with the extracted
legacy/marking_inputs.json.gz, --ids am2_window_01_frame_28019 and
--click-inset-m 0. Original final output, generation accounting and known
proposal 405298 match the earlier saved capture exactly. This does not assert
numerical equivalence of every row in that older capture.

Run the completed refinement comparison from the same extracted dependencies:

```bash
PYTHONPATH=src:. python "$gx_replay/probe/refit_examples.py" \
  --inputs "$gx_replay/inputs/gx/inputs.json.gz" \
  --traces "$gx_replay/probe/traces" --legacy "$gx_replay/legacy" \
  --output "$gx_replay/refits"

PYTHONPATH=src:. python "$gx_replay/probe/render_recovery.py" \
  --refits "$gx_replay/refits" --caps "$gx_replay/probe/rectangle_cap.json.gz" \
  --frames "$gx_recorded/extension_overlays/gx" \
  --output "$gx_replay/recovery_gallery"
```

These starts are chosen using reference boundaries after detection. Neither
paint optimiser sees the labels. The ordinary frame-5 trace supplies its start;
the all-pairs example is a separate experiment. All 14 fits converge, but none
passes the original floor gate. Solver success is not court correctness.
All saved boundary metrics were independently recomputed within 1e-8 px; the
largest local/experiment-environment difference was about 9.77e-14 px.

The ZIP contains producers and results, not its numerical environment.
check_trace.py verifies saved examples and denominators; without full arrays,
it does not independently recompute population-wide minima. The paired trace
and seed-cap control establish their respective enumeration identities.
