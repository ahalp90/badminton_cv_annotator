"""Trace cached court proposals without changing their generation or filtering.

Run once per frozen input pack. Each case first runs uninstrumented, then with
observers; complete final outputs must match exactly. Labels enter only the
post-run summary. --legacy names the directory containing zone_net.py and its
camera_diagnostic.py dependency from marking_refit_replay.zip.
"""
from __future__ import annotations

import argparse
import gzip
import importlib
import json
import lzma
import sys
from collections import deque
from dataclasses import asdict
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from experiments.annotator.independent_court import boundary_metrics, detector

ROW_DTYPE = np.dtype([
    ("generation_id", "i8"), ("corners_px", "f8", (4, 2)),
    ("one_fraction", "f8"), ("two_fraction", "f8"),
    ("floor_score", "f8"), ("family_support", "f8", (2,)),
    ("line_counts", "i8", (2,)), ("camera_error", "f8"),
])


def read(path: Path) -> dict:
    return json.loads(gzip.decompress(path.read_bytes()))


def write(path: Path, value: Any) -> None:
    path.write_bytes(gzip.compress(json.dumps(value, allow_nan=False).encode(), mtime=0))


def final_output(result: Any) -> dict:
    detection = result.detection
    return {
        "generated": result.hypotheses_generated,
        "with_players": result.hypotheses_with_players,
        "accepted": detection.accepted, "reason": detection.reason,
        "gap": detection.score_gap, "line_counts": list(detection.family_line_counts),
        "scored": detection.hypotheses_scored,
        "player_fractions": result.player_fractions,
        "segments_px": detection.segments_px.tolist(),
        "candidates": [{**asdict(candidate), "corners_px": candidate.corners_px.tolist()}
                       for candidate in detection.candidates],
    }


def geometry(homographies: np.ndarray, size: tuple[int, int], settings: detector.Settings) -> tuple:
    corners, denominator = detector.project(homographies, detector.CORNER_COURT_M)
    edges = np.roll(corners, -1, axis=1) - corners
    turns = edges[..., 0] * np.roll(edges[..., 1], -1, axis=1) - edges[..., 1] * np.roll(edges[..., 0], -1, axis=1)
    span = np.minimum(corners.max(axis=1), np.asarray(size) - 1) - np.maximum(corners.min(axis=1), 0)
    valid = (np.isfinite(corners).all(axis=(1, 2)) & np.all(denominator > 1e-6, axis=1)
             & np.all(turns > 0, axis=1) & np.all(span / size >= settings.min_visible_span_fraction, axis=1))
    return valid, corners


def capture(source: dict, zone: Any, settings: detector.Settings) -> tuple[dict, np.ndarray]:
    width, height = source["dimensions"]["width"], source["dimensions"]["height"]
    resize = min(1.0, settings.max_dimension / max(width, height))
    size = (round(width * resize), round(height * resize))
    scale = np.asarray([width, height]) / size
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    feet = np.asarray([[[np.nan, np.nan] if foot is None else foot for foot in sample]
                       for sample in source["all_feet_px"]], dtype=float)
    segments = np.asarray(source["segments_px"], dtype=float)
    # Cached fragments make image intensities irrelevant in this generator.
    baseline = final_output(zone.detect(frame, feet, settings, segments_px=segments))
    batches = []
    generated = 0
    player_count = 0
    score_inputs = 0
    current = {}
    camera_rows = deque()
    original_player = zone.player_fractions
    original_score = detector._score
    original_net = zone.net_segments

    def observe_players(homographies: np.ndarray, working_feet: np.ndarray, margin: float = 0.15) -> tuple:
        nonlocal generated, player_count, current
        fractions = original_player(homographies, working_feet, margin)
        if len(homographies) == 1:
            return fractions  # Final retained-candidate validation, after generation.
        if len(homographies) % len(detector.TEMPLATE_TRANSFORMS):
            raise ValueError("unexpected generation batch size")
        one, two = fractions
        supported = (one == 1.0) & (two >= 0.5)
        valid, corners = geometry(homographies, size, settings)
        rows = np.zeros(int(valid.sum()), dtype=ROW_DTYPE)
        rows["generation_id"] = np.arange(generated, generated + len(homographies))[valid]
        rows["corners_px"] = corners[valid] * scale
        rows["one_fraction"], rows["two_fraction"] = one[valid], two[valid]
        rows["floor_score"], rows["family_support"], rows["camera_error"] = np.nan, np.nan, np.nan
        rows["line_counts"] = -1
        current = {"homographies": homographies[supported].copy(),
                   "corners": corners[valid & supported].copy(),
                   "row_indices": np.flatnonzero(supported[valid]), "rows": rows}
        batches.append(rows)
        generated += len(homographies)
        player_count += int(supported.sum())
        return fractions

    def observe_score(homographies: np.ndarray, maps: np.ndarray, score_settings: Any, lines: tuple) -> tuple:
        nonlocal score_inputs
        if not np.array_equal(homographies, current["homographies"]):
            raise ValueError("score inputs differ from the observed player subset")
        result = original_score(homographies, maps, score_settings, lines)
        corners, scores, means, counts = result
        if not np.array_equal(corners, current["corners"]):
            raise ValueError("geometry mask or row ordering differs from detector._score")
        rows, indices = current["rows"], current["row_indices"]
        rows["floor_score"][indices] = scores
        rows["family_support"][indices] = means
        rows["line_counts"][indices] = counts
        if camera_rows:
            raise ValueError("previous camera checks were not consumed")
        camera_rows.extend(indices[scores >= 0].tolist())
        score_inputs += len(homographies)
        return result

    def observe_net(corners: np.ndarray, dimensions: tuple) -> tuple:
        index = camera_rows.popleft()
        rows = current["rows"]
        if not np.array_equal(corners, rows["corners_px"][index]):
            raise ValueError("camera row identity differs from the floor output")
        result = original_net(corners, dimensions)
        rows["camera_error"][index] = result[1]
        return result

    zone.player_fractions, detector._score, zone.net_segments = observe_players, observe_score, observe_net
    try:
        traced = final_output(zone.detect(frame, feet, settings, segments_px=segments))
    finally:
        zone.player_fractions, detector._score, zone.net_segments = original_player, original_score, original_net
    if baseline != traced:
        raise ValueError(f"tracing changed detector output for {source['id']}")
    if generated != baseline["generated"] or player_count != baseline["with_players"] or score_inputs != player_count:
        raise ValueError("instrumented hypothesis accounting differs from detector")
    if camera_rows:
        raise ValueError("unconsumed camera checks")
    rows = np.concatenate(batches)
    if np.isfinite(rows["floor_score"]).sum() != baseline["scored"]:
        raise ValueError("geometry-valid floor rows differ from detector count")
    return {"id": source["id"], "settings": asdict(settings), "exact_output_control": True,
            "final": baseline}, rows


def boundary_proxy(corners: np.ndarray, reference: dict, dimensions: dict) -> np.ndarray:
    """Rank diagnostic examples by finite outer-boundary distances at 1280x720.

    This proxy uses the unchanged outer-corner template with zero click inset.
    Reported shortlisted boundary metrics separately apply the requested inset.
    """
    scale = np.array([1280 / dimensions["width"], 720 / dimensions["height"]])
    scaled = corners * scale
    squared = np.zeros(len(corners))
    count = 0
    for landmark in reference.get("landmarks", []):
        court_point = np.asarray(landmark["court_m"])
        point = np.asarray(landmark["image_px"]) * scale
        for boundary in boundary_metrics._boundary_names(court_point):
            first, last = {"left": (0, 3), "top": (0, 1), "right": (1, 2), "bottom": (3, 2)}[boundary]
            start, vector = scaled[:, first], scaled[:, last] - scaled[:, first]
            fraction = np.clip(np.sum((point - start) * vector, axis=1) / np.sum(vector**2, axis=1), 0, 1)
            squared += np.sum((point - start - fraction[:, None] * vector)**2, axis=1)
            count += 1
    if not count:
        raise ValueError("boundary diagnostics require outer-boundary landmarks")
    return np.sqrt(squared / count)


def summarise(record: dict, rows: np.ndarray, source: dict, reference: dict, zone: Any, inset: float) -> dict:
    settings = detector.Settings(**record["settings"])
    corners = rows["corners_px"]
    errors = np.linalg.norm(corners - np.asarray(reference["corners_px"]), axis=2)
    boundary = boundary_proxy(corners, reference, source["dimensions"])
    players = (rows["one_fraction"] == 1) & (rows["two_fraction"] >= 0.5)
    floor = rows["floor_score"] >= 0
    camera = floor & (rows["camera_error"] <= 0.1)
    phases = {"geometry_before_players": np.ones(len(rows), dtype=bool),
              "players_and_geometry": players, "floor_survivors": floor, "camera_survivors": camera}
    record["counts"] = {name: int(mask.sum()) for name, mask in phases.items()}
    record["counts"]["support_mean_pass"] = int(np.all(rows["family_support"] >= settings.min_family_support, axis=1).sum())
    record["counts"]["distinct_line_pass"] = int(np.all(rows["line_counts"] >= settings.min_supported_lines, axis=1).sum())
    record["subgate_count_population"] = "players_and_geometry"
    record["diagnostic_rankings"] = {}
    selected = set()
    for phase, mask in phases.items():
        indices = np.flatnonzero(mask)
        rankings = {}
        for name, values in {"max_corner_native_px": errors.max(axis=1), "boundary_proxy_1280_px": boundary}.items():
            order = indices[np.argsort(values[indices], kind="stable")[:5]]
            rankings[name] = [{"generation_id": int(rows["generation_id"][index]), "value": float(values[index])}
                              for index in order]
            selected.update(order.tolist())
        record["diagnostic_rankings"][phase] = rankings
    draw = int(np.random.default_rng(20260909).integers(len(rows)))
    selected.add(draw)
    record["random_sample"] = {"seed": 20260909, "population": "all geometry-valid generated rows",
                               "row_index": draw, "generation_id": int(rows["generation_id"][draw])}
    width, height = source["dimensions"]["width"], source["dimensions"]["height"]
    resize = min(1., settings.max_dimension / max(width, height))
    size = (round(width * resize), round(height * resize))
    scale = np.array([width, height]) / size
    segments = np.asarray(source["segments_px"]) / np.tile(scale, 2)
    families = detector._wide_line_families(segments)
    maps = detector._distance_maps(families, size)
    merged = tuple(detector._merge_lines(family, settings) for family in families)
    record["examples"] = []
    for index in sorted(selected):
        candidate = corners[index]
        transform = cv2.getPerspectiveTransform(detector.CORNER_COURT_M, (candidate / scale).astype(np.float32))
        _, scores, means, counts = detector._score(transform[None], maps, settings, merged)
        _, camera_error, _ = zone.net_segments(candidate, (width, height))
        record["examples"].append({
            "generation_id": int(rows["generation_id"][index]), "corners_px": candidate.tolist(),
            "max_corner_native_px": float(errors[index].max()), "boundary_proxy_1280_px": float(boundary[index]),
            "player_pass": bool(players[index]), "one_fraction": float(rows["one_fraction"][index]),
            "two_fraction": float(rows["two_fraction"][index]),
            "original_floor_score": float(rows["floor_score"][index]) if players[index] else None,
            "rescored_floor_score": float(scores[0]), "family_support": means[0].tolist(),
            "line_counts": counts[0].tolist(), "camera_error": camera_error,
            "boundary_metrics": boundary_metrics.measure(candidate, reference, (width, height),
                                                           reference.get("clicked_corner_indices", [0, 1, 2, 3]), inset),
        })
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ids", nargs="*")
    parser.add_argument("--click-inset-m", type=float, default=0.005)
    parser.add_argument("--save-arrays", action="store_true")
    args = parser.parse_args()
    cv2.setNumThreads(1)
    sys.path.insert(0, str(args.legacy.resolve()))
    zone = importlib.import_module("zone_net")
    packed = read(args.inputs)
    args.output.mkdir(parents=True, exist_ok=True)
    for source in packed["cases"]:
        if args.ids and source["id"] not in args.ids:
            continue
        record, rows = capture(source, zone, detector.Settings(wide_families=True, min_supported_lines=3))
        record = summarise(record, rows, source, packed["references"][source["id"]], zone, args.click_inset_m)
        record["schema"] = "gx-generation-gate-trace/1"
        record["labels_used_only_after_detection"] = True
        record["click_inset_m"] = args.click_inset_m
        write(args.output / f"{source['id']}.json.gz", record)
        if args.save_arrays:
            with lzma.open(args.output / f"{source['id']}.npy.xz", "wb", format=lzma.FORMAT_XZ, preset=9) as output:
                np.save(output, rows, allow_pickle=False)
        print(source["id"], record["counts"], flush=True)


if __name__ == "__main__":
    main()
