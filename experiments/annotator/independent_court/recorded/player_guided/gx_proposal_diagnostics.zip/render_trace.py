"""Render saved proposal examples selected after detection by reference distance."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from experiments.annotator.independent_court.render_stripe_overlays import (
    court_lines,
    draw_lines,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--frames", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    font = ImageFont.truetype("DejaVuSans.ttf", 21)
    small_font = ImageFont.truetype("DejaVuSans.ttf", 18)
    for path in sorted(args.results.glob("*.json.gz")):
        record = json.loads(gzip.decompress(path.read_bytes()))
        order = record["diagnostic_rankings"]["players_and_geometry"]["boundary_proxy_1280_px"]
        if not order:
            continue
        selected = next(example for example in record["examples"] if example["generation_id"] == order[0]["generation_id"])
        with Image.open(args.frames / f"{record['id']}.png") as source:
            scale = np.array([1280 / source.width, 720 / source.height])
            frame = source.convert("RGB").resize((1280, 720), Image.Resampling.LANCZOS)
        lines = court_lines(np.asarray(selected["corners_px"]), scale)
        overlay = frame.copy()
        draw_lines(overlay, lines, "#cc00cc", False, (0, 0, 1280, 720))
        image = Image.new("RGB", (2560, 830), "white")
        image.paste(frame, (0, 110))
        image.paste(overlay, (1280, 110))
        draw = ImageDraw.Draw(image)
        draw.text((15, 10), f"{record['id']} — source", fill="black", font=font)
        draw.text((1295, 10), f"Original proposal {selected['generation_id']} — magenta court markings", fill="black", font=font)
        rms = selected["boundary_metrics"]["boundary_landmark_rms_px"]
        draw.text((1295, 43), f"Chosen afterwards using reference boundaries; boundary RMS {rms:.2f}px at 1280x720", fill="black", font=small_font)
        draw.text((1295, 74), "Diagnostic example; the unchanged detector rejects this court.", fill="black", font=small_font)
        image.save(args.output / f"{record['id']}.jpg", quality=94)


if __name__ == "__main__":
    main()
