"""Render saved GX recovery results without generating, selecting or fitting courts."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from run_trace import read

from experiments.annotator.independent_court.render_stripe_overlays import (
    court_lines,
    draw_lines,
)


def panel(frame: Image.Image, scale: np.ndarray, corners: list, title: str, subtitle: str) -> Image.Image:
    shown = frame.copy()
    draw_lines(shown, court_lines(np.asarray(corners), scale), "#cc00cc", False, (0, 0, 1280, 720))
    result = Image.new("RGB", (1280, 820), "white")
    result.paste(shown, (0, 100))
    draw = ImageDraw.Draw(result)
    draw.text((15, 10), title, font=ImageFont.truetype("DejaVuSans.ttf", 22), fill="black")
    draw.text((15, 47), subtitle, font=ImageFont.truetype("DejaVuSans.ttf", 18), fill="black")
    draw.text((15, 74), "Reference-selected diagnostic; automatic selection is not evaluated.",
              font=ImageFont.truetype("DejaVuSans.ttf", 16), fill="black")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refits", type=Path, required=True)
    parser.add_argument("--caps", type=Path, required=True)
    parser.add_argument("--frames", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for path in sorted(args.refits.glob("*.json.gz")):
        record = read(path)
        with Image.open(args.frames / f"{record['id']}.png") as source:
            scale = np.array([1280 / source.width, 720 / source.height])
            frame = source.convert("RGB").resize((1280, 720), Image.Resampling.LANCZOS)
        for model in ("legacy", "physical"):
            entries = {entry["stage"]: entry for entry in record["entries"] if entry["model"] == model}
            if "refit" not in entries:
                continue
            comparison = Image.new("RGB", (2560, 820), "white")
            for index, stage in enumerate(("start", "refit")):
                entry = entries[stage]
                title = f"{record['id']} — {'Original start' if stage == 'start' else model.capitalize() + ' paint refit'}"
                rms = entry["boundary_metrics"]["boundary_landmark_rms_px"]
                displayed = panel(frame, scale, entry["corners_px"], title, f"Boundary RMS: {rms:.2f}px at 1280x720")
                comparison.paste(displayed, (1280 * index, 0))
            comparison.save(args.output / f"{record['id']}__{model}.jpg", quality=94)
    for record in read(args.caps)["records"]:
        with Image.open(args.frames / f"{record['id']}.png") as source:
            scale = np.array([1280 / source.width, 720 / source.height])
            frame = source.convert("RGB").resize((1280, 720), Image.Resampling.LANCZOS)
        comparison = Image.new("RGB", (2560, 820), "white")
        for index, arm in enumerate(("baseline", "all_pairs")):
            entry = record[arm]["best"]["max_corner_native_px"]
            title = f"{record['id']} — {'Usual rectangle sample' if arm == 'baseline' else 'All available rectangles'}"
            error = entry["value"] * scale[0]
            displayed = panel(frame, scale, entry["corners_px"], title, f"Nearest by all four corners; maximum error: {error:.2f}px at 1280x720")
            comparison.paste(displayed, (1280 * index, 0))
        comparison.save(args.output / f"{record['id']}__cap.jpg", quality=94)


if __name__ == "__main__":
    main()
