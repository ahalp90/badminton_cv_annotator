"""Run the unchanged GX refitter from the approved complete-search frame-5 court."""

from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path
from time import perf_counter

import cv2
import numpy as np

CASE_ID = "gxBQ_window_00_frame_5"
GENERATION_ID = 6476322


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--caps", type=Path, required=True)
    parser.add_argument("--trace-directory", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path[:0] = [str(args.trace_directory.resolve()), str(args.legacy.resolve())]
    trace = importlib.import_module("run_trace")
    refitter = importlib.import_module("refit_examples")
    legacy = importlib.import_module("run_alignment")
    packed = trace.read(args.inputs)
    source = next(case for case in packed["cases"] if case["id"] == CASE_ID)
    reference = packed["references"][CASE_ID]
    cap = next(record for record in trace.read(args.caps)["records"] if record["id"] == CASE_ID)
    selected = cap["all_pairs"]["best"]["max_corner_native_px"]
    assert selected["generation_id"] == GENERATION_ID

    # Adapt the explicitly selected court to the existing runner's input contract.
    # This is not a new boundary ranking or an automatic selection result.
    selected_trace = {
        "diagnostic_rankings": {"players_and_geometry": {
            "boundary_proxy_1280_px": [{"generation_id": GENERATION_ID}],
        }},
        "examples": [selected],
    }
    cv2.setNumThreads(1)
    started = perf_counter()
    result = refitter.run_case(source, selected_trace, reference, legacy)
    result["elapsed_s"] = perf_counter() - started
    result["start_selection"] = "saved all-pairs minimum maximum-corner error, generation 6476322"
    result["user_judgement"] = "starting court approved; refitted courts not yet visually assessed"
    dimensions = source["dimensions"]
    display_scale = np.array([1280 / dimensions["width"], 720 / dimensions["height"]])
    reference_corners = np.asarray(reference["corners_px"])
    for entry in result["entries"]:
        if entry["stage"] == "start":
            np.testing.assert_array_equal(entry["corners_px"], selected["corners_px"])
        residual = (np.asarray(entry["corners_px"]) - reference_corners) * display_scale
        entry["max_corner_1280_px"] = float(np.linalg.norm(residual, axis=1).max())
        print(entry["model"], entry["stage"],
              "boundary RMS", entry["boundary_metrics"]["boundary_landmark_rms_px"],
              "max corner", entry["max_corner_1280_px"], flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    trace.write(args.output, result)
    print("elapsed seconds", result["elapsed_s"], flush=True)


if __name__ == "__main__":
    main()
