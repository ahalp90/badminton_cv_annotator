# Approved-court refit control

One saved GX frame-5 complete-search court (generation 6476322) is passed to
the existing refit_examples.run_case. Both legacy and physical paint conventions
and all fitting settings remain unchanged. No search or automatic selection runs.

The result records original/refitted coordinates, boundary and corner errors,
original gate evidence, optimisation outcomes and elapsed seconds. Reference
labels select the saved start and measure errors, not the optimisation objective.

Replay from the repository root at checkpoint 6f8d8c6. Extract the adjacent
gx_proposal_diagnostics.zip for refit_examples.py, run_trace.py and
rectangle_cap.json.gz; extension_diagnostics.zip for gx/inputs.json.gz; and
marking_refit_replay.zip for the legacy Python helpers including run_alignment.py.
Extract this archive separately. Supply those extracted paths to:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=src:. \
  python run_close_refit.py \
  --inputs INPUT_DIRECTORY/gx/inputs.json.gz \
  --caps TRACE_DIRECTORY/rectangle_cap.json.gz \
  --trace-directory TRACE_DIRECTORY --legacy LEGACY_DIRECTORY \
  --output fresh_result.json.gz
```

The recorded numerical environment used Python 3.11.13, NumPy 2.4.6,
OpenCV 5.0.0 and SciPy 1.17.1. The adjacent gx_proposal_trace.md report explains
the mixed metric result. Only the starting court has prior visual approval.
