"""Attribute decisive raster samples to individual cached fragments without rescoring courts."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from run_raster_matching import read, write

from experiments.annotator.independent_court import detector

TARGETS = (
    ('gxBQ_window_00_frame_5', 'complete_search_6476322', (4, 11)),
    ('gxBQ_window_00_frame_0', 'reference', (2,)),
    ('am3_window_00_frame_0', 'stripe_legacy_0000_original', (8,)),
    ('shuttleset_03_scene_0017', 'junction_legacy_0030_refit_legacy_start', (2, 5)),
)


def inspect(case: dict, saved: dict, court_id: str, intervals: tuple[int, ...]) -> list[dict]:
    """Use individual-fragment rasters to verify each union-map sample distance."""
    entry = next(item for item in saved['entries'] if item['id'] == court_id)
    fragments = np.asarray(case['segments_px']) / np.tile(saved['native_scale'], 2)
    vectors = fragments[:, 2:] - fragments[:, :2]
    angles = np.degrees(np.arctan2(vectors[:, 1], vectors[:, 0]))
    pixels = np.asarray(entry['sample_pixels'])[list(intervals)]
    distances = np.empty((len(intervals), pixels.shape[1], len(fragments)))
    for first in range(0, len(fragments), 2):
        maps = detector._distance_maps((fragments[first:first + 1], fragments[first + 1:first + 2]),
                                       tuple(saved['working_size']))
        for offset in range(min(2, len(fragments) - first)):
            distances[:, :, first + offset] = maps[offset, pixels[..., 1], pixels[..., 0]]
    records = []
    for row, interval in enumerate(intervals):
        access_records = {}
        for access, arm_name in (('family', 'family_family'), ('projected', 'projected_all'), ('all', 'all_all')):
            ids = {'family': saved['family_fragment_ids'][interval // 6],
                   'projected': entry['projected_fragment_ids'][interval], 'all': list(range(len(fragments)))}[access]
            selected = distances[row][:, ids]
            nearest = np.asarray(ids)[selected.argmin(axis=1)] if ids else np.full(pixels.shape[1], -1)
            best = selected.min(axis=1) if ids else np.full(pixels.shape[1], np.finfo(np.float32).max)
            actual = np.asarray(entry['arms'][arm_name]['sample_raster_distances_px'][interval])
            # An empty mask uses OpenCV's large finite sentinel; only non-empty
            # selections have meaningful nearest-fragment distance attribution.
            if ids:
                np.testing.assert_allclose(best, actual, rtol=2e-7, atol=1e-6)
                np.testing.assert_array_equal(best <= case['settings']['support_distance'],
                                              actual <= case['settings']['support_distance'])
            covered = actual <= case['settings']['support_distance']
            access_records[access] = {'nearest_fragment_ids': nearest.tolist(),
                                      'sample_distances_px': actual.tolist(), 'covered_samples': covered.tolist(),
                                      'individual_union_max_distance_delta_px': float(np.max(np.abs(best - actual)))
                                      if ids else None}
        relevant = np.flatnonzero((distances[row] <= case['settings']['support_distance']).any(axis=0))
        contributors = []
        for raw_id in relevant:
            contributors.append({'raw_id': int(raw_id), 'angle_deg': float(angles[raw_id]),
                                 'endpoints_working_px': fragments[raw_id].tolist(),
                                 'sample_ids_within_radius': np.flatnonzero(
                                     distances[row, :, raw_id] <= case['settings']['support_distance']).tolist(),
                                 'family_access': int(raw_id) in saved['family_fragment_ids'][interval // 6],
                                 'projected_access': int(raw_id) in entry['projected_fragment_ids'][interval]})
        records.append({'case_id': case['id'], 'court_id': court_id, 'interval_id': interval,
                        'interval_name': entry['interval_names'][interval],
                        'projected_angle_deg': entry['projected_angles_deg'][interval],
                        'access': access_records, 'contributors': contributors, 'union_coverage_control_exact': True, 'distance_check_rtol': 2e-7, 'distance_check_atol': 1e-6})
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    cases = {}
    saved = {}
    for input_name, result_name in (('inputs.json.gz', 'gx_results.json.gz'),
                                    ('controls.json.gz', 'control_results.json.gz')):
        cases.update({case['id']: case for case in read(args.directory / input_name)['cases']})
        saved.update({case['id']: case for case in read(args.directory / result_name)['cases']})
    records = []
    for case_id, court_id, intervals in TARGETS:
        records.extend(inspect(cases[case_id], saved[case_id], court_id, intervals))
        print(case_id, court_id, flush=True)
    write(args.directory / 'decisive_matches.json.gz', {'records': records})


if __name__ == '__main__':
    main()
