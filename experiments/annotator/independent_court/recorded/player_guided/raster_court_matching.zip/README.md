# Raster-preserving fixed-court replay

This archive records one five-arm diagnostic on 63 frozen courts/22 frames.
Read the sibling raster_court_matching.md for the question, results and limitations.
It holds all court corners/settings fixed and changes evidence access only.

## Contents and provenance

- inputs.json.gz:25 GX courts across7 frames.
- controls.json.gz:38 older courts across15 frames.
- gx_results.json.gz and control_results.json.gz: all five arms, projected intervals,
  sample coordinates/pixels, raster distances/support, allowed raw-fragment IDs,
  merged-line pools/IDs/residuals, distinct counts, means and rejection reasons.
- run_raster_matching.py: measurement runner importing the committed
  experiments.annotator.independent_court.fixed_raster_evidence module.
- inspect_matches.py and decisive_matches.json.gz: individual-fragment raster
  attribution for six selected intervals on four fixed courts. It validates the
  saved union-map coverage without moving or rescoring the courts.
- verify_review.py and review_checks.json.gz: saved-score and pre-cap group
  inspection validating the review attribution. No different-cap arm is scored.
- check_results.py and check.json.gz: arithmetic, identity and cross-arm checks;
  also compares original raster fields with the previous saved results.

The input packs are byte-identical to fixed_court_matching.zip. Their source fields
name original archive members; selection descriptions and prior_evidence retain
why each court entered the fixed population. Source-selection adapters are private
working scripts; input packs are the portable boundary. This is a diagnostic
selection, partly label-guided, not a held-out or automatic-ranking test.

The results' source_identity contains MD5s of the four modules actually used.
input_source_identity preserves the older input pack's provenance; it is not the
new measurement module identity. input_md5 verifies each unchanged compressed pack.
Python3.11.13, NumPy2.4.6, OpenCV5.0.0 produced these results. Sum of case runtimes
11.613790779258125s includes preparation/scoring and baseline checks, excluding
imports/transfers. This is a small-case diagnostic timing, not a search benchmark.

## Scoring contract

Arm order: family_family (Original), projected_family (Fragments), family_all
(Lines), projected_all (Both), all_all (Unrestricted). First identifier selects
raw-fragment access; second selects the merged pool. Projected fragments lie
within5deg of the undirected projected marking. All arms use original residual
matching on merged lines, without adding an angle mask. The existing merge/cap32
can change pool membership: the all pool is not necessarily a superset.

Twelve intervals and24 samples each; working maximum dimension960px; visible
clipped markings must span at least12px. Original rounded fragment endpoints,
OpenCV distance transform and truncated/clipped sample pixels. Support<=4px;
mean/support threshold0.55; at least3 distinct merged lines per direction;
merged-line sampled-endpoint residual<=8px. Saved settings are authoritative.
Original family preparation uses wide_families for this whole population.

nearest_line_ids identify closest lines even when they cannot count.
counted_line_ids use-1 for ineligible matches. IDs index the saved family pool or
common all_lines array; equal numbers across different pools do not identify the
same line. Distinct counts are within each court direction. A missing finite line
residual uses-1. Empty raster maps retain OpenCV's large finite distance sentinel.
Invisible intervals contribute zero and are omitted from the family-mean denominator.
Every recorded court passed the original geometry gate, enabling all63 exact
original-score comparisons. Only floor evidence is measured, not final acceptance.

Rasters alone do not identify a nearest raw fragment. projected_fragment_ids give
allowed raw input row indices. The separate decisive attribution builds individual
fragment rasters; it records every nearby fragment and one nearest ID per sample
(first raw ID on ties). Individual minima agree with union-map support exactly.
Float32 distance rounding differs by at most7.62939453125e-6px; comparison tolerance
is rtol2e-7/atol1e-6. It does not change the4px support decision.

Non-court placements are three dimension-normalised reference shapes on each of
8 existing non-court images. No neighbouring-court control is available, and these
24 rejections are not a search-level false-acceptance rate. Random GX proposals
are not labelled negatives. User usability feedback concerns the specific saved
GX frame5 complete_search_6476322 court, not general detector readiness.

## Replay from the repository root

Use an environment with NumPy and OpenCV. The recorded versions give the strongest
numerical reproducibility. Replace python below with that environment's interpreter.

```bash
records=experiments/annotator/independent_court/recorded/player_guided
mkdir -p /tmp/gx-raster-replay /tmp/gx-finite-replay &&
unzip -q "$records/raster_court_matching.zip" -d /tmp/gx-raster-replay &&
unzip -q "$records/fixed_court_matching.zip" -d /tmp/gx-finite-replay
PYTHONPATH=src:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  python /tmp/gx-raster-replay/run_raster_matching.py \
  --inputs /tmp/gx-raster-replay/inputs.json.gz \
  --output /tmp/gx-raster-replay/gx_replayed.json.gz
PYTHONPATH=src:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  python /tmp/gx-raster-replay/run_raster_matching.py \
  --inputs /tmp/gx-raster-replay/controls.json.gz \
  --output /tmp/gx-raster-replay/controls_replayed.json.gz
python /tmp/gx-raster-replay/check_results.py \
  --directory /tmp/gx-raster-replay --baseline-directory /tmp/gx-finite-replay
PYTHONPATH=src:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  python /tmp/gx-raster-replay/inspect_matches.py --directory /tmp/gx-raster-replay
```

The checker validates the archived results. To check a replay, use a separate
copy and name the replay outputs gx_results.json.gz and control_results.json.gz.
Per-case runtime will differ; compare deterministic fields separately. Original
source archives remain available through the input packs' source references.
