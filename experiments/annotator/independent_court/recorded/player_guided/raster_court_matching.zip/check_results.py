"""Check saved raster-access results without rescoring any court."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import numpy as np

ARM_NAMES = (
    "family_family",
    "projected_family",
    "family_all",
    "projected_all",
    "all_all",
)
ARM_ACCESS = {
    "family_family": ("family", "family"),
    "projected_family": ("projected", "family"),
    "family_all": ("family", "all"),
    "projected_all": ("projected", "all"),
    "all_all": ("all", "all"),
}
BASELINE_FIELDS = (
    "floor_score",
    "family_means",
    "distinct_line_counts",
    "interval_support",
    "covered_samples",
)
POINT_FIELDS = (
    "sample_raster_distances_px",
    "covered_samples",
    "interval_support",
    "family_means",
)
FRAGMENT_FIELDS = ("nearest_line_ids", "nearest_line_residual_px")
EXPECTED_CASES = 22
EXPECTED_COURTS = 63


def read(path: Path) -> dict:
    """Read one saved JSON result pack."""
    return json.loads(gzip.decompress(path.read_bytes()))


def write(path: Path, data: dict) -> None:
    """Write deterministic gzip JSON with strict JSON numeric values."""
    encoded = json.dumps(data, allow_nan=False).encode()
    path.write_bytes(gzip.compress(encoded, mtime=0))


def check_exact(label: str, actual: object, expected: object) -> None:
    """Raise a short error when two saved fields differ exactly."""
    if actual != expected:
        raise AssertionError(f"{label} differs")


def check_array(label: str, actual: object, expected: object) -> None:
    """Compare numeric or boolean nested lists without a tolerance."""
    try:
        np.testing.assert_array_equal(np.asarray(actual), np.asarray(expected))
    except AssertionError as error:
        raise AssertionError(f"{label} differs") from error


def check_identity(source: dict, result: dict) -> None:
    """Check that a result pack records the frozen input and its schema."""
    check_exact("result input source identity", result["input_source_identity"], source["source_identity"])
    check_exact("result population", result["population"], source["population"])
    assert result["schema"] == "fixed-court-raster-access/1"


def check_arm(entry: dict, arm_name: str, settings: dict) -> None:
    """Recompute one arm's stored support and floor gate from saved arrays."""
    arm = entry["arms"][arm_name]
    assert (arm["fragment_access"], arm["line_pool"]) == ARM_ACCESS[arm_name]
    visible = np.asarray(entry["visible"], dtype=bool)
    distances = np.asarray(arm["sample_raster_distances_px"], dtype=float)
    covered = (distances <= settings["support_distance"]) & visible[:, None]
    check_array(f"{arm_name} covered samples", arm["covered_samples"], covered)

    support = covered.mean(axis=1)
    check_array(f"{arm_name} interval support", arm["interval_support"], support)
    visible_denominators = [max(int(visible[:6].sum()), 1), max(int(visible[6:].sum()), 1)]
    means = [
        float(support[:6].sum() / visible_denominators[0]),
        float(support[6:].sum() / visible_denominators[1]),
    ]
    check_array(f"{arm_name} family means", arm["family_means"], means)

    counted_ids = np.asarray(arm["counted_line_ids"])
    line_counts = []
    for first in (0, 6):
        family_ids = counted_ids[first:first + 6]
        line_counts.append(len(np.unique(family_ids[family_ids >= 0])))
    check_exact(f"{arm_name} distinct line counts", arm["distinct_line_counts"], line_counts)

    reasons = []
    for family, family_name in enumerate(("lengthwise", "crosscourt")):
        if means[family] < settings["min_family_support"]:
            reasons.append(f"{family_name}_mean")
        if line_counts[family] < settings["min_supported_lines"]:
            reasons.append(f"{family_name}_distinct_lines")
    check_exact(f"{arm_name} rejection reasons", arm["rejection_reasons"], reasons)
    floor_score = -1.0 if reasons else float(np.asarray(means).mean())
    check_exact(f"{arm_name} floor score", arm["floor_score"], floor_score)


def check_cross_arm_consistency(entry: dict) -> None:
    """Check invariants shared by pools and by fragment-access choices."""
    arms = entry["arms"]
    for first, second in (("family_family", "family_all"), ("projected_family", "projected_all")):
        for field in POINT_FIELDS:
            check_array(f"{field} across {first}/{second}", arms[first][field], arms[second][field])

    for same_pool in (("family_family", "projected_family"), ("family_all", "projected_all", "all_all")):
        first = same_pool[0]
        for other in same_pool[1:]:
            for field in FRAGMENT_FIELDS:
                check_array(f"{field} across {first}/{other}", arms[first][field], arms[other][field])


def baseline_entries(directory: Path, result_name: str) -> dict[tuple[str, str], dict]:
    """Index the previous four-arm results by case and court ID."""
    result = read(directory / result_name)
    entries = {}
    for case in result["cases"]:
        for entry in case["entries"]:
            key = (case["id"], entry["id"])
            if key in entries:
                raise AssertionError(f"duplicate baseline entry {key}")
            entries[key] = entry
    return entries


def check_pack(
    source: dict,
    result: dict,
    previous_entries: dict[tuple[str, str], dict],
    role_counts: dict[str, dict[str, list[int]]],
) -> tuple[int, float]:
    """Check one frozen input pack and return court count and runtime total."""
    check_identity(source, result)
    check_exact("case IDs", [case["id"] for case in result["cases"]], [case["id"] for case in source["cases"]])
    runtime = 0.0
    court_count = 0
    for source_case, result_case in zip(source["cases"], result["cases"]):
        check_exact("case source", result_case["source"], source_case["source"])
        check_exact("case settings", result_case["settings"], source_case["settings"])
        check_exact("court IDs", [court["id"] for court in result_case["entries"]],
                    [court["id"] for court in source_case["courts"]])
        assert len(result_case["entries"]) == len(source_case["courts"])
        runtime += result_case["runtime_s"]
        for source_court, entry in zip(source_case["courts"], result_case["entries"]):
            check_exact("court role", entry["role"], source_court["role"])
            check_exact("court corners", entry["corners_px"], source_court["corners_px"])
            assert entry["original_score_control_exact"] is True
            for arm_name in ARM_NAMES:
                check_arm(entry, arm_name, source_case["settings"])

            baseline = previous_entries[(source_case["id"], source_court["id"])]
            for field in BASELINE_FIELDS:
                check_exact(f"baseline {field}", entry["arms"]["family_family"][field],
                            baseline["arms"]["raster_family"][field])
            check_cross_arm_consistency(entry)

            role = source_court["role"]
            if role not in role_counts:
                role_counts[role] = {name: [0, 0] for name in ARM_NAMES}
            for arm_name in ARM_NAMES:
                counts = role_counts[role][arm_name]
                counts[1] += 1
                counts[0] += int(entry["arms"][arm_name]["floor_score"] >= 0)
            court_count += 1
    return court_count, runtime


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=Path(__file__).parent)
    parser.add_argument("--baseline-directory", type=Path, default=Path(__file__).parent.parent / "gx_matching")
    args = parser.parse_args()

    role_counts: dict[str, dict[str, list[int]]] = {}
    total_cases = 0
    total_courts = 0
    runtime_by_pack = {}
    for input_name, result_name, pack_name in (
        ("inputs.json.gz", "gx_results.json.gz", "gx"),
        ("controls.json.gz", "control_results.json.gz", "controls"),
    ):
        source = read(args.directory / input_name)
        result = read(args.directory / result_name)
        previous_entries = baseline_entries(args.baseline_directory, result_name)
        courts, runtime = check_pack(source, result, previous_entries, role_counts)
        total_cases += len(source["cases"])
        total_courts += courts
        runtime_by_pack[pack_name] = runtime

    assert total_cases == EXPECTED_CASES
    assert total_courts == EXPECTED_COURTS
    runtime_by_pack["total"] = sum(runtime_by_pack.values())
    summary = {
        "schema": "fixed-court-raster-access-check/1",
        "case_count": total_cases,
        "court_count": total_courts,
        "arms": ARM_NAMES,
        "role_counts": role_counts,
        "runtime_s": runtime_by_pack,
        "sum_case_runtime_s": runtime_by_pack["total"],
        "checks": "frozen identity, exact baseline raster family, raster support arithmetic, and arm invariants",
    }
    write(args.directory / "check.json.gz", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
