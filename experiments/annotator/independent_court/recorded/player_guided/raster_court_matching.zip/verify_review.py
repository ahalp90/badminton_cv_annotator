"""Verify review attributions from saved courts; do not score any new experiment arm."""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import numpy as np
from run_raster_matching import read, write

from experiments.annotator.independent_court import detector


def main() -> None:
    root = Path(__file__).parent
    losses = []
    controls = []
    pool_flips = []
    for input_name, result_name in (('inputs.json.gz', 'gx_results.json.gz'),
                                    ('controls.json.gz', 'control_results.json.gz')):
        inputs = read(root / input_name)
        results = read(root / result_name)
        for case, saved in zip(inputs['cases'], results['cases']):
            settings = detector.Settings(**case['settings'])
            segments = np.asarray(case['segments_px']) / np.tile(saved['native_scale'], 2)
            # _merge_lines considers at most 300 fragments. Raising only its final
            # slice reveals already-formed groups; no floor score is calculated.
            before_slice = detector._merge_lines(segments, replace(settings, max_family_lines=300))
            np.testing.assert_array_equal(before_slice[:settings.max_family_lines], saved['all_lines'])
            for entry in saved['entries']:
                arms = entry['arms']
                for point_access in ('family', 'projected'):
                    if (arms[f'{point_access}_family']['floor_score'] >= 0) != (
                            arms[f'{point_access}_all']['floor_score'] >= 0):
                        pool_flips.append({'case_id': case['id'], 'court_id': entry['id'],
                                           'point_access': point_access})
                if entry['role'] in ('noncourt_transplant', 'gx_random_geometry'):
                    controls.append({'case_id': case['id'], 'court_id': entry['id'], 'role': entry['role'],
                                     'means': arms['all_all']['family_means'],
                                     'counts': arms['all_all']['distinct_line_counts'],
                                     'reasons': arms['all_all']['rejection_reasons']})
                for interval, support in enumerate(arms['family_family']['interval_support']):
                    original = arms['family_family']['nearest_line_residual_px'][interval]
                    capped = arms['family_all']['nearest_line_residual_px'][interval]
                    if support < settings.min_family_support or original > 8 or capped <= 8:
                        continue
                    endpoints = np.asarray(entry['samples_working_px'])[interval, [0, -1]]
                    residuals = np.abs(endpoints @ before_slice[:, :2].T + before_slice[:, 2]).max(axis=0)
                    nearest = int(residuals.argmin())
                    losses.append({'case_id': case['id'], 'court_id': entry['id'], 'interval_id': interval,
                                   'original_residual_px': original, 'capped_residual_px': capped,
                                   'group_rank_before_slice': nearest,
                                   'group_residual_px': float(residuals[nearest]),
                                   'group_count_before_slice': len(before_slice)})
    result = {'pool_losses': losses, 'pool_gate_flips': pool_flips, 'unrestricted_controls': controls,
              'scope': 'Saved score inspection and pre-slice merged-group attribution only; no new scored arm.'}
    write(root / 'review_checks.json.gz', result)
    print('Lost matches', len(losses), 'courts', len({(row['case_id'], row['court_id']) for row in losses}))
    print('Recovered before slice', sum(row['group_residual_px'] <= 8 for row in losses))
    print('Pool flips', pool_flips)
    for row in losses:
        if row['case_id'] == 'gxBQ_window_00_frame_0':
            print(row)


if __name__ == '__main__':
    main()
