"""Score retained court candidates for bright painted-stripe contrast.

This is a private diagnostic.  It uses the canonical court plane and samples
native-resolution pixels around each painted segment.  The score is evidence
for ranking candidates and has no calibrated interpretation.
"""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from experiments.annotator.independent_court import detector

SAMPLE_COUNT = 64
SAMPLE_FRACTIONS = np.linspace(0.05, 0.95, SAMPLE_COUNT, dtype=np.float64)
CENTRE_OFFSETS_M = np.array([-0.04, -0.02, 0.0, 0.02, 0.04], dtype=np.float64)
BACKGROUND_OFFSET_M = 0.12
CONTRAST_SCALE = 64.0


def read_json(path: Path) -> Any:
    return json.loads(gzip.decompress(path.read_bytes()))


def write_json(path: Path, value: Any) -> None:
    path.write_bytes(gzip.compress(json.dumps(value, allow_nan=False).encode(), mtime=0))


def _project(homography: np.ndarray, points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    homogeneous = np.concatenate((points, np.ones((*points.shape[:-1], 1))), axis=-1)
    mapped = np.einsum("ij,...j->...i", homography, homogeneous)
    depth = mapped[..., 2]
    with np.errstate(divide="ignore", invalid="ignore"):
        pixels = mapped[..., :2] / depth[..., None]
    return pixels, depth


def score(frame: np.ndarray, corners: np.ndarray) -> float:
    """Return equal-family bright-stripe contrast for one native-resolution frame."""
    if frame.ndim == 3:
        grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)
    else:
        grey = frame.astype(np.float32)
    height, width = grey.shape
    homography = cv2.getPerspectiveTransform(
        np.asarray(detector.CORNER_COURT_M, dtype=np.float32),
        np.asarray(corners, dtype=np.float32),
    )

    segments = np.asarray(detector.SEGMENTS_M, dtype=np.float64)
    starts = segments[:, 0]
    vectors = segments[:, 1] - starts
    normals = np.stack((-vectors[:, 1], vectors[:, 0]), axis=1)
    normals /= np.linalg.norm(vectors, axis=1)[:, None]
    base = starts[:, None, :] + SAMPLE_FRACTIONS[None, :, None] * vectors[:, None, :]
    offsets = CENTRE_OFFSETS_M[None, None, :, None]
    normal = normals[:, None, None, :]
    centre = base[:, :, None, :] + offsets * normal
    left = base[:, :, None, :] + (offsets - BACKGROUND_OFFSET_M) * normal
    right = base[:, :, None, :] + (offsets + BACKGROUND_OFFSET_M) * normal
    points = np.stack((centre, left, right), axis=3)  # (segment, sample, offset, point, xy)

    pixels, depths = _project(homography, points)
    finite = np.isfinite(pixels).all(axis=-1)
    in_frame = (
        (pixels[..., 0] >= 0)
        & (pixels[..., 0] < width)
        & (pixels[..., 1] >= 0)
        & (pixels[..., 1] < height)
    )
    valid = np.all((depths > 0) & finite & in_frame, axis=3)

    def remap(points_to_sample: np.ndarray) -> np.ndarray:
        map_x = points_to_sample[..., 0].astype(np.float32).reshape(-1, 1)
        map_y = points_to_sample[..., 1].astype(np.float32).reshape(-1, 1)
        return cv2.remap(grey, map_x, map_y, cv2.INTER_LINEAR).reshape(points_to_sample.shape[:-1])

    intensity = remap(pixels)
    contrast = np.minimum(intensity[..., 0] - intensity[..., 1], intensity[..., 0] - intensity[..., 2])
    best = np.max(np.where(valid, contrast, -np.inf), axis=2)
    visible = np.any(valid, axis=2)

    family_means = []
    for family in (slice(0, 6), slice(6, 12)):
        values = np.clip(best[family][visible[family]] / CONTRAST_SCALE, 0.0, 1.0)
        if not len(values):
            raise ValueError("court family has no visible stripe samples")
        family_means.append(float(np.mean(values)))
    return float(np.mean(family_means))


def _frame_index(people_dir: Path) -> dict[str, tuple[Path, dict[str, int]]]:
    images: dict[str, tuple[Path, dict[str, int]]] = {}
    manifest = read_json(people_dir / "manifest.json.gz")
    for window in manifest["windows"]:
        record = read_json(people_dir / window["record"])
        for anchor in record["anchor_images"]:
            image_id = f"{record['id']}_frame_{anchor['frame_index']}"
            images[image_id] = (people_dir / anchor["image"], record["dimensions"])
    return images


def _score_records(
    records: list[dict[str, Any]],
    people_dir: Path,
    dataset: str,
    errors: list[str],
) -> list[dict[str, Any]]:
    image_index = _frame_index(people_dir)
    output = []
    for record in records:
        image_info = image_index.get(record["id"])
        if image_info is None:
            errors.append(f"{record['id']}: matching people image is missing")
            output.append({"id": record["id"], "dataset": dataset, "candidates": []})
            continue
        image_path, dimensions = image_info
        frame = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if frame is None:
            errors.append(f"{record['id']}: image could not be decoded")
            output.append({"id": record["id"], "dataset": dataset, "candidates": []})
            continue
        if [frame.shape[1], frame.shape[0]] != [dimensions["width"], dimensions["height"]]:
            errors.append(f"{record['id']}: image dimensions do not match people record")
            output.append({"id": record["id"], "dataset": dataset, "candidates": []})
            continue

        candidates = []
        for original_rank, candidate in enumerate(record["candidates"]):
            row = {
                "original_rank": original_rank,
                "corners": candidate["corners_px"],
                "stripe_score": None,
                "combined_score": None,
                "original_metrics": candidate.get("metrics"),
                "selected_rank": None,
            }
            try:
                stripe_score = score(frame, np.asarray(candidate["corners_px"], dtype=np.float32))
            except (ValueError, cv2.error) as exc:  # keep scoring other retained candidates
                errors.append(f"{record['id']} candidate {original_rank}: {exc}")
            else:
                row["stripe_score"] = stripe_score
                row["combined_score"] = (4.0 * float(candidate["score"]) + stripe_score) / 5.0
            candidates.append(row)

        ranked = sorted(
            ((index, row) for index, row in enumerate(candidates) if row["combined_score"] is not None),
            key=lambda item: (-item[1]["combined_score"], item[1]["original_rank"]),
        )
        for selected_rank, (index, _row) in enumerate(ranked):
            candidates[index]["selected_rank"] = selected_rank
        output.append({"id": record["id"], "dataset": dataset, "candidates": candidates})
    return output


def main() -> None:
    base = Path(__file__).parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--people", type=Path, default=base)
    parser.add_argument("--people-short", type=Path)
    parser.add_argument("--people-original", type=Path)
    parser.add_argument("--fits-short", type=Path)
    parser.add_argument("--fits-original", type=Path)
    parser.add_argument("--lines", type=Path, help="retained for compatibility with the private pipeline")
    parser.add_argument("--references", type=Path, help="retained for compatibility; labels are not read")
    parser.add_argument("--output", type=Path, default=base / "stripe_results.json.gz")
    args = parser.parse_args()
    people_short = args.people_short or args.people / "people_short"
    people_original = args.people_original or args.people / "people_original"
    fits_short = args.fits_short or args.people / "fits_short_full_search" / "results.json.gz"
    fits_original = args.fits_original or args.people / "fits_original_full_search" / "results.json.gz"

    errors: list[str] = []
    short_records = read_json(fits_short)["records"]
    original_records = [
        record for record in read_json(fits_original)["records"] if record.get("variant") == "motion_net"
    ]
    records = _score_records(short_records, people_short, "short_full_search", errors)
    records += _score_records(original_records, people_original, "original_full_search_motion_net", errors)
    result = {
        "method": {
            "segments": "detector.SEGMENTS_M",
            "samples_per_segment": SAMPLE_COUNT,
            "sample_fraction_range": [0.05, 0.95],
            "centre_offsets_m": CENTRE_OFFSETS_M.tolist(),
            "background_offset_m": BACKGROUND_OFFSET_M,
            "contrast_scale": CONTRAST_SCALE,
            "combined_score": "(4*existing_net_score+stripe_score)/5",
            "family_means": "first six and last six segments, equal family mean",
        },
        "records": records,
        "errors": errors,
    }
    write_json(args.output, result)
    for error in errors:
        print(f"score_error: {error}")
    print(f"wrote {args.output} ({len(records)} records, {sum(len(r['candidates']) for r in records)} candidates)")


if __name__ == "__main__":
    main()
