"""Private diagnostic: refine retained courts against nearby finite line fragments."""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import least_squares

from experiments.annotator.independent_court import detector, evaluate


def read(path):
    return json.loads(gzip.decompress(Path(path).read_bytes()))


def refine(corners, segments, size):
    scale = max(size)
    court_size = detector.CORNER_COURT_M.max(axis=0)
    model = detector.SEGMENTS_M / court_size
    template_h = np.concatenate((model, np.ones((*model.shape[:-1], 1))), axis=-1)
    court_lines = np.cross(template_h[:, 0], template_h[:, 1])
    observed = segments.reshape(-1, 2, 2) / scale
    observed_h = np.concatenate((observed, np.ones((*observed.shape[:-1], 1))), axis=-1)
    transform = cv2.getPerspectiveTransform(detector.UNIT_CORNERS, (corners / scale).astype(np.float32))
    history = []
    for iteration in range(4):
        projected, _ = detector.project(transform[None], model)
        projected = projected.reshape(12, 2, 2)
        lines = court_lines @ np.linalg.inv(transform)
        lines /= np.linalg.norm(lines[:, :2], axis=1)[:, None]
        distances = np.abs(np.einsum('sed,ld->sel', observed_h, lines)).max(axis=1) * scale
        # Only fragments overlapping a finite marking can constrain that marking.
        vectors = projected[:, 1] - projected[:, 0]
        positions = np.einsum('seld,ld->sel', observed[:, :, None] - projected[None, None, :, 0], vectors)
        positions /= np.square(vectors).sum(axis=1)[None, None]
        overlap = (positions.max(axis=1) >= 0) & (positions.min(axis=1) <= 1)
        distances[~overlap] = np.inf
        assignments = np.argmin(distances, axis=1)
        use = distances[np.arange(len(segments)), assignments] < 8 * scale / 960
        chosen = assignments[use]
        if len(np.unique(chosen)) < 4:
            break
        points = observed_h[use]
        def residual(parameters):
            trial = np.append(parameters, 1).reshape(3, 3)
            projected_lines = court_lines[chosen] @ np.linalg.inv(trial)
            projected_lines /= np.linalg.norm(projected_lines[:, :2], axis=1)[:, None]
            return (np.einsum('sed,sd->se', points, projected_lines) * scale).ravel()
        fit = least_squares(residual, (transform / transform[2, 2]).ravel()[:8],
                            loss='soft_l1', f_scale=2 * scale / 960, max_nfev=100)
        transform = np.append(fit.x, 1).reshape(3, 3)
        history.append({'iteration':iteration,'fragments':int(use.sum()),'markings':len(np.unique(chosen)),
                        'median_residual':float(np.median(np.abs(fit.fun))),'converged':bool(fit.success)})
    result, denominator = detector.project(transform[None], detector.UNIT_CORNERS)
    return result[0] * scale, history


def score(corners, maps, settings):
    transform = cv2.getPerspectiveTransform(detector.CORNER_COURT_M, corners.astype(np.float32))
    endpoints, denominator = detector.project(transform[None], detector.SEGMENTS_M)
    if np.any(denominator <= 0):
        return -1.0
    points, visible = detector._visible_samples(endpoints.reshape(1,12,2,2),
                                               (maps.shape[2],maps.shape[1]),settings.samples_per_line)
    pixel_x=np.clip(points[...,0],0,maps.shape[2]-1).astype(int)
    pixel_y=np.clip(points[...,1],0,maps.shape[1]-1).astype(int)
    families=np.repeat([0,1],6)[None,:,None]
    distances=maps[families,pixel_y,pixel_x]
    support=np.exp(-0.5*(distances/2.0)**2).mean(axis=-1)*visible
    means=[support[:,:6].sum()/max(visible[:,:6].sum(),1),support[:,6:].sum()/max(visible[:,6:].sum(),1)]
    return float(np.mean(means))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--group', default='short')
    parser.add_argument('--fits')
    parser.add_argument('--output')
    parser.add_argument('--references',type=Path)
    args = parser.parse_args()
    root = args.run
    people = root / f'people_{args.group}'
    manifest = read(people / 'line_manifest.json.gz')
    images = {row['id']:row['image'] for row in manifest['cases']}
    lines = {row['id']:np.array(row['segments_px']) for row in read(root / f'lines_{args.group}/deeplsd_md_default.json.gz')['cases']}
    references = read(args.references or root / 'references.json.gz')
    output = root / (args.output or f'refined_{args.group}')
    output.mkdir(exist_ok=True)
    results = []
    for row in read(root / (args.fits or f'fits_{args.group}') / 'results.json.gz')['records']:
        if row['variant'] in ('baseline', 'motion') or not row['candidates']:
            continue
        frame = cv2.imread(str(people / images[row['id']]))
        scale=min(1,960/max(frame.shape[:2]))
        size=(round(frame.shape[1]*scale),round(frame.shape[0]*scale))
        native_scale=np.array(frame.shape[1::-1])/size
        families=detector._wide_line_families(lines[row['id']]/np.tile(native_scale,2))
        maps=detector._distance_maps(families,size)
        for index, candidate in enumerate(row['candidates']):
            corners, history = refine(np.array(candidate['corners_px']), lines[row['id']], frame.shape[1::-1])
            refs = references[row['window']]
            metrics = {key:evaluate._metrics(corners, refs[key], frame.shape[1], frame.shape[0]) for key in candidate['metrics']}
            results.append({'id':row['id'],'variant':row['variant'],'candidate_index':index,
                            'corners_px':corners.tolist(),'metrics':metrics,'history':history,
                            'soft_score':score(corners/native_scale,maps,detector.DEFAULT_SETTINGS)})
            if index == 0:
                key = next(iter(metrics))
                evaluate._overlay(frame, corners, refs[key], output / f"{row['id']}__{row['variant']}.jpg")
                print(row['id'], row['variant'], metrics, flush=True)
    (output / 'results.json.gz').write_bytes(gzip.compress(json.dumps(results, allow_nan=False).encode()))


if __name__ == '__main__':
    main()
