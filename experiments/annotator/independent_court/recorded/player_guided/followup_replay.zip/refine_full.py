"""Refine full-search candidates, then repeat their original scores and gates."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import cv2
import numpy as np

from experiments.annotator.independent_court import detector, evaluate
from fit_windows import read, write
from refine_fits import refine
from camera_diagnostic import net_segments
from zone_net import player_fractions


def run(job: dict) -> dict:
    row, case = job['row'], job['case']
    width, height = case['dimensions']['width'], case['dimensions']['height']
    scale = min(1, 960 / max(width, height))
    size = (round(width * scale), round(height * scale))
    native_scale = np.array([width, height]) / size
    segments = np.asarray(case['segments_px'])
    working_segments = segments / np.tile(native_scale, 2)
    families = detector._wide_line_families(working_segments)
    settings = detector.Settings(wide_families=True, min_supported_lines=3)
    lines = tuple(detector._merge_lines(family, settings) for family in families)
    maps = detector._distance_maps(families, size)
    net_maps = detector._distance_maps((working_segments, working_segments), size)
    feet = np.asarray(case['selected_pair_feet'], dtype=float) / native_scale
    candidates, diagnostic = [], []
    for index, candidate in enumerate(row['candidates']):
        corners, history = refine(np.asarray(candidate['corners_px']), segments, (width, height))
        transform = cv2.getPerspectiveTransform(detector.CORNER_COURT_M, (corners / native_scale).astype(np.float32))
        one, two = player_fractions(transform[None], feet)
        scored_corners, scores, means, counts = detector._score(transform[None], maps, settings, lines)
        valid = len(scores) and scores[0] >= 0 and one[0] == 1 and two[0] >= .5
        score = float(scores[0]) if len(scores) else -1.
        if valid and row['variant'] == 'motion_net':
            net, error, _ = net_segments(corners, (width, height))
            valid = error <= .1
            points, visible = detector._visible_samples((net / native_scale)[None], size, 48)
            pixel_x = np.clip(points[..., 0], 0, size[0] - 1).astype(int)
            pixel_y = np.clip(points[..., 1], 0, size[1] - 1).astype(int)
            support = np.exp(-.5 * (net_maps[0, pixel_y, pixel_x] / 4.) ** 2).mean(axis=-1) * visible
            score = (3 * score + float(support.sum() / max(visible.sum(), 1))) / 4
        diagnostic.append({'original_rank': index, 'corners_px': corners.tolist(), 'history': history,
                           'eligible': bool(valid), 'score': score,
                           'metrics': evaluate._metrics(corners, case['reference'], width, height)})
        if valid:
            candidates.append(detector.Candidate(scored_corners[0], score, tuple(means[0]), tuple(counts[0])))
    retained = detector._retain([], candidates, settings)
    selected = []
    for candidate in retained:
        corners = candidate.corners_px * native_scale
        selected.append({'corners_px': corners.tolist(), 'score': candidate.score,
                         'metrics': evaluate._metrics(corners, case['reference'], width, height)})
    result = {'id': row['id'], 'variant': row['variant'], 'candidates': selected,
              'refinements': diagnostic, 'acceptance_policy': None}
    print(row['id'], row['variant'], selected[0]['metrics'] if selected else None, flush=True)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--fits', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    cases = {case['id']: case for case in read(args.cases)['cases']}
    jobs = [{'row': row, 'case': cases[row['id']]} for row in read(args.fits)['records']]
    with ProcessPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(run, jobs))
    write(args.output, {'records': results})


if __name__ == '__main__':
    main()
