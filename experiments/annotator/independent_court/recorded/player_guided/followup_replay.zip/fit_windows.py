"""Compare line-only fits with movement and centrality-guided complete courts."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import gzip
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time
from typing import Any

import cv2
import numpy as np

from experiments.annotator.independent_court import detector, evaluate, player_guided
from experiments.annotator.independent_court.temporal import pair_presence, summarise_track, track_people


def read(path: Path) -> Any:
    return json.loads(gzip.decompress(path.read_bytes()))


def write(path: Path, value: Any) -> None:
    path.write_bytes(gzip.compress(json.dumps(value, allow_nan=False).encode(), mtime=0))


def choose_pairs(record: dict, score_min: float = 0.2) -> dict:
    samples = record['samples']
    tracks = track_people(samples, score_min=score_min)
    summaries = [summarise_track(track, len(samples)) for track in tracks]
    eligible = [row for row in summaries if row['observed_fraction'] >= 0.5]
    pairs = []
    for first, second in combinations(eligible, 2):
        presence = pair_presence(tracks[first['id']], tracks[second['id']], len(samples))
        if not presence['passes_literal']:
            continue
        xs = np.array([first['median_foot_px'][0], second['median_foot_px'][0]]) / record['dimensions']['width']
        centre_x = xs.mean()
        weaker_motion = min(first['path_length_px'], second['path_length_px'])
        pairs.append({'ids':[first['id'],second['id']], **presence,
                      'movement':first['path_length_px']+second['path_length_px'],
                      'central_movement':weaker_motion/(0.10+np.abs(xs-0.5).mean()),
                      'centre_x':centre_x,
                      'median_feet':[first['median_foot_px'],second['median_foot_px']],
                      'median_heights':[first['median_height_px'],second['median_height_px']]})
    if not pairs:
        return {'motion':None, 'central':None, 'alternatives':[]}
    result = {'alternatives':pairs}
    for name, field in [('motion','movement'),('central','central_movement')]:
        selected = max(pairs, key=lambda pair:pair[field])
        feet = np.full((len(samples),2,2),np.nan)
        for slot, track_id in enumerate(selected['ids']):
            track = tracks[track_id]
            feet[track.sample_indices,slot] = track.feet_px
        result[name] = {'pair':selected, 'feet':feet}
    return result


def run(job: dict) -> dict:
    image_path = Path(job['image'])
    image = cv2.imread(str(image_path))
    if image is None:
        raise FileNotFoundError(image_path)
    line_record = job['line_record']
    if hashlib.md5(image_path.read_bytes()).hexdigest() != line_record['image_file_md5']:
        raise ValueError(f"wrong line image: {job['id']}")
    segments = np.asarray(line_record['segments_px'],dtype=float).reshape(-1,4)
    settings = detector.Settings(wide_families=True,min_supported_lines=3)
    started = time.perf_counter()
    pair = job['pair']
    if job['variant']=='baseline':
        detection = detector.detect(image,settings,segments_px=segments)
        extra = {}
    elif pair is None:
        return {'id':job['id'],'variant':job['variant'],'accepted':False,'reason':'no_persistent_pair','candidates':[]}
    else:
        if job['variant'].startswith('floor'):
            median_feet = np.asarray(pair['pair']['median_feet'])
            far = int(np.argmin(median_feet[:,1]))
            floor_y = median_feet[far,1] - float(job['variant'][5:]) * pair['pair']['median_heights'][far]
            segments = segments[np.maximum(segments[:,1],segments[:,3]) >= floor_y]
        guided = player_guided.detect(image,pair['feet'],settings,segments_px=segments,
                                       region_filter=job['variant']=='central_region')
        detection = guided.detection
        extra = {'hypotheses_generated':guided.hypotheses_generated,
                 'hypotheses_with_players':guided.hypotheses_with_players,'pair':pair['pair']}
    references = job['references']
    candidate_rows = []
    for candidate in detection.candidates:
        metrics = {frame:evaluate._metrics(candidate.corners_px,reference,image.shape[1],image.shape[0])
                   for frame,reference in references.items()}
        candidate_rows.append({'corners_px':candidate.corners_px.tolist(),'score':candidate.score,'metrics':metrics})
    result = {'id':job['id'],'window':job['window'],'variant':job['variant'],'accepted':detection.accepted,
              'reason':detection.reason,'gap':detection.score_gap,'family_line_counts':detection.family_line_counts,
              'hypotheses_scored':detection.hypotheses_scored,'seconds':time.perf_counter()-started,
              'candidates':candidate_rows, **extra}
    output = Path(job['output'])
    output.mkdir(parents=True,exist_ok=True)
    write(output/f"{job['id']}__{job['variant']}.json.gz",result)
    for frame,reference in references.items():
        predicted = detection.candidates[0].corners_px if detection.candidates else None
        evaluate._overlay(image,predicted,reference,output/f"{job['id']}__{job['variant']}__ref{frame}.jpg")
    top = candidate_rows[0]['metrics'] if candidate_rows else None
    print(job['id'],job['variant'],'accepted',detection.accepted,'top',top,flush=True)
    return result


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument('--people',type=Path,required=True)
    parser.add_argument('--lines',type=Path,required=True)
    parser.add_argument('--references',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=8)
    parser.add_argument('--all-anchors',action='store_true')
    parser.add_argument('--raw-only',action='store_true')
    parser.add_argument('--patch-seconds',type=float,default=0)
    parser.add_argument('--score-min',type=float,default=0.2)
    parser.add_argument('--variants',nargs='+',default=['baseline','motion','central','central_region'])
    args=parser.parse_args()
    refs=read(args.references)
    lines={item['id']:item for item in read(args.lines)['cases']}
    jobs=[]
    for item in read(args.people/'manifest.json.gz')['windows']:
        record=read(args.people/item['record'])
        selected=choose_pairs(record,args.score_min)
        anchors=record['anchor_images']
        if not args.all_anchors:
            anchors=[anchors[len(anchors)//2]]
        images=[(f"{record['id']}_median",record['median_image'],refs[record['id']])]
        images += [(f"{record['id']}_frame_{anchor['frame_index']}",anchor['image'],
                    {str(anchor['frame_index']):refs[record['id']][str(anchor['frame_index'])]}) for anchor in anchors]
        for image_id,relative_image,references in images:
            if args.raw_only and image_id.endswith('_median'):
                continue
            if args.patch_seconds and not image_id.endswith('_median'):
                anchor_frame=int(image_id.rsplit('_',1)[-1])
                source_samples=record['samples']
                start=max(source_samples[0]['timestamp_seconds'],anchor_frame/record['source_fps']-args.patch_seconds/2)
                start=min(start,source_samples[-1]['timestamp_seconds']-args.patch_seconds+1/record['sample_fps'])
                patch=[sample for sample in source_samples if start <= sample['timestamp_seconds'] < start+args.patch_seconds]
                selected=choose_pairs({**record,'samples':patch},args.score_min)
            for variant in args.variants:
                pair=selected['motion' if variant=='motion' else 'central']
                jobs.append({'id':image_id,'window':record['id'],'image':str(args.people/relative_image),
                             'line_record':lines[image_id],'references':references,'variant':variant,
                             'pair':pair,'output':str(args.output)})
    args.output.mkdir(parents=True,exist_ok=True)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        results=list(pool.map(run,jobs))
    write(args.output/'results.json.gz',{'records':results})


if __name__=='__main__':
    main()
