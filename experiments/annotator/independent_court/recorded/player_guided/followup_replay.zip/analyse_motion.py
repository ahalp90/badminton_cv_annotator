"""Private ranking diagnostic for residual person-box motion."""

from __future__ import annotations

import argparse
from itertools import combinations
import gzip
import json
from pathlib import Path
from typing import Any

import numpy as np

from experiments.annotator.independent_court.temporal import pair_presence, summarise_track, track_people


def _read_json(path: Path) -> Any:
    with gzip.open(path, "rt", encoding="utf-8") as source:
        return json.load(source)


def _write_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + ".tmp")
    with gzip.open(temporary, "wt", encoding="utf-8") as target:
        json.dump(value, target, allow_nan=False, separators=(",", ":"))
    temporary.replace(path)


def _patch_samples(record: dict[str, Any], anchor: dict[str, Any]) -> list[dict[str, Any]]:
    samples = record["samples"]
    anchor_seconds = anchor["frame_index"] / record["source_fps"]
    start = max(samples[0]["timestamp_seconds"], anchor_seconds - 1.5)
    start = min(start, samples[-1]["timestamp_seconds"] - 3 + 1 / record["sample_fps"])
    return [sample for sample in samples if start <= sample["timestamp_seconds"] < start + 3]


def _check_detection_alignment(
    people_samples: list[dict[str, Any]], motion_record: dict[str, Any],
) -> dict[int, list[dict[str, Any]]]:
    motion_samples = motion_record["samples"]
    motion_by_frame = {sample["frame_index"]: sample for sample in motion_samples}
    if len(motion_by_frame) != len(motion_samples):
        raise ValueError(f"{motion_record['id']}: duplicate motion frame indices")
    aligned: dict[int, list[dict[str, Any]]] = {}
    for people_sample in people_samples:
        frame_index = people_sample["frame_index"]
        if frame_index not in motion_by_frame:
            raise ValueError(f"{motion_record['id']}: missing motion frame {frame_index}")
        motion_detections = motion_by_frame[frame_index]["detections"]
        people_boxes = people_sample["bboxes"]
        people_scores = people_sample["scores"]
        if len(motion_detections) != len(people_boxes) or len(people_boxes) != len(people_scores):
            raise ValueError(f"{motion_record['id']}: detection rows do not align at frame {frame_index}")
        for detection_index, (motion_detection, bbox, score) in enumerate(
            zip(motion_detections, people_boxes, people_scores)
        ):
            if not np.allclose(motion_detection["bbox"], bbox, rtol=0, atol=1e-6):
                raise ValueError(f"{motion_record['id']}: bbox index drift at frame {frame_index}, detection {detection_index}")
            if not np.isclose(motion_detection["score"], score, rtol=0, atol=1e-6):
                raise ValueError(f"{motion_record['id']}: score index drift at frame {frame_index}, detection {detection_index}")
        aligned[frame_index] = motion_detections
    return aligned


def _summary(values: list[float]) -> tuple[float | None, float | None, float | None]:
    if not values:
        return None, None, None
    array = np.asarray(values, dtype=np.float64)
    return float(array.mean()), float(np.median(array)), float(np.percentile(array, 90))


def _track_motion(
    track: Any,
    samples: list[dict[str, Any]],
    motion_by_frame: dict[int, list[dict[str, Any]]],
) -> dict[str, float | int | None]:
    flow_pixels: list[float] = []
    flow_heights: list[float] = []
    for sample_index, detection_index in zip(track.sample_indices, track.detection_indices):
        frame_index = samples[sample_index]["frame_index"]
        motion = motion_by_frame[frame_index][detection_index]
        quantiles = motion.get("flow_quantiles")
        if quantiles is None or quantiles.get("p75") is None:
            continue
        flow_p75 = float(quantiles["p75"])
        flow_pixels.append(flow_p75)
        box_height = motion.get("box_height")
        if box_height is not None and float(box_height) > 0:
            flow_heights.append(flow_p75 / float(box_height))
    mean_flow_px, median_flow_px, p90_flow_px = _summary(flow_pixels)
    mean_flow_heights, median_flow_heights, p90_flow_heights = _summary(flow_heights)
    return {
        "motion_observations": len(flow_pixels),
        "normalised_motion_observations": len(flow_heights),
        "mean_flow_px": mean_flow_px,
        "median_flow_px": median_flow_px,
        "p90_flow_px": p90_flow_px,
        "mean_flow_heights": mean_flow_heights,
        "median_flow_heights": median_flow_heights,
        "p90_flow_heights": p90_flow_heights,
    }


def _eligible(summary: dict[str, Any], width: int, height: int) -> bool:
    median_x, median_y = summary["median_foot_px"]
    return (
        summary["observed_fraction"] >= 0.5
        and 0 <= median_x < width
        and 0 <= median_y < height
    )


def _pair_row(
    first: dict[str, Any], second: dict[str, Any], first_track: Any, second_track: Any, sample_count: int, width: int,
) -> dict[str, Any] | None:
    presence = pair_presence(first_track, second_track, sample_count)
    if not presence["passes_literal"]:
        return None
    first_motion = first["mean_flow_heights"]
    second_motion = second["mean_flow_heights"]
    central_distance = (
        abs(first["median_foot_px"][0] / width - 0.5)
        + abs(second["median_foot_px"][0] / width - 0.5)
    ) / 2
    min_motion = None if first_motion is None or second_motion is None else min(first_motion, second_motion)
    sum_motion = None if first_motion is None or second_motion is None else first_motion + second_motion
    return {
        "ids": [first["id"], second["id"]],
        **presence,
        "member_mean_flow_heights": [first_motion, second_motion],
        "min_motion": min_motion,
        "sum_motion": sum_motion,
        "central_distance": central_distance,
        "central_score": None if min_motion is None else min_motion / (0.1 + central_distance),
        "member_mean_flow_px": [first["mean_flow_px"], second["mean_flow_px"]],
    }


def _feet_for_pair(pair: dict[str, Any], tracks_by_id: dict[int, Any], sample_count: int) -> list[list[list[float] | None]]:
    feet: list[list[list[float] | None]] = [[[None, None], [None, None]] for _ in range(sample_count)]
    for slot, track_id in enumerate(pair["ids"]):
        track = tracks_by_id[track_id]
        for sample_index, foot in zip(track.sample_indices, track.feet_px):
            feet[sample_index][slot] = [float(foot[0]), float(foot[1])]
    return feet


def _selected(pair_rows: list[dict[str, Any]], field: str, tracks_by_id: dict[int, Any], sample_count: int) -> dict[str, Any] | None:
    ranked = [pair for pair in pair_rows if pair[field] is not None]
    if not ranked:
        return None
    ordered = sorted(ranked, key=lambda pair: (-pair[field], pair["ids"]))
    pair = ordered[0]
    return {"pair": pair, "feet": _feet_for_pair(pair, tracks_by_id, sample_count)}


def analyse_patch(
    patch_id: str,
    samples: list[dict[str, Any]],
    motion_by_frame: dict[int, list[dict[str, Any]]],
    dimensions: dict[str, Any],
) -> dict[str, Any]:
    tracks = track_people(samples)
    summaries: list[dict[str, Any]] = []
    for track in tracks:
        summary = summarise_track(track, len(samples))
        summary.update(_track_motion(track, samples, motion_by_frame))
        summaries.append(summary)
    width, height = int(dimensions["width"]), int(dimensions["height"])
    sorted_tracks = sorted(
        summaries,
        key=lambda track: (
            track["mean_flow_heights"] is None,
            -(track["mean_flow_heights"] or 0),
            track["id"],
        ),
    )
    eligible = [summary for summary in summaries if _eligible(summary, width, height)]
    tracks_by_id = {track.track_id: track for track in tracks}
    pairs: list[dict[str, Any]] = []
    for first, second in combinations(eligible, 2):
        pair = _pair_row(first, second, tracks_by_id[first["id"]], tracks_by_id[second["id"]], len(samples), width)
        if pair is not None:
            pairs.append(pair)
    return {
        "id": patch_id,
        "sample_frame_indices": [sample["frame_index"] for sample in samples],
        "pairs": {
            "central": sorted(
                pairs,
                key=lambda pair: (pair["central_score"] is None, -(pair["central_score"] or 0), pair["ids"]),
            )[:8],
            "motion": sorted(
                pairs,
                key=lambda pair: (pair["sum_motion"] is None, -(pair["sum_motion"] or 0), pair["ids"]),
            )[:8],
        },
        "tracks": sorted_tracks,
        "selected": {
            "central": _selected(pairs, "central_score", tracks_by_id, len(samples)),
            "motion": _selected(pairs, "sum_motion", tracks_by_id, len(samples)),
        },
    }


def _motion_path(motion_dir: Path, record_id: str) -> Path:
    path = motion_dir / f"{record_id}.json.gz"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def analyse_record(record: dict[str, Any], motion_record: dict[str, Any]) -> dict[str, Any]:
    people_samples = record["samples"]
    motion_by_frame = _check_detection_alignment(people_samples, motion_record)
    patches = [{"id": "whole", "samples": people_samples}]
    for anchor in record.get("anchor_images", []):
        patches.append({"id": f"frame_{anchor['frame_index']}", "samples": _patch_samples(record, anchor)})
    return {
        "id": record["id"],
        "patches": [
            analyse_patch(patch["id"], patch["samples"], motion_by_frame, record["dimensions"])
            for patch in patches
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--people", type=Path, required=True)
    parser.add_argument("--motion", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args(argv)
    manifest = _read_json(arguments.people / "manifest.json.gz")
    records: list[dict[str, Any]] = []
    for entry in manifest["windows"]:
        record = _read_json(arguments.people / entry["record"])
        motion_record = _read_json(_motion_path(arguments.motion, record["id"]))
        records.append(analyse_record(record, motion_record))
    _write_json(arguments.output, {"records": records})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
