"""Replay court fitting from frozen lines, people and measured motion."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import gzip
import json
from pathlib import Path
import time

import numpy as np

from experiments.annotator.independent_court import detector, evaluate, player_guided
import zone_activity
import zone_net


def read(path: Path) -> dict:
    return json.loads(gzip.decompress(path.read_bytes()))


def run(job: dict) -> dict:
    case = job['case']
    variant = job['variant']
    pair_variant = variant.startswith('pair_')
    selected = case['selected_pair_feet'] if pair_variant else case['all_feet_px']
    result = {'id': case['id'], 'variant': variant, 'accepted': False,
              'reason': 'no_persistent_pair', 'candidates': []}
    if selected is None:
        return result
    width, height = case['dimensions']['width'], case['dimensions']['height']
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    feet = np.asarray(selected, dtype=float)
    settings = detector.Settings(wide_families=True, min_supported_lines=3,
                                 max_rectangles=job['max_rectangles'])
    segments = np.asarray(case['segments_px'], dtype=float)
    started = time.perf_counter()
    if variant == 'activity':
        guided = zone_activity.detect(frame, feet, np.asarray(case['motion_weights']), settings,
                                      segments_px=segments)
    else:
        implementation = player_guided if variant == 'pair_floor' else zone_net
        guided = implementation.detect(frame, feet, settings, segments_px=segments)
    detection = guided.detection
    candidates = []
    for candidate in detection.candidates:
        candidates.append({'corners_px': candidate.corners_px.tolist(), 'score': candidate.score,
                           'metrics': evaluate._metrics(candidate.corners_px, case['reference'], width, height)})
    result.update({'accepted': detection.accepted, 'reason': detection.reason,
                   'gap': detection.score_gap, 'candidates': candidates,
                   'hypotheses_generated': guided.hypotheses_generated,
                   'hypotheses_with_players': guided.hypotheses_with_players,
                   'seconds': time.perf_counter() - started})
    print(case['id'], variant, result['reason'],
          candidates[0]['metrics']['corner_max_error_px'] if candidates else None, flush=True)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--variants', nargs='+', choices=['pair_floor', 'pair_net', 'all_net', 'activity'],
                        default=['pair_floor', 'pair_net', 'all_net', 'activity'])
    parser.add_argument('--ids', nargs='+')
    parser.add_argument('--max-rectangles', type=int, default=4096)
    parser.add_argument('--workers', type=int, default=8)
    args = parser.parse_args()
    jobs = []
    for case in read(args.cases)['cases']:
        if args.ids and case['id'] not in args.ids:
            continue
        for variant in args.variants:
            jobs.append({'case': case, 'variant': variant, 'max_rectangles': args.max_rectangles})
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        rows = list(pool.map(run, jobs))
    result = {'max_rectangles': args.max_rectangles, 'records': rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(gzip.compress(json.dumps(result, allow_nan=False).encode(), mtime=0))


if __name__ == '__main__':
    main()
