"""Measure residual image motion inside exported person boxes.

This is a diagnostic measurement. It estimates the dominant frame-to-frame
affine motion, subtracts it from dense current-to-previous optical flow and
reports residual magnitudes in working-image pixels. It does not select people.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
import os
import re
from collections.abc import Iterator, Sequence
from pathlib import Path
from typing import Any

import cv2
import numpy as np

MAX_WORKING_WIDTH = 640
GRID_STEP = 16
GRID_BORDER = 8
RNG_SEED = 20260908
FLOW_DIRECTION = "current_to_previous"
FLOW_SETTINGS = {
    "pyramid_scale": 0.5,
    "levels": 3,
    "window_size": 15,
    "iterations": 3,
    "poly_n": 5,
    "poly_sigma": 1.2,
    "affine_method": "RANSAC",
    "ransac_reprojection_threshold": 0.75,
    "affine_max_iterations": 1000,
    "affine_confidence": 0.99,
    "affine_refine_iterations": 10,
    "grid_step": GRID_STEP,
    "grid_border": GRID_BORDER,
    "rng_seed": RNG_SEED,
}


def _read_json(path: Path) -> Any:
    with gzip.open(path, "rt", encoding="utf-8") as source:
        return json.load(source)


def _write_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + ".tmp")
    with gzip.open(temporary, "wt", encoding="utf-8") as target:
        json.dump(value, target, allow_nan=False)
    os.replace(temporary, path)


def _safe_id(value: Any) -> str:
    if not isinstance(value, str) or re.fullmatch(r"[A-Za-z0-9_-]+", value) is None:
        raise ValueError("window ids must contain only letters, numbers, '_' or '-'")
    return value


def _working_grey(frame: np.ndarray) -> np.ndarray:
    height, width = frame.shape[:2]
    scale = min(1.0, MAX_WORKING_WIDTH / width)
    working_width = max(1, round(width * scale))
    working_height = max(1, round(height * scale))
    grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    if (working_width, working_height) != (width, height):
        grey = cv2.resize(grey, (working_width, working_height), interpolation=cv2.INTER_AREA)
    return grey


def _iter_sample_greys(video_path: Path, sample_indices: Sequence[int]) -> Iterator[tuple[int, np.ndarray, tuple[int, int]]]:
    if not sample_indices or list(sample_indices) != sorted(set(sample_indices)):
        raise ValueError("sample frame indices must be non-empty, sorted and unique")
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise OSError(f"could not open video: {video_path.name}")
    try:
        frame_count = float(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if not math.isfinite(frame_count) or frame_count <= 0:
            raise ValueError(f"{video_path.name}: video has an unknown frame count")
        if sample_indices[-1] >= int(frame_count):
            raise ValueError(f"{video_path.name}: sample index exceeds video frame count")
        targets = set(sample_indices)
        for frame_index in range(sample_indices[-1] + 1):
            if frame_index in targets:
                ok, frame = cap.read()
            else:
                ok = cap.grab()
                frame = None
            if not ok:
                raise OSError(f"{video_path.name}: could not decode frame {frame_index}")
            if frame_index in targets:
                if frame is None or frame.ndim != 3 or frame.shape[2] != 3:
                    raise ValueError(f"{video_path.name}: invalid decoded frame {frame_index}")
                grey = _working_grey(frame)
                yield frame_index, grey, (frame.shape[1], frame.shape[0])
    finally:
        cap.release()


def _residual_flow(prev_grey: np.ndarray, current_grey: np.ndarray) -> tuple[np.ndarray, list[list[float]], float]:
    if prev_grey.ndim != 2 or current_grey.ndim != 2 or prev_grey.shape != current_grey.shape:
        raise ValueError("previous and current greys must be matching 2-D images")
    current_to_previous = cv2.calcOpticalFlowFarneback(
        current_grey,
        prev_grey,
        None,
        0.5,
        3,
        15,
        3,
        5,
        1.2,
        0,
    )
    height, width = current_grey.shape
    grid_y, grid_x = np.mgrid[GRID_BORDER : height - GRID_BORDER : GRID_STEP, GRID_BORDER : width - GRID_BORDER : GRID_STEP]
    if grid_x.size < 3:
        raise ValueError("working frame is too small for an affine motion grid")
    source = np.column_stack((grid_x.ravel(), grid_y.ravel())).astype(np.float32)
    sampled_flow = current_to_previous[grid_y, grid_x].reshape(-1, 2)
    destination = source + sampled_flow
    cv2.setRNGSeed(RNG_SEED)
    affine, inliers = cv2.estimateAffine2D(
        source,
        destination,
        method=cv2.RANSAC,
        ransacReprojThreshold=0.75,
        maxIters=1000,
        confidence=0.99,
        refineIters=10,
    )
    if affine is None or inliers is None or not np.isfinite(affine).all():
        raise ValueError("background affine motion could not be estimated")
    inlier_fraction = float(np.asarray(inliers, dtype=bool).mean())
    all_y, all_x = np.indices((height, width), dtype=np.float32)
    predicted = np.empty_like(current_to_previous)
    predicted[..., 0] = affine[0, 0] * all_x + affine[0, 1] * all_y + affine[0, 2] - all_x
    predicted[..., 1] = affine[1, 0] * all_x + affine[1, 1] * all_y + affine[1, 2] - all_y
    return current_to_previous - predicted, affine.tolist(), inlier_fraction


def _box_height(bbox: Sequence[float], native_size: tuple[int, int], scale: tuple[float, float]) -> float | None:
    values = np.asarray(bbox, dtype=np.float64)
    if values.shape != (4,) or not np.isfinite(values).all():
        return None
    _, native_height = native_size
    y1, y2 = values[1], values[3]
    height = max(0.0, min(native_height, y2) - max(0.0, y1)) * scale[1]
    return float(height)


def _score_detections(
    residual_flow: np.ndarray,
    bboxes_native: Sequence[Sequence[float]],
    native_size: tuple[int, int],
) -> list[dict[str, Any]]:
    working_height, working_width = residual_flow.shape[:2]
    native_width, native_height = native_size
    scale = (working_width / native_width, working_height / native_height)
    rows: list[dict[str, Any]] = []
    for bbox in bboxes_native:
        values = np.asarray(bbox, dtype=np.float64)
        box_height = _box_height(values, native_size, scale)
        row: dict[str, Any] = {"flow_quantiles": None, "box_height": box_height}
        if values.shape != (4,) or not np.isfinite(values).all():
            rows.append(row)
            continue
        x1, y1, x2, y2 = values * np.array([scale[0], scale[1], scale[0], scale[1]])
        crop_x1 = max(0.0, x1 + 0.2 * (x2 - x1))
        crop_x2 = min(working_width, x1 + 0.8 * (x2 - x1))
        crop_y1 = max(0.0, y1 + 0.2 * (y2 - y1))
        crop_y2 = min(working_height, y1 + 0.9 * (y2 - y1))
        left, top = math.floor(crop_x1), math.floor(crop_y1)
        right, bottom = math.ceil(crop_x2), math.ceil(crop_y2)
        if right - left < 2 or bottom - top < 2:
            rows.append(row)
            continue
        magnitudes = np.linalg.norm(residual_flow[top:bottom, left:right], axis=2)
        p50, p75, p90 = np.percentile(magnitudes, [50, 75, 90])
        row["flow_quantiles"] = {"p50": float(p50), "p75": float(p75), "p90": float(p90)}
        rows.append(row)
    return rows


def motion_scores(
    prevgrey: np.ndarray,
    currentgrey: np.ndarray,
    currentbboxes_native: Sequence[Sequence[float]],
    native_size: tuple[int, int],
) -> list[dict[str, Any]]:
    """Measure residual motion for current-frame boxes after affine subtraction."""
    residual, _, _ = _residual_flow(prevgrey, currentgrey)
    return _score_detections(residual, currentbboxes_native, native_size)


def _sample_output(
    sample: dict[str, Any], scores: list[dict[str, Any]], affine: list[list[float]] | None, inlier_fraction: float | None
) -> dict[str, Any]:
    bboxes = sample.get("bboxes")
    detections = []
    if not isinstance(bboxes, list) or not isinstance(sample.get("scores"), list) or len(bboxes) != len(sample["scores"]):
        raise ValueError(f"{sample.get('frame_index')}: malformed detection arrays")
    for bbox, score, motion in zip(bboxes, sample["scores"], scores):
        detections.append({"bbox": bbox, "score": score, **motion})
    return {
        "frame_index": sample["frame_index"],
        "timestamp_seconds": sample.get("timestamp_seconds"),
        "affine": affine,
        "inlier_fraction": inlier_fraction,
        "detections": detections,
    }


def _process_window(record: dict[str, Any], video_root: Path, output: Path) -> dict[str, Any]:
    window_id = _safe_id(record.get("id"))
    video_value = record.get("video")
    if not isinstance(video_value, str) or not video_value or Path(video_value).is_absolute():
        raise ValueError(f"{window_id}: video must be a relative basename")
    video_path = video_root / Path(video_value).name
    if not video_path.is_file():
        raise FileNotFoundError(f"video does not exist: {video_path.name}")
    samples = record.get("samples")
    if not isinstance(samples, list) or not samples:
        raise ValueError(f"{window_id}: person record has no samples")
    sample_by_index = {sample.get("frame_index"): sample for sample in samples}
    if len(sample_by_index) != len(samples) or any(not isinstance(index, int) or index < 0 for index in sample_by_index):
        raise ValueError(f"{window_id}: sample frame indices must be unique non-negative integers")
    sample_indices = sorted(sample_by_index)
    dimensions = record.get("dimensions")
    native_size = (int(dimensions["width"]), int(dimensions["height"]))
    output_samples: list[dict[str, Any]] = []
    previous_grey: np.ndarray | None = None
    image_scale: float | None = None
    working_scale: tuple[float, float] | None = None
    working_dimensions: tuple[int, int] | None = None
    for frame_index, current_grey, decoded_native_size in _iter_sample_greys(video_path, sample_indices):
        if decoded_native_size != native_size:
            raise ValueError(f"{window_id}: decoded dimensions differ from person record")
        if image_scale is None:
            image_scale = current_grey.shape[1] / native_size[0]
            working_scale = (
                current_grey.shape[1] / native_size[0],
                current_grey.shape[0] / native_size[1],
            )
            working_dimensions = (current_grey.shape[1], current_grey.shape[0])
        sample = sample_by_index[frame_index]
        bboxes = sample.get("bboxes", [])
        if previous_grey is None:
            rows = [
                {"flow_quantiles": None, "box_height": _box_height(bbox, native_size, working_scale)}
                for bbox in bboxes
            ]
            output_samples.append(_sample_output(sample, rows, None, None))
        else:
            residual, affine, inlier_fraction = _residual_flow(previous_grey, current_grey)
            rows = _score_detections(residual, bboxes, native_size)
            output_samples.append(_sample_output(sample, rows, affine, inlier_fraction))
        previous_grey = current_grey
    if image_scale is None or working_scale is None or working_dimensions is None or len(output_samples) != len(samples):
        raise RuntimeError(f"{window_id}: sample decoding was incomplete")
    result = {
        "id": window_id,
        "video": video_path.name,
        "source_fps": record.get("source_fps"),
        "sample_fps": record.get("sample_fps"),
        "start_frame": record.get("start_frame"),
        "end_frame": record.get("end_frame"),
        "image_scale": image_scale,
        "working_dimensions": {"width": working_dimensions[0], "height": working_dimensions[1]},
        "sample_frame_indices": sample_indices,
        "flow_direction": FLOW_DIRECTION,
        "flow_settings": FLOW_SETTINGS,
        "samples": output_samples,
    }
    _write_json(output / f"{window_id}.json.gz", result)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--people", type=Path, required=True)
    parser.add_argument("--video-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args(argv)
    manifest = _read_json(arguments.people / "manifest.json.gz")
    if not isinstance(manifest, dict) or not isinstance(manifest.get("windows"), list):
        raise TypeError("people manifest must contain a windows list")
    arguments.output.mkdir(parents=True, exist_ok=True)
    for entry in manifest["windows"]:
        if not isinstance(entry, dict) or not isinstance(entry.get("record"), str):
            raise TypeError("people manifest contains an invalid record entry")
        record_name = Path(entry["record"])
        if record_name.is_absolute() or ".." in record_name.parts:
            raise ValueError("people record path must be relative")
        record_path = arguments.people / record_name
        _process_window(_read_json(record_path), arguments.video_root, arguments.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
