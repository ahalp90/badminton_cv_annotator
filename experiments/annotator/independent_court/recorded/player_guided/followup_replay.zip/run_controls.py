"""Run the frozen net-aware zone detector on packed control inputs."""

from __future__ import annotations

import argparse
import gzip
import json
import sys
from itertools import repeat
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any

import cv2
import numpy as np

HERE = Path(__file__).resolve().parent
REPO_ROOT = next(parent for parent in (HERE, *HERE.parents) if (parent / "experiments").is_dir())
for import_path in (REPO_ROOT, HERE):
    if str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from experiments.annotator.independent_court import detector

import zone_net


def read_json_gz(path: Path) -> dict[str, Any]:
    """Read one UTF-8 JSON gzip file."""
    with gzip.open(path, "rt", encoding="utf-8") as source:
        value = json.load(source)
    if not isinstance(value, dict):
        raise TypeError(f"{path} must contain a JSON object")
    return value


def write_json_gz(path: Path, value: dict[str, Any]) -> None:
    """Write one deterministic UTF-8 JSON gzip file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(gzip.compress(json.dumps(value, allow_nan=False).encode(), mtime=0))


def _feet_from_samples(
    samples: list[dict[str, Any]], dimensions: tuple[int, int],
) -> tuple[np.ndarray, int]:
    """Build in-frame bottom-centre feet with one slot per packed box column."""
    width, height = dimensions
    slot_count = max((len(sample["bboxes"]) for sample in samples), default=0)
    feet = np.full((len(samples), slot_count, 2), np.nan, dtype=np.float64)
    for sample_index, sample in enumerate(samples):
        boxes = np.asarray(sample["bboxes"], dtype=np.float64).reshape(-1, 4)
        if len(boxes) != int(sample["ndet"]):
            raise ValueError(f"sample {sample['frame_index']} has inconsistent ndet")
        if not np.isfinite(boxes).all():
            raise ValueError(f"sample {sample['frame_index']} contains non-finite boxes")
        if not len(boxes):
            continue
        feet[sample_index, :len(boxes), 0] = (boxes[:, 0] + boxes[:, 2]) / 2
        feet[sample_index, :len(boxes), 1] = boxes[:, 3]
    if slot_count:
        in_frame = (
            (feet[..., 0] >= 0)
            & (feet[..., 0] < width)
            & (feet[..., 1] >= 0)
            & (feet[..., 1] < height)
        )
        feet[~in_frame] = np.nan
    return feet, slot_count


def _candidate_rows(candidates: tuple[detector.Candidate, ...]) -> list[dict[str, Any]]:
    """Serialise candidate geometry and score without reference metrics."""
    return [
        {"corners_px": candidate.corners_px.tolist(), "score": candidate.score}
        for candidate in candidates
    ]


def run_case(case: dict[str, Any], max_rectangles: int = 4096) -> dict[str, Any]:
    """Run one packed control case through the unchanged net-aware detector."""
    dimensions = (int(case["dimensions"]["width"]), int(case["dimensions"]["height"]))
    samples = case["samples"]
    feet, slot_count = _feet_from_samples(samples, dimensions)
    result: dict[str, Any] = {
        "id": case["id"],
        "accepted": False,
        "reason": None,
        "gap": None,
        "candidates": [],
        "hypotheses_generated": 0,
        "hypotheses_with_players": 0,
        "hypotheses_scored": 0,
        "people_slots": slot_count,
        "sample_count": len(samples),
    }
    if slot_count < 2:
        result["reason"] = "insufficient_people"
        return result
    counts = np.isfinite(feet).all(axis=-1).sum(axis=-1)
    if not (counts >= 1).all() or (counts >= 2).mean() < 0.5:
        result["reason"] = "insufficient_persistent_people"
        return result

    frame = np.zeros((dimensions[1], dimensions[0], 3), dtype=np.uint8)
    segments = np.asarray(case["segments_px"], dtype=np.float64).reshape(-1, 4)
    settings = detector.Settings(wide_families=True, min_supported_lines=3, max_rectangles=max_rectangles)
    guided = zone_net.detect(
        frame,
        feet,
        settings,
        segments_px=segments,
        player_margin=0.15,
    )
    detection = guided.detection
    result.update(
        {
            "accepted": detection.accepted,
            "reason": detection.reason,
            "gap": detection.score_gap,
            "candidates": _candidate_rows(detection.candidates),
            "hypotheses_generated": guided.hypotheses_generated,
            "hypotheses_with_players": guided.hypotheses_with_players,
            "hypotheses_scored": detection.hypotheses_scored,
        }
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pack", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--max-rectangles", type=int, default=4096)
    args = parser.parse_args()
    if args.workers < 1:
        raise ValueError("--workers must be positive")
    pack = read_json_gz(args.pack)
    cases = pack.get("cases")
    if not isinstance(cases, list):
        raise TypeError("control pack must contain a cases list")
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(run_case, cases, repeat(args.max_rectangles)))
    write_json_gz(args.output, {"schema": "independent-court-control-results/1",
                              "max_rectangles": args.max_rectangles, "records": results})


if __name__ == "__main__":
    main()
