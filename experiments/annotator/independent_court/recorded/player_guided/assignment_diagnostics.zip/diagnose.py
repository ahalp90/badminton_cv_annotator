"""Post-run, label-only inspection of selected and best available frozen geometries."""
import gzip
import json
from pathlib import Path

import cv2
import numpy as np

from experiments.annotator.independent_court import assignment
from experiments.annotator.independent_court.detector import (
    CORNER_COURT_M,
    SEGMENTS_M,
    _visible_samples,
    project,
)

HERE = Path(__file__).resolve().parent
results = json.loads(gzip.decompress((HERE / 'results_v1.json.gz').read_bytes()))
records = []
for record in results['records']:
    if record['id'] not in ('yellow_short_frame_156', 'letterboxed_short_frame_58', 'centre_short_frame_64'):
        continue
    entries = {entry['id']: entry for entry in record['entries']}
    best = min((entry for entry in entries.values() if entry['eligible']),
               key=lambda entry: entry['metrics']['corner_max_error_px'])
    selected = entries[record['orders']['assignment'][0]]
    raw = np.array([segment for group in record['groups'] for segment in group['segments_working_px']])
    size = tuple(record['working_size'])
    observations = assignment.prepare_observations(raw, size)
    width, height = record['dimensions']['width'], record['dimensions']['height']
    scale = np.array([width / size[0], height / size[1]])
    cases = []
    for role, entry in (('selected', selected), ('best_by_corner_label', best)):
        homography = cv2.getPerspectiveTransform(CORNER_COURT_M,
                                                (np.asarray(entry['corners_px']) / scale).astype(np.float32))
        projected = project(homography[None], SEGMENTS_M)[0].reshape(12, 2, 2)
        samples, visible = _visible_samples(projected[None], size, assignment.MARKING_SAMPLES)
        vectors = projected[:, 1] - projected[:, 0]
        directions = vectors / np.linalg.norm(vectors, axis=1)[:, None]
        compatible = np.abs(directions @ observations.directions.T) >= np.cos(np.deg2rad(assignment.MATCH_ANGLE_DEG))
        support = assignment.measure_support(homography, observations, size)
        marking_rows = []
        for marking, intervals in enumerate(assignment.MARKING_INTERVALS):
            active = [index for index in intervals if visible[0, index]]
            if not active:
                continue
            nearest = []
            for interval in active:
                distances = assignment.distances_to_segments(samples[0, interval], observations.segments)
                nearest.append(np.where(compatible[interval], distances, np.inf).min(axis=1))
            all_fragments = np.exp(-0.5 * np.square(np.concatenate(nearest) / assignment.DISTANCE_SIGMA_PX)).mean()
            marking_rows.append({'marking': assignment.MARKINGS[marking], 'all_fragments_forward': float(all_fragments),
                                 'best_group_forward': float(support.forward[marking].max())})
        cases.append({'role': role, 'entry': entry['id'], 'metrics': entry['metrics'],
                      'markings': marking_rows,
                      'all_fragments_forward': float(np.mean([row['all_fragments_forward'] for row in marking_rows])),
                      'best_group_forward': entry['independent']['forward'],
                      'assigned_forward': entry['assignment']['forward'],
                      'assigned_reverse': entry['assignment']['reverse']})
    records.append({'id': record['id'], 'observation_union_length_px': sum(g['union_length_px'] for g in record['groups']),
                    'comparisons': cases})
output = {'post_hoc': True, 'labels_used_only_to_identify_best_geometry': True, 'records': records}
(HERE / 'diagnostics.json.gz').write_bytes(gzip.compress(json.dumps(output, allow_nan=False).encode(), mtime=0))
for record in records:
    print(record['id'], 'observed length', record['observation_union_length_px'])
    for case in record['comparisons']:
        print(case['role'], case['entry'], 'all', round(case['all_fragments_forward'], 4),
              'best group', round(case['best_group_forward'], 4), 'assigned', round(case['assigned_forward'], 4))
