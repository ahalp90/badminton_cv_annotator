"""Diagnostic rectangle selection with the original court geometry preserved."""

from __future__ import annotations

from itertools import combinations

import cv2
import numpy as np

from experiments.annotator.independent_court import detector


def select_rectangles(
    x_lines: np.ndarray,
    y_lines: np.ndarray,
    size: tuple[int, int],
    settings: detector.Settings,
    mode: str,
) -> tuple[np.ndarray, dict]:
    """Enumerate and select diagnostic court rectangles.

    Geometry and the post-selection area gate intentionally mirror
    :func:`detector._image_rectangles`.  Pair-product IDs use that function's
    sorted-line, x-pair-major enumeration before convexity filtering.
    """
    if mode not in ("random", "stratified"):
        raise ValueError(f"unknown rectangle selection mode: {mode}")

    width, height = size
    x_order = np.argsort(-(x_lines[:, 1] * height / 2 + x_lines[:, 2]) / x_lines[:, 0])
    y_order = np.argsort(-(y_lines[:, 0] * width / 2 + y_lines[:, 2]) / y_lines[:, 1])
    x_lines, y_lines = x_lines[x_order], y_lines[y_order]
    intersections = np.cross(x_lines[:, None], y_lines[None, :])
    with np.errstate(divide="ignore", invalid="ignore"):
        points = intersections[..., :2] / intersections[..., 2:]
    x_pairs = np.asarray(list(combinations(range(len(x_lines)), 2)))
    y_pairs = np.asarray(list(combinations(range(len(y_lines)), 2)))
    x_slots = x_pairs[:, [0, 1, 1, 0]][:, None, :]
    y_slots = y_pairs[:, [0, 0, 1, 1]][None, :, :]
    quads = points[x_slots, y_slots].reshape(-1, 4, 2)
    edges = np.roll(quads, -1, axis=1) - quads
    turns = edges[..., 0] * np.roll(edges[..., 1], -1, axis=1) - edges[..., 1] * np.roll(edges[..., 0], -1, axis=1)
    valid = np.isfinite(quads).all(axis=(1, 2)) & np.all(turns > 0, axis=1)
    pair_product_ids = np.arange(len(quads), dtype=np.int64)
    quads = quads[valid]
    pair_product_ids = pair_product_ids[valid]

    available_convex_quads = len(quads)
    capped = available_convex_quads > settings.max_rectangles
    occupied_bins: int | None = None
    if not capped:
        selected_indices = np.arange(available_convex_quads)
    elif mode == "random":
        generator = np.random.default_rng(settings.seed)
        selected_indices = generator.choice(available_convex_quads, settings.max_rectangles, replace=False)
    else:
        bin_count = max(1, int(np.floor(settings.max_rectangles ** 0.25)))
        x_normalised = x_pairs / (len(x_lines) - 1)
        y_normalised = y_pairs / (len(y_lines) - 1)
        x_features = np.column_stack((x_normalised.mean(axis=1), np.diff(x_normalised, axis=1)[:, 0]))
        y_features = np.column_stack((y_normalised.mean(axis=1), np.diff(y_normalised, axis=1)[:, 0]))
        features = np.concatenate(
            (np.repeat(x_features, len(y_pairs), axis=0), np.tile(y_features, (len(x_pairs), 1))),
            axis=1,
        )[valid]
        bin_indices = np.clip(np.floor(features * bin_count).astype(int), 0, bin_count - 1)
        bin_keys = np.ravel_multi_index(bin_indices.T, (bin_count,) * 4)
        centres = (bin_indices + 0.5) / bin_count
        distances = np.sum((features - centres) ** 2, axis=1)
        order = np.lexsort((pair_product_ids, distances, bin_keys))
        ordered_keys = bin_keys[order]
        group_starts = np.r_[0, np.flatnonzero(np.diff(ordered_keys)) + 1]
        group_sizes = np.diff(np.r_[group_starts, len(order)])
        within_bin_rank = np.arange(len(order)) - np.repeat(group_starts, group_sizes)
        round_robin = np.lexsort((ordered_keys, within_bin_rank))
        selected_indices = order[round_robin[:settings.max_rectangles]]
        occupied_bins = len(group_starts)

    selected_quads = quads[selected_indices]
    selected_pair_product_ids = pair_product_ids[selected_indices]
    rectangles = []
    retained_pair_product_ids: list[int] = []
    for pair_product_id, quad in zip(selected_pair_product_ids, selected_quads, strict=True):
        if cv2.contourArea(quad.astype(np.float32)) >= 100:
            retained_pair_product_ids.append(int(pair_product_id))
            rectangles.append(cv2.getPerspectiveTransform(detector.UNIT_CORNERS, quad.astype(np.float32)))

    stats = {
        "available_convex_quads": available_convex_quads,
        "selected_quads": len(selected_quads),
        "area_retained_rectangles": len(rectangles),
        "occupied_bins": occupied_bins,
        "selected_pair_product_ids": selected_pair_product_ids.tolist(),
        "retained_pair_product_ids": retained_pair_product_ids,
        "mode": mode,
    }
    return np.asarray(rectangles).reshape(-1, 3, 3), stats
