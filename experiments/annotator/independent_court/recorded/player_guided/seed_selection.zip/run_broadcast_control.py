"""Compare emitted broadcast courts where only corner annotations are available."""

from __future__ import annotations

import argparse
import importlib
import sys
import time
from pathlib import Path

import cv2
import numpy as np
from select_seeds import select_rectangles

from experiments.annotator.independent_court import detector


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--trace-directory", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path[:0] = [str(args.legacy.resolve()), str(args.trace_directory.resolve())]
    zone = importlib.import_module("zone_net")
    trace = importlib.import_module("run_trace")
    packed = trace.read(args.inputs)
    case_id = "shuttleset_03_scene_0019"
    source = next(case for case in packed["cases"] if case["id"] == case_id)
    reference = np.asarray(packed["references"][case_id]["corners_px"])
    width, height = source["dimensions"]["width"], source["dimensions"]["height"]
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    feet = np.asarray([[[np.nan, np.nan] if foot is None else foot for foot in sample]
                       for sample in source["all_feet_px"]], dtype=float)
    segments = np.array(source["segments_px"], dtype=float)
    settings = detector.Settings(wide_families=True, min_supported_lines=3)
    original_rectangles = detector._image_rectangles
    cv2.setNumThreads(1)
    records = []
    for mode in ("random", "stratified"):
        selections = []

        def rectangles(
            x_lines: np.ndarray, y_lines: np.ndarray, size: tuple[int, int], settings: detector.Settings,
            *, arm_mode: str = mode, arm_selections: list = selections,
        ) -> np.ndarray:
            selected, details = select_rectangles(x_lines, y_lines, size, settings, arm_mode)
            arm_selections.append(details)
            return selected

        started = time.perf_counter()
        detector._image_rectangles = rectangles
        try:
            result = trace.final_output(zone.detect(frame, feet, settings, segments_px=segments))
        finally:
            detector._image_rectangles = original_rectangles
        elapsed = time.perf_counter() - started
        chosen_error = None
        if result["candidates"]:
            chosen = np.asarray(result["candidates"][0]["corners_px"])
            chosen_error = float(np.linalg.norm((chosen - reference) * [1280 / width, 720 / height], axis=1).max())
        records.append({"mode": mode, "final": result, "seed_selection": selections[0],
                        "selected_max_corner_1280_px": chosen_error, "detection_s": elapsed})
        print(mode, result["accepted"], len(result["candidates"]), chosen_error, elapsed, flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    trace.write(args.output, {"case_id": case_id, "population": "direct detector output control",
                              "boundary_metrics": "unavailable: reference has no boundary landmarks", "arms": records})


if __name__ == "__main__":
    main()
