"""Small exactness and identity smoke checks for diagnostic seed selection."""

from __future__ import annotations

import numpy as np
from select_seeds import select_rectangles

from experiments.annotator.independent_court import detector


def synthetic_lines() -> tuple[np.ndarray, np.ndarray, tuple[int, int]]:
    """Return unsorted axis-aligned lines with several sub-100-pixel quads."""
    x_positions = np.array([300, 760, 95, 500, 100, 640], dtype=np.float64)
    y_positions = np.array([350, 95, 500, 100, 200], dtype=np.float64)
    x_lines = np.column_stack((np.ones(len(x_positions)), np.zeros(len(x_positions)), -x_positions))
    y_lines = np.column_stack((np.zeros(len(y_positions)), np.ones(len(y_positions)), -y_positions))
    return x_lines, y_lines, (800, 600)


def check() -> None:
    """Run exact geometry, capped selection and identity checks."""
    x_lines, y_lines, size = synthetic_lines()
    capped_settings = detector.Settings(max_rectangles=16, seed=20260913)

    expected_random = detector._image_rectangles(x_lines, y_lines, size, capped_settings)
    random_rectangles, random_stats = select_rectangles(x_lines, y_lines, size, capped_settings, "random")
    np.testing.assert_array_equal(random_rectangles, expected_random)
    assert random_stats["selected_quads"] <= capped_settings.max_rectangles

    stratified_rectangles, stratified_stats = select_rectangles(
        x_lines, y_lines, size, capped_settings, "stratified",
    )
    repeated_rectangles, repeated_stats = select_rectangles(
        x_lines, y_lines, size, capped_settings, "stratified",
    )
    np.testing.assert_array_equal(stratified_rectangles, repeated_rectangles)
    assert stratified_stats == repeated_stats
    selected_ids = stratified_stats["selected_pair_product_ids"]
    retained_ids = stratified_stats["retained_pair_product_ids"]
    assert len(selected_ids) <= capped_settings.max_rectangles
    assert len(selected_ids) == len(set(selected_ids))
    assert set(retained_ids).issubset(selected_ids)
    assert stratified_stats["occupied_bins"] is not None

    uncapped_settings = detector.Settings(max_rectangles=10_000, seed=20260913)
    expected_uncapped = detector._image_rectangles(x_lines, y_lines, size, uncapped_settings)
    random_uncapped, random_uncapped_stats = select_rectangles(
        x_lines, y_lines, size, uncapped_settings, "random",
    )
    stratified_uncapped, stratified_uncapped_stats = select_rectangles(
        x_lines, y_lines, size, uncapped_settings, "stratified",
    )
    np.testing.assert_array_equal(random_uncapped, expected_uncapped)
    np.testing.assert_array_equal(stratified_uncapped, expected_uncapped)
    assert random_uncapped_stats["occupied_bins"] is None
    assert stratified_uncapped_stats["occupied_bins"] is None
    assert random_uncapped_stats["selected_pair_product_ids"] == stratified_uncapped_stats[
        "selected_pair_product_ids"
    ]

    retained_id_to_transform = dict(
        zip(
            stratified_uncapped_stats["retained_pair_product_ids"],
            stratified_uncapped,
            strict=True,
        )
    )
    for retained_id, rectangle in zip(retained_ids, stratified_rectangles, strict=True):
        np.testing.assert_array_equal(rectangle, retained_id_to_transform[retained_id])

    assert stratified_uncapped_stats["available_convex_quads"] > stratified_uncapped_stats[
        "area_retained_rectangles"
    ]
    print("seed-selection smoke passed")


if __name__ == "__main__":
    check()
