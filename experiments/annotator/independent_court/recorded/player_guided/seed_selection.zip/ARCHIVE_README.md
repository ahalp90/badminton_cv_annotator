# Fixed-budget court seed comparison

This archive contains the tested selector, runners, synthetic smoke check and
saved random/stratified outputs. Read the adjacent seed_selection.md report for
the interpretation. This is a frozen development comparison, not a deployed
detector. The selector is preserved exactly as tested, including float64
bin-centre distances and ascending bin visitation order.

The seven GX summaries and the Amateur-2 control contain proposal coverage and
actual gate counts. The broadcast control compares direct detector outputs only:
its reference supplies corners but no boundary landmarks. Its result therefore
has no boundary RMS or generated-population coverage ranking.

Input packs and legacy helpers are already published in the adjacent archives:

- extension_diagnostics.zip: gx/inputs.json.gz and broadcast/inputs.json.gz.
- marking_refit_replay.zip: marking_inputs.json.gz, zone_net.py and dependencies.
- gx_proposal_diagnostics.zip: run_trace.py and the original coverage controls.

Use the repository experiment modules at checkpoint cedf732 with the archived
scripts. The recorded numerical environment uses Python 3.11.13, NumPy 2.4.6,
OpenCV 5.0.0 and SciPy 1.17.1. Inputs contain cached line and person observations;
no model inference or video decoding is required.

From the repository root, prepare a temporary replay directory:

```bash
court_recorded=experiments/annotator/independent_court/recorded/player_guided &&
court_replay=$(mktemp -d /tmp/court-seeds.XXXXXX) &&
unzip -q "$court_recorded/seed_selection.zip" -d "$court_replay/seed" &&
unzip -q "$court_recorded/gx_proposal_diagnostics.zip" -d "$court_replay/trace" &&
unzip -q "$court_recorded/extension_diagnostics.zip" \
  gx/inputs.json.gz broadcast/inputs.json.gz -d "$court_replay/inputs" &&
unzip -q "$court_recorded/marking_refit_replay.zip" \
  '*.py' marking_inputs.json.gz -d "$court_replay/legacy"
```

Run the GX pilot; pass the other five recorded case IDs to extend it:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=src:. \
  python "$court_replay/seed/run_comparison.py" \
  --inputs "$court_replay/inputs/gx/inputs.json.gz" \
  --legacy "$court_replay/legacy" --trace-directory "$court_replay/trace" \
  --ids gxBQ_window_00_frame_0 gxBQ_window_00_frame_5 \
  --output "$court_replay/fresh-gx"
```

For the amateur control, use the same command with
`--inputs "$court_replay/legacy/marking_inputs.json.gz"`,
`--ids am2_window_00_frame_150`, `--click-inset-m 0` and a separate output directory.
For the broadcast control:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=src:. \
  python "$court_replay/seed/run_broadcast_control.py" \
  --inputs "$court_replay/inputs/broadcast/inputs.json.gz" \
  --legacy "$court_replay/legacy" --trace-directory "$court_replay/trace" \
  --output "$court_replay/fresh-broadcast.json.gz"
```

The runner's optional click-inset argument was added after the GX runs. Its
default remains their original 0.005 m calculation; those saved GX records omit
the later metadata key. The argument affects reported boundary diagnostics only.
The numerical results, selection and gates retain their original meaning.

Maximum corner errors in GX/amateur coverage summaries are native pixels.
Multiply by 2/3 for their 1920×1080 images to report at 1280×720. Boundary fields
already use 1280×720. The broadcast control's selected_max_corner_1280_px is
already scaled. Coverage minima select diagnostic examples after generation;
they do not describe an automatically emitted court.
