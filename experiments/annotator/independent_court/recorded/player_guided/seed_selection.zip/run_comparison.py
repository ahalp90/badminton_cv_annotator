"""Compare one deterministic seed sample with the original random sample.

Reuse the frozen-input detector tracer. Labels enter its summary only after
detection; matching, player checks, camera checks and retention stay unchanged.
"""

from __future__ import annotations

import argparse
import importlib
import sys
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from select_seeds import select_rectangles

from experiments.annotator.independent_court import detector


def run_arm(source: dict, reference: dict, mode: str, zone: Any, trace: Any, click_inset_m: float) -> dict:
    settings = detector.Settings(wide_families=True, min_supported_lines=3)
    original_rectangles = detector._image_rectangles
    original_detect = zone.detect
    selections = []
    calls = []
    timings = []

    def rectangles(x_lines: np.ndarray, y_lines: np.ndarray, size: tuple[int, int], settings: Any) -> np.ndarray:
        started = time.perf_counter()
        result, details = select_rectangles(x_lines, y_lines, size, settings, mode)
        details["selection_s"] = time.perf_counter() - started
        selections.append(details)
        calls.append((x_lines, y_lines, size, settings, result))
        return result

    def timed_detect(*args: Any, **kwargs: Any) -> Any:
        started = time.perf_counter()
        result = original_detect(*args, **kwargs)
        timings.append(time.perf_counter() - started)
        return result

    detector._image_rectangles = rectangles
    zone.detect = timed_detect
    try:
        record, rows = trace.capture(source, zone, settings)
    finally:
        detector._image_rectangles = original_rectangles
        zone.detect = original_detect
    if mode == "random":
        x_lines, y_lines, size, settings, measured = calls[0]
        np.testing.assert_array_equal(measured, original_rectangles(x_lines, y_lines, size, settings))
    started = time.perf_counter()
    record = trace.summarise(record, rows, source, reference, zone, click_inset_m)
    record["click_inset_m"] = click_inset_m
    record["timing"] = {"detection_s": timings[0], "traced_detection_s": timings[1],
                        "summary_s": time.perf_counter() - started}
    record["seed_selection"] = selections[0]
    record["mode"] = mode
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--trace-directory", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--click-inset-m", type=float, default=0.005)
    args = parser.parse_args()
    sys.path[:0] = [str(args.legacy.resolve()), str(args.trace_directory.resolve())]
    zone = importlib.import_module("zone_net")
    trace = importlib.import_module("run_trace")
    cv2.setNumThreads(1)
    packed = trace.read(args.inputs)
    selected = [case for case in packed["cases"] if case["id"] in args.ids]
    if {case["id"] for case in selected} != set(args.ids):
        raise ValueError("Requested case IDs must exist in the frozen pack")
    args.output.mkdir(parents=True, exist_ok=True)
    for source in selected:
        records = []
        for mode in ("random", "stratified"):
            record = run_arm(source, packed["references"][source["id"]], mode, zone, trace, args.click_inset_m)
            records.append(record)
            best = record["diagnostic_rankings"]["geometry_before_players"]["max_corner_native_px"][0]["value"]
            print(source["id"], mode, "best native corner error", best,
                  "counts", record["counts"], "detection seconds", record["timing"]["detection_s"], flush=True)
        trace.write(args.output / f"{source['id']}.json.gz", {
            "schema": "fixed-budget-seed-comparison/1", "case_id": source["id"],
            "labels_used_only_after_detection": True, "court_matching": "unchanged original scorer",
            "arms": records,
        })


if __name__ == "__main__":
    main()
