# Court identity is not established by the present ranking evidence

## Evidence and revision actually accessed

Repository: **`ahalp90/badminton_cv_annotator`**. Every repository read was pinned to **`7299ff3`**, resolved to **`7299ff3f74bf51dc3bc59582c79190dbc81666ca`**. The named branch is `fix/court-det`; I did not substitute its current head. The supplement identifies `b90518c` as its scientific basis. Paths below are relative to:

`experiments/annotator/independent_court/recorded/player_guided/projective_patterns/`

| Evidence | Actual access |
|---|---|
| `evaluation/README.md`, `automatic_axes_results.md`, `automatic_axes_visual_judgements.md` | Read completely, first and in the requested order. |
| `evaluation/method_excerpts.md` | Read the court/mapping and relevant paint, visibility and winner-selection excerpts; the initial whole-file response was truncated, then the relevant later sections were retrieved. |
| `measurements.json.gz`, `gx0_control_measurements.json.gz` | Fully recovered and decompressed; both compressed files verified against their Git blob hashes. All nine automatic-case summaries and both extreme false profiles were accessible. |
| `evaluation/ranking_records.json.gz` | **Partial retrieval:** four complete detailed entries recovered: Amateur-2 frame150 `30:30`, `30:33`, and frame28019 `16:1800`, `184:4123`, all `automatic_all_camera`. Their scores, gates and corners match the complete measurement summary. I did not decode the remainder of this archive. |
| `automatic_axes_visual_check.html`, `gx0_control_visual_check.html` | Automatic gallery source partially read; GX0 control HTML/SVG source completely read. **No rendered gallery or background image was successfully opened.** Visual conclusions below use the existing written judgements, not my own image inspection. |
| `methods.md`; commit metadata | Read as supplementary scope/provenance evidence. |

The handover manifest records these limitations and hashes. Detailed records absent from this review are not thereby absent from the repository. [S1–S11]

**Assessment: the observations expose missing discriminating information; they do not establish a court-identity or acceptance rule.** They decisively refute the sufficiency of perfect paint profiles, complete profile availability, or the original floor outcome considered alone. They also expose useful disagreement between paint and line evidence. That is a reason to investigate the disagreement, not evidence that an untested combination resolves it. This is not a proof that the original images—or every combination of recorded features—cannot distinguish the candidates. The existing human judgements already distinguish several of them. [S1–S7]

## Finding 1 — A passed profile identifies a local appearance condition, not court paint

**Recorded facts.** These three identities all belong to population `automatic_all_camera`; the case is part of each identity. Line values below are `stripe.exclusive.score` in the detailed records and `stripe_score` in the compact summary. [S3, S5, S6]

| Exact case / candidate | Saved paint evidence | Line score | Existing judgement |
|---|---|---:|---|
| `am2_window_01_frame_28019` / `184:4123` | `profile.score = 1.0`; all 12 intervals available and passing; all 11 `marking_ridge` values equal 1 | 0.1352180041 | Grossly wrong court near the net top. |
| `shuttleset_03_scene_0019` / `165:6702` | `profile.score = 1.0`; five available markings pass; six markings unavailable | 0.2238074951 | Unrelated, hallucinated court. |
| `am2_window_00_frame_150` / `30:33` | `profile.score = 1.0`; all 12 intervals available and passing; all 11 marking values equal 1 | 0.3263949156 | Approved as perfect, with uncertainty at the extreme far end. |

**Deduction.** The first and third candidates have identical complete saved `profile` objects but opposite visual rulings. A decision using only that object—including its availability counts—cannot distinguish them. Their other features and images are not identical. Thus a visible-count penalty alone cannot explain or resolve `184:4123`.

For scene19 `165:6702`, the five supported markings are **left/right singles and doubles sidelines, and far short service**. The centre, both baselines, far long service, near short service and near long service are unavailable. This is five available intervals out of twelve: the unavailable centre accounts for two intervals. It is not six observed paint failures. [S4, S6]

### Three states, at two different levels

| State | What the current records establish | What they do not establish |
|---|---|---|
| **Unavailable observation** | `interval_visible=False`; a marking is `None` if none of its intervals is eligible. | Whether physical paint is absent, occluded, cropped away, or distinguishable. `interval_ridge=False` on an unavailable interval is an initialized placeholder, not a failed observation. |
| **Observed support** | On an eligible interval, the bright-ridge test passed. A marking value of 1 means its available intervals passed. | That the pixels belong to this court, that the whole interval follows one continuous marking, or that another interval contributes independent evidence. |
| **Observed contradiction to the appearance test** | On an eligible interval, `interval_ridge=False` records a failed test. A centre value of 0.5 can combine one passing and one failing available interval. | That the candidate court is physically wrong. Occlusion, weak contrast, crowded paint, resolution or insufficient valid side samples can also produce failure. |

These are measurement states. **Semantic contradiction**—expected paint is observably missing or replaced by incompatible structure—additionally requires knowing that the relevant region is observable and that the expected marking should be distinguishable there. The present arrays do not supply that knowledge. Conversely, the written rejection of `184:4123` is semantic evidence against that candidate even though every profile passes. [S3, S4]

`detector._visible_samples` requires a positive clipped span of **at least 12 working pixels**. An intersecting but shorter interval is unavailable too. Homography, image dimensions and the model intervals can distinguish geometric clipping reasons; they cannot establish occlusion or contrast. `inspect_appearance.profiles` averages available intervals within a marking, then averages non-`None` markings. Observing just one centre-line half can therefore supply a full centre-marking value. [S4]

**Deduction about hiding inconvenient markings.** Let `A(H)` be the markings eligible under candidate homography `H`. The recorded score is

`P(H) = mean(r_m(H) for m in A(H))`.

Candidate geometry chooses both the locations tested and which markings enter the denominator. Holding the remaining outcomes fixed, removing outcomes below the current mean increases that mean. Across candidates, projecting poorly aligned markings outside the image—or leaving less than 12 working pixels—can therefore remove negative contributions rather than incur contradiction. This is a selection incentive, not a claim about an optimizer's intention. Changing a real homography can also change the other profiles, camera eligibility and line score; improvement is not guaranteed. [S4]

Scene19 demonstrates the **perfect conditional score with limited observations**, but does not show what its six unobserved markings would have scored outside the image. Treating them as six known failures invents evidence. Treating them as six successes also invents evidence. A valid severely cropped court could have the same availability pattern; no approved five-marking analogue has been established by the detailed records accessed here.

**Untested explanation for the all-eleven case.** `_filter_painted_stripes` samples 24 positions, searches five normal offsets at each position and accepts an interval when at least 40% satisfy its centre-versus-both-sides contrast condition. Those are existing measurement settings, not proposed acceptance thresholds. All profiles passing does not certify continuous paint at every position or a coherent offset along the line. Fragmented or repeated background ridges could satisfy the predicate. The records do not verify which physical structures supplied `184:4123`'s passing samples. Shared image content, shared geometry and possible shared supports also prevent treating eleven passes as eleven independent confirmations. [S4, S5]

## Finding 2 — Existing corroboration is informative, but its simplest vetoes have contrary examples

**Recorded facts.** Both false paint winners have `gates.floor_score = -1.0`. So do the approved **GX0 supplied-direction comparator `89`** and **GX0 label-guided observed-bank winners `1864` and `5144`**, which the control record judges essentially ideal. These are three different control identities, not automatic GX0 winners or interchangeable candidate IDs. The control file records their common case as `gxBQ_window_00_frame_0`. The floor outcomes therefore do not separate the two false winners from these approved controls. Nothing here establishes what internal floor condition produced `-1.0`. [S1, S6, S7]

The false winners also have `geometry_valid=True`, `player_fractions=[1.0,1.0]`, and camera errors **0.0244304924** and **0.0694164338**, respectively. Approved Amateur-2 frame150 `30:33` also has player fractions `[1.0,1.0]`. These existing player summaries do not resolve the ambiguity. Camera eligibility is likewise not a court-identity certificate. [S5, S6]

There is already a more specific discrepancy to examine. In `184:4123`, `stripe.exclusive_per_marking` is exactly zero for **left singles, centre and right doubles**, despite all their paint profiles passing; its saved `gates.line_counts` is `[0,2]`. Scene19 `165:6702` has `[0,0]`. But requiring line corroboration on every marking also faces a positive contrary example: approved `30:33` has far-long-service exclusive support approximately **2.25e-15**, while its paint profile passes. These are different measurement systems, not interchangeable tests of physical absence. [S5, S6]

**Deductions and bounded hypotheses.** The following are potential discriminating observations, not proposed gates. Each needs an assumption that the present candidate summaries do not certify.

| Observation and named ambiguity | What it could distinguish; physical assumption required | Plausible valid court it would wrongly penalise |
|---|---|---|
| **Finite extent, endpoints and the centre-line gap** — Amateur-2 mat-border fits versus court boundaries; partial scene19 pattern. | Correct support should occur over the appropriate finite painted spans and, where observable, terminate or meet other markings consistently. The current profiles already use finite clipped intervals; merely adding “finite extent” is not a new distinction. Stronger endpoint/gap evidence needs observable terminations and assumes unrelated markings do not continue through them. | Cropped endpoints, worn or player-covered terminations, or intersecting multi-sport paint. This is not hypothetical for a blanket in-frame rule: approved GX0 `1864` and `5144` have a native corner at `y=1161.095…` in a 1080-high image. Approved `30:33` has a corner at `x=-98.425…`. These prove valid partial extent, not validity of every low-profile-count crop. |
| **Cross-marking spatial correspondence, using existing line/profile disagreement** — `184:4123`'s eleven passes. | Could distinguish separately corroborated court markings and their junctions from a few borrowed or fragmented structures. Requires resolvable paint identities and alignment between saved observation assignments and image locations. One homography imposes model consistency; it does not independently verify that observed supports have the required identities. | Foreshortened, blurred or crowded far-end markings can merge; real junctions legitimately share pixels. Approved `30:33` already contradicts a demand for substantial exclusive support everywhere. Array labels such as `independent` do not establish statistical independence. |
| **Player-to-floor/court association beyond the saved fractions** — GX5 wall/children fits and the Amateur-2 net-top fit. | Reliable foot/contact positions associated with actual players could locate the playing surface relative to the projected court. This needs correct player identity, appropriate treatment of jump/occlusion states and an assumption about where players may stand. The existing fractions have already failed to distinguish the named false winners. | A valid court with players lunging outside its boundary, jumping, partly occluded or confused with nearby people. A hard requirement that all detected people lie inside is not justified. |
| **Scene support distinguishing floor paint from wall, net or mat-edge structure** — GX5 and Amateur-2 false fits. | Could distinguish physical surface or object identity when local ridge appearance is similar. Requires trustworthy scene/plane association; a mat boundary is not assumed to be a court boundary. This is not equivalent to reinstating the observed floor gate. | A real court on low-contrast, reflective, heavily marked or partly hidden flooring. More decisively, the recorded gate already rejects the approved GX0 trio. Its missing implementation prevents attributing those outcomes to a particular failure mechanism. |

The first two observations can be partly investigated through existing geometry and stripe arrays. Verifying spatial ownership, meaningful absence, or scene identity requires image evidence and often explicit visual judgement. I did not obtain that image access, and the saved aggregate fields cannot replace it. [S1, S3–S7]

## Finding 3 — These are opposing ranking counterexamples, not an acceptance evaluation

**Recorded facts.** The required choice changes with the case and population. [S2, S3, S6]

| Population and case | Existing comparison |
|---|---|
| `automatic_all_camera`, Amateur-2 frame150 | Line `30:30` follows the mat boundary; paint `30:33` is approved. Their display corner errors are 185.106 versus 10.843. |
| `automatic_all_camera`, ShuttleSet03 scene19 | Line `1:60` is usable; paint `165:6702` is rejected. Their errors are 12.736 versus 8390.859. |
| `automatic_all_camera`, GX0 | Neither `22:4579` nor `22:4588` is usable. The user prefers the line winner despite its larger corner error, 18.806 versus 12.690. |
| Camera-first arm, Amateur-2 frame28019 | Paint `16:1796` has display error 22.900; removing the global cap introduces all-camera paint winner `184:4123` at 1189.522. This numerical repair is not visual approval of `16:1796`. |

**Deduction.** “Use line everywhere” loses approved `30:33`; “use paint everywhere” loses usable scene19 `1:60`. Replacing the all-eleven false winner by its line winner `16:1800` would still leave an unusable Amateur-2 frame28019 result. Paint ranking can help within some pools and fail in others; selecting an alternative and accepting it are separate questions.

Perfect paint agreement is not necessary for the existing usability rulings either: the essentially perfect Amateur-3 line winner `(am3_window_00_frame_0, automatic_all_camera, 43:22603)` has paint score **0.7272727…**. ShuttleSet03 scene17 line winner `1:80` is usable, whereas paint winner `1:132` is described as worse with a boundary overshoot. No overall approval was recorded for that paint panel; it should not silently become a newly labelled binary negative. Minor paint-edge and internal-line differences accepted in other named panels do not define a universal pixel cutoff. Apparent bowing has no verified cause. [S3, S6]

Four claim levels must remain separate:

| Claim level | What follows here |
|---|---|
| **Candidate availability** | GX0 controls show matcher capacity with label-guided observed directions, not automatic recovery of those directions. A ranker cannot recover candidates excluded earlier. Poor displayed nearest-control candidates do not prove every undisplayed pool member unusable. |
| **Ranking** | `run_automatic.winner_ids` compares camera-eligible candidates with an available paint score. Line maximises exclusive line support; paint maximises profile score with line support as tie-breaker. Floor outcome does not select these diagnostic winners. |
| **Acceptance** | Existing human approval is candidate-specific. Winner status does not mean the detector accepts or emits that candidate; no acceptance rule is established here. |
| **End-to-end detection** | Five views have usable line winners and four have usable paint winners. Their six-view union requires human selection between rankings. It is not an automatic six-of-nine success rate. |

The 19,286 all-camera candidates are not 19,286 labelled negatives in the ranking export. That export selects 17 distinct automatic winners plus two GX0 controls. Repeated panels of the same identity are not additional fits; shared frames or references do not establish independence. Nine views from five videos, including ShuttleSet median composites, are development material, not independent trials or designated holdouts. Neither score calibration nor a population false-positive rate can be inferred. The two additional hard videos remain reserved, as specified in the request. [S1–S4, S6, S10]

## One smallest fixed-pool comparison — an observability-and-correspondence audit

**Specification only; not run.** Use the **19 distinct exported winners**: the 17 `automatic_all_camera` line/paint winners across all nine existing views, plus GX0 observed-bank control winners `1864` and `5144`. This is the smallest already-exported set preserving both rankings on every development view and both ideal observed-bank contrary controls. Keep approved supplied-direction `89` as a documented comparator, not another automatic candidate or independent success. Deduplicate shared scene20 `0:2`; never merge scene16 and scene19 `1:60`. [S1, S3, S7]

**Question.** Where perfect paint agreement is wrong, is corroboration actually missing or spatially incompatible—information hidden by the profile aggregation—or does the observable background genuinely supply a coherent finite pattern, leaving court/scene identity unresolved? These explanations can coexist, including candidate-dependent cropping. The audit must allow “indeterminate,” not force a binary answer.

**Required features.** Freeze candidates, scores and existing judgements. Compare, per expected marking, the existing `interval_visible`, `interval_ridge`, `marking_ridge`, `stripe.exclusive_per_marking`, assignments, gates, homography, image dimensions and painted-interval mapping. Retrieve the remaining detailed ranking entries before interpreting their unexamined fields. Use the existing backgrounds to distinguish geometric unavailability from observable support/contradiction and to check whether support belongs to distinct, correctly connected finite markings. The latter requires spatially interpretable observation provenance or explicit visual judgement; aggregate assignment arrays alone are not enough. Record unavailable evidence as unavailable, not as zero.

**Positive contrary examples and fixed outcomes.** Preserve approved Amateur-2 `30:33` against mat-border `30:30`; usable scene19 `1:60` against false `165:6702`; and false frame28019 `184:4123` despite full profile availability. Preserve the approved GX0 controls despite floor rejection/cropping, and the existing Amateur-3, scene16 and scene20 positives despite acceptable marking discrepancies. Retain the scene17 paint panel's lack of overall approval rather than inventing a label. These outcomes are already recorded; no numeric success threshold is substituted. [S3, S5–S7]

**Discriminating outcome and failure conditions.** If the false candidates have observable extent/junction or line/profile correspondence contradictions absent from the positive contrary examples, that supports a specific additional-evidence hypothesis within this fixed set. If a false candidate remains spatially coherent under those observable checks, those checks have not resolved identity; another observation, such as scene/target association, is still needed. If a proposed contradiction also occurs on approved partial or weakly marked courts, that cue has failed as a sufficient discriminator. Inaccessible images, unresolved observability, unknown provenance, or genuinely identical evidence states make the comparison indeterminate. No off-image paint outcome may be invented to rescue it.

This would be a **development diagnostic**, not a tuned-and-tested generalisation result, full-pool ranking replay or acceptance benchmark. It changes neither the independent direction experiments nor their fixed protocol.

## What needs no further annotation—and what does

**Already decidable:** the identical-profile counterexample; the conditional-mean missingness mechanism; the distinction between unavailable and failed tests; the floor/player counterexamples; opposing ranking preferences; coordinate-scale distinctions; and the gap between availability, ranking, acceptance and detection. These follow from frozen methods, recovered measurements and existing judgements. No new direction experiment or pixel tolerance is needed.

**Still unresolved:** whether a particular failed test represents observable missing paint rather than occlusion/weakness; which physical structures supplied the false winners' passing samples; whether finite/joint correspondence separates every selected contrary example; and why the floor gate rejects approved GX0 courts. These require image-level judgement and/or evidence not present in the accessed summaries. Full floor implementation is needed to diagnose its mechanism; appropriately judged rejected-candidate evidence is needed to evaluate its consequences. Broader candidate evidence and separate evaluation are needed for acceptance or generalisation claims. Merely completing my partial archive retrieval would fill an access gap, not automatically supply those semantic labels.

**Bottom line:** preserve the distinction between “this candidate explains the sampled appearance” and “the observations identify this as the court.” The present examples establish the gap between those claims more strongly than they establish a replacement rule.

## Source keys and handover contents

All repository paths are relative to the evidence root above and pinned to the stated commit. Exact access status and Git blob hashes are in `access_manifest.json`.

| Key | Repository source / relevant location |
|---|---|
| S1 | `evaluation/README.md`, Ranking and visibility; Interpretation limits. |
| S2 | `automatic_axes_results.md`, results, visual inspection and GX0 control. |
| S3 | `automatic_axes_visual_judgements.md`, exact case-specific rulings and candidate identities. |
| S4 | `evaluation/method_excerpts.md`: `inspect_appearance.profiles`, `detector._visible_samples`, `detector._filter_painted_stripes`, `run_automatic.winner_ids`, `assignment.MARKINGS`, `assignment.MARKING_INTERVALS`, painted court intervals. |
| S5 | `evaluation/ranking_records.json.gz`, four complete retrieved Amateur-2 entries, scoped by case and `automatic_all_camera`. |
| S6 | `measurements.json.gz`, `automatic_arms`, `extreme_paint_winners`, control summaries. |
| S7 | `gx0_control_measurements.json.gz`, approved comparator, actual winners, dimensions and visual judgements. |
| S8 | `automatic_axes_visual_check.html`, partially accessed source only. |
| S9 | `gx0_control_visual_check.html`, source only; no image inspection. |
| S10 | `methods.md`, population, automatic directions, validation and limitations. |
| S11 | GitHub commit metadata for `7299ff3`, resolved full revision and parent. |

`candidate_evidence_ledger.json` preserves all 17 automatic winner summaries, both actual GX0 control winners, the separate approved comparator, available detailed profiles and source locators. Unknown-to-this-review profile details are explicitly distinguished from `None` in a saved profile. Control population namespaces are document-scoped handover labels, not invented literal tokens from the unread portion of the ranking export.

`retrieved_ranking_entries.json` contains the four complete entries actually recovered. `source_snapshots/` contains the two fully verified compact gzip sources. No gallery images are duplicated. No repository code, score, annotation or experiment protocol was changed.
