# New committed-record findings: a bounded temporal selection audit

## Revision and evidence actually inspected

Repository: `ahalp90/badminton_cv_annotator`. Requested branch context: `fix/court-det`. Every repository read remained pinned to **`d0c9a12fb62eea64e1e4cec523d6f29a42e37a2a`**; no branch-head update or repository change was made.

The new numerical work uses `experiments/annotator/independent_court/recorded/player_guided/replay.zip`. Relative to the previous assessment, inspection was extended to the **complete logical `records[0]` object: `window="yellow_short"`, `stage="floor_only"`, 33 candidates**, including every candidate's three floor scores, three net scores, corners, origin and saved reference metrics. The frame order **14, 90, 156** was verified from the fully recovered `people_short/yellow_short.json.gz`, rather than inferred from reference-key order. Its dimensions are 1280 × 720. The complete `joint_short.py` was also recovered and inspected, not executed.

Integrity checks: the `joint_short.py` ZIP CRC and the people entry's ZIP and gzip CRCs pass. The results gzip was recovered only as a prefix: 9,830 of 80,059 entry bytes, yielding 46,200 JSON bytes. That prefix includes the entire 30,936-byte Yellow floor record, followed by part of the `initial` record. Sixteen complete candidate objects from that second record match the floor record's corners, score vectors, camera errors and reference metrics exactly. All 33 stored floor scalar scores replay exactly. **The whole results-gzip CRC and whole archive Git blob SHA were not verified.** Recovery boundaries are machine-readable in `results/recovery_checks.json`.

The full archive, full 13-frame modern supplement, and repository image pixels were not recovered. No image registration, camera-stability measurement, model inference, fresh line extraction, geometry generation, detector acceptance decision, or timing benchmark was performed. These new findings concern **one older candidate population**, not GX/Amateur-2/Amateur-3 temporal performance. Source symbols and records are identified below; the previous modern findings remain attributed to the pinned reports.

## Recommendation

**There is now a small, directly computed reason to prioritize shared-candidate scoring in the later audit—not merely an architectural argument.** On the recovered Yellow population, sharing observations improves selection even when the candidate set and scoring cues are held fixed. However, there is also a stronger negative result: no ordinary monotone aggregation of its three saved floor scores can promote the much closer candidate, because a displaced court beats it in every observation.

The practical priority remains **same-pool independent versus shared scoring**, with generation coverage, ranking, acceptance and camera validity reported separately. Do not spend the next iteration merely swapping median for mean or another floor-score smoother. The result does not justify adding the old net cue universally, declaring an accepted detector, or changing the independent direction experiments.

## Finding 1 — A matched comparison is possible from saved records, and it shows a conditional temporal benefit

**New computation.** For each of the 33 saved unrefined geometries, the archive already has floor scores `f[t]` and net scores `n[t]` at all three anchors. I re-ranked those numbers without running repository detector code, modifying geometry, choosing candidates manually, or consulting references during selection.

I compared single-observation selection with shared selection separately for each of the two historical cue definitions:

- Floor: single score `f[t]`; shared score `median_t f[t]`.
- Historical floor-plus-net: single score `(3*f[t]+n[t])/4`; shared score `(3*median_t f[t]+median_t n[t])/4`.

The second shared expression preserves `joint_short.py::main` exactly: it combines componentwise medians. It is not silently replaced by the median of the per-frame composite score. The same saved candidate set is used in every cell. All principal winners are unique, so the audit's deterministic source-identity tie breaker does not affect these outcomes.

Candidate identities, within this older population:

| Label | `source_image` | `source_rank` | Index in `records[0].candidates` |
|---|---|---:|---:|
| A | `yellow_short_frame_90` | 0 | 0 |
| B | `yellow_short_frame_90` | 2 | 4 |
| C | `yellow_short_frame_156` | 0 | 1 |

References were joined only after these selection decisions were locked. Errors below are the existing maximum-corner metric in 1280 × 720 coordinates, evaluated on the actual anchor receiving each selected geometry.

| Frozen cue definition | Independent winners at 14 / 90 / 156 | Shared winner | Worst independent corner error | Worst shared corner error |
|---|---|---|---:|---:|
| Floor | A / A / C | A | 1,270.997 px | 221.189 px |
| Floor plus net, historical 3:1 | A / B / B | B | 221.189 px | 26.012 px |

For floor-only scoring, sharing prevents the especially displaced frame-156 selection but still chooses A. With the net cue held fixed, sharing changes the frame-14 selection to B; the other two selections already choose B independently. Worst landmark RMS, also from existing references, changes from **206.060 to 61.821 px** in the floor comparison and **59.399 to 4.600 px** in the net-inclusive comparison. These landmark results support a geometric improvement without inventing a usability cutoff.

**Important limitation.** This is a *matched surviving-population ranking comparison*, not a complete independent-frame detector baseline. The 33 candidates have already passed the archive's shared-player check and nonnegative median-floor filter, after 12-native-pixel deduplication. Candidates excluded by those operations are not reintroduced. Sixteen of the 33 have a negative floor sentinel on one observation: counts by anchor are 15 / 0 / 1. That is another reason not to interpret this table as per-frame acceptance performance.

**Contrary evidence.** B's 26.012-pixel error is not a new visual approval or accepted-court result. The earlier Letterboxed headline still worsens from 10.06 to 17.38 pixels when the net cue is added; that experiment cannot justify deploying this cue everywhere. The already-good modern Amateur-3 candidate `43:22603` was not tested by this new calculation.

**Falsifiable implication.** A modern same-pool comparison can have a genuine temporal benefit without changing the generator. But it must demonstrate the benefit within a fixed scorer/cue arm, not compare a floor-only baseline against a temporally aggregated, net-enhanced and refined system.

## Finding 2 — The saved floor evidence supplies a dominance certificate, not just a bad median result

**New computation.** The three decisive floor-score vectors are:

| Candidate | Frame 14 | Frame 90 | Frame 156 | Worst corner error across anchors |
|---|---:|---:|---:|---:|
| A | 0.777778 | 0.854167 | 0.784722 | 221.189 px |
| B | 0.663194 | 0.777778 | 0.760417 | 26.012 px |
| C | 0.715278 | 0.775694 | 0.785417 | 1,270.997 px |

Using the complete 33-candidate floor record, **A scores strictly higher in all three columns than 31 of its 32 competitors**, including B. Only C escapes domination because its frame-156 floor score is slightly higher. Consequently the floor-score Pareto frontier—the candidates not beaten componentwise by another candidate—contains only A and C.

Reference-only evaluation after selection shows B has both the lowest worst-corner error and the lowest worst-landmark RMS in this 33-candidate population. This diagnostic does not select the output: B is independently the unique maximizer of the pre-existing net-inclusive shared score.

**Mathematical deduction.** For A and B,

`f[t](A) > f[t](B)` for every saved observation `t`.

Therefore every positive-weight average, and the ordinary mean, minimum, maximum, median or quantile of these same observations, favors A over B. More generally a coordinatewise nondecreasing aggregate cannot strictly prefer a dominated score vector; a degenerate flat rule could tie it but would need a separate selection criterion. A strictly increasing aggregate cannot select any of the 31 dominated candidates. Common strictly increasing recalibrations of each frame's scores do not remove this ordering.

This is stronger than saying that the particular historical median failed. **Changing the temporal aggregator while leaving these observations and the floor scorer unchanged cannot recover B.** The explicit 31 dominance certificates and componentwise margins are included in `results/dominance_certificates.csv`.

**Boundary and contrary evidence.** This is not a theorem about additional frames or about modern paint/line scores. A new observation could reverse the ordering; a different cue can already do so here. B's saved net scores are approximately 0.873173 / 0.872979 / 0.858649, compared with A's 0.550461 / 0.529515 / 0.545169. The net-inclusive arm exploits this difference. The data do not establish whether the underlying floor confusion was occlusion, line identity, background structure or another scorer mechanism.

**Falsifiable implication.** Once a modern same-geometry cross-frame matrix exists, check whether a useful alternative is dominated. If it is, stop tuning the aggregation rule for that frozen matrix: the needed change lies in observations, cue discrimination, geometry generation or another explicitly different criterion. The missing observation is not merely “more frames”; it is a frame that adds discriminating support for the same useful geometry.

## Finding 3 — Score leave-one-out can conceal dependence on the generating frame

**New computation.** Holding out each anchor's score in turn, while retaining all 33 candidates, the historical 3:1 shared scorer chooses B in all three two-observation comparisons. That looks reassuring, but B is credited to frame 90. When frame 90's score is held out, its generated geometry remains available.

I therefore ran one explicitly separate provenance sensitivity: hold out frame 90's score and also exclude the **14 saved candidates credited to `yellow_short_frame_90`**. Nineteen candidates remain. Scoring those on frames 14 and 156 selects `yellow_short_frame_156`, `source_rank=1`—D—whose saved maximum-corner error **at held anchor 90 is 288.297 pixels**, instead of B's 25.786 pixels. The closest remaining candidate by reference-only evaluation is `yellow_short_frame_156`, `source_rank=4`: **63.051 pixels at anchor 90**, or 63.257 pixels at the worst of the three anchors.

This separates two effects within the sensitivity: the credited candidate set loses its closest geometry, and the frozen ranking does not choose the closest remaining geometry. No oracle candidate was used as output.

**Limitation.** This is not an independent hard holdout and not an exact reconstruction of generation without frame 90. The old deduplication stores one credited origin and can suppress near-duplicates from other origins. The shared player selection and original survival filter also use the clip. Removing credited origins cannot undo those operations. All leave-one-out results are accordingly labeled **diagnostics, not holdouts**, in the assets.

**Contrary interpretation worth preserving.** Dependence on one good generating observation is not itself a failure of the per-view target: that target deliberately needs good geometry only once. The result does show why success on held-out *score columns* must not be advertised as independent frame-level generalization, and why generation coverage must be reported separately from ranking.

**Falsifiable implication.** Preserve multi-origin provenance in the later audit, or state this limitation. A claimed temporal ranking improvement should survive a clear accounting of which frames supplied the winning geometry, which only scored it, and which evaluated it.

## What this changes, and what is still missing

The original three-arm headline table remains confounded. The new calculation adds a distinct conditional independent-versus-shared comparison that was absent from that table. It supplies evidence that shared selection can help this older Yellow case, plus an explicit certificate that floor-score smoothing alone cannot fix its useful alternative's ranking.

It does not rank pooled-line generation against shared scoring in the modern pipeline, demonstrate a camera guard, or establish production acceptance. The modern direction diagnosis still matters: shared ranking cannot create absent directions or geometry. No historical scores or proposals were mixed with modern populations. Missing modern results remain unmeasured, not failures.

The minimum consequential missing modern evidence is still **a fixed-geometry cross-frame score matrix attached to an independently established camera-view state**, with the already-good Amateur-3 case included, a reference-blind fixed output rule, and acceptance reported separately. Within-sample agreement must not be extended to unseen intervals. References may evaluate but may not establish view grouping or choose output. No new annotations or expanded sweep are required by this extension; the previously bounded later-audit proposal and independent B/M/R/MR experiments remain unchanged.

A useful next decision observation would be: the same automatically generated modern court receives discriminating support across independently same-view observations, a fixed shared ranker improves selection over the same-pool independent comparator, and Amateur-3 does not regress. If the useful modern candidate is uniformly dominated, these new certificates explain why simply changing the temporal average is not the right next intervention.

## Reproducibility and source index

**Executed:** standard-library numerical re-ranking and diagnostics; 15 passing software regression tests. Tests confirm exact saved floor-score replay, unique principal winners, source-order invariance, and unchanged selection after references/corners are removed or reference values are altered. They do not validate detector acceptance or camera stability.

**Primary source:** pinned `replay.zip!joint_short.py::main`; `replay.zip!joint_short/results.json.gz`, complete `records[0]`; complete `replay.zip!people_short/yellow_short.json.gz`. The first 16 complete candidates in the next `initial` record provide redundant field and top-score checks, not a claim of full second-record inspection.

**Context only:** `projective_patterns/evaluation/temporal_assessment.md`; `projective_patterns/evaluation/README.md`; `projective_patterns/automatic_axes_results.md`; `projective_patterns/automatic_axes_visual_judgements.md`; player-guided `README.md` and its earlier summary. The modern Amateur-3 approval belongs only to its exact modern candidate.

**Local outputs:** `results/analysis.json`, `results/selections.csv`, `results/dominance_certificates.csv`, `results/sensitivity_not_holdouts.csv`, `results/recovery_checks.json`, `results/test_log.txt`, and `results/floor_dominance.png`. Run instructions are in `README.md`.
