# Bounded extension: saved-score audit of the older Yellow shared-court experiment

This handover contains an executed, reference-blind selection audit on **33 complete saved candidates** from `yellow_short / floor_only`, at pinned repository revision `d0c9a12fb62eea64e1e4cec523d6f29a42e37a2a`.

Read `assessment.md` for findings, distinctions and limitations. This is not an end-to-end detector, a modern-pipeline result, an acceptance policy, or a camera-stability test.

## Reproduce the executed analysis

Python 3.10 or later; the audit and tests use only the standard library. Run from this directory:

```bash
python recover_excerpts.py
python audit_saved_scores.py --input data/yellow_floor_record.json --output results
python -m unittest discover -s tests -v
```

The first command verifies the recovered complete ZIP entries and the complete logical Yellow record in a partially decoded results-gzip prefix. It explicitly does **not** verify the whole results-gzip CRC or whole archive Git SHA. It also checks 16 complete candidate objects in the beginning of the saved `initial` stage against the floor table.

The second command recomputes selections from saved numerical floor/net scores. It never imports or executes the repository detector. The third command runs 15 audit regression checks, including reference-removal/mutation invariance and candidate-order invariance. These are software checks, not detector performance tests.

## Files

`data/yellow_floor_record.json` is the complete 33-candidate common-population fixture, including references for evaluation only. `data/yellow_anchor_metadata.json` preserves frame order and dimensions from the verified people archive entry. `results/analysis.json` contains selections, score margins, reference-only evaluation, Pareto-front certificates, and explicitly non-holdout sensitivity checks. CSVs expose those results for inspection. `results/floor_dominance.png` plots three fixed candidates on three observations; the joining lines are not a stability trace. `raw/` contains the exact inspected base64 ranges and recovered `joint_short.py`, for provenance.

The plot was generated with Matplotlib using default colors; Matplotlib is not required to reproduce the numerical audit.

## Optional local full-archive input

The same audit script accepts an existing local original archive:

```bash
python audit_saved_scores.py --input /path/to/committed/replay.zip --output results_all_saved
```

This input mode was transport-tested with a synthetic wrapper around the same Yellow fixture. **The full original archive and all three clips were not run here.** The script selects each complete `floor_only` record as a common unrefined saved population, and reads actual anchor order from `people_short`. It does not turn the archived clip grouping into verified camera-view grouping.

## Scientific boundary

The matched comparisons condition on candidates that survived the original shared-player check, 12-native-pixel deduplication, and nonnegative median-floor filter. They are not native independent-frame detection comparisons. References never select output. Historical 3:1 weights are preserved; no numerical usability or acceptance threshold is introduced. Missing modern results are not failures. The independent B/M/R/MR experiments and final hard holdouts are untouched.
