#!/usr/bin/env python3
"""Reconstruct inspected committed excerpts from the bundled GitHub base64 ranges.

Does not claim that the entire archive or results gzip has been recovered.
ZIP/gzip CRCs are checked only where a complete archive entry was recovered.
"""
import base64
import gzip
import hashlib
import json
from pathlib import Path
import struct
import zlib

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw"


def decoded_ranges(names):
    return base64.b64decode("".join((RAW / name).read_text() for name in names))


def unzip_local_entry_prefix(data):
    offset = data.index(b"PK\x03\x04")
    header = struct.unpack_from("<4s5H3I2H", data, offset)
    start = offset + 30 + header[-2] + header[-1]
    name = data[offset + 30:offset + 30 + header[-2]].decode()
    decoder = zlib.decompressobj(-15)
    output = decoder.decompress(data[start:start + header[7]])
    complete = decoder.eof and len(output) == header[8]
    if complete:
        assert zlib.crc32(output) == header[6], f"ZIP CRC mismatch: {name}"
    return name, output, {"complete_zip_entry": complete, "zip_crc32_expected": f"{header[6]:08x}",
                          "zip_crc32_verified": complete, "entry_bytes_recovered": len(output),
                          "entry_bytes_expected": header[8]}


def main():
    code_names = ["replay_141_185.b64"]
    people_names = ["replay_190_229.b64", "replay_230_309.b64", "replay_310_323.b64"]
    result_names = ["replay_4404_4463.b64", "replay_4464_4543.b64", "replay_4544_4623.b64"]
    name, code, code_info = unzip_local_entry_prefix(decoded_ranges(code_names))
    assert name == "joint_short.py" and code_info["complete_zip_entry"]
    assert code == (RAW / "joint_short.py").read_bytes()
    name, people_gz, people_info = unzip_local_entry_prefix(decoded_ranges(people_names))
    assert name == "people_short/yellow_short.json.gz" and people_info["complete_zip_entry"]
    people = json.loads(gzip.decompress(people_gz))  # Also checks inner gzip CRC.
    people_info["gzip_crc_verified"] = True
    name, result_gz_prefix, result_info = unzip_local_entry_prefix(decoded_ranges(result_names))
    assert name == "joint_short/results.json.gz" and not result_info["complete_zip_entry"]
    decoder = zlib.decompressobj(31)
    text = decoder.decompress(result_gz_prefix).decode("utf-8")
    assert not decoder.eof
    result_info.update({"gzip_crc_verified": False, "decoded_json_prefix_bytes": len(text.encode())})
    reader = json.JSONDecoder()
    start = text.index("[") + 1
    record, count = reader.raw_decode(text[start:])
    assert record["window"] == "yellow_short" and record["stage"] == "floor_only"
    fixture = json.loads((ROOT / "data/yellow_floor_record.json").read_text())
    assert fixture["records"] == [record]
    anchors = [a["frame_index"] for a in people["anchor_images"]]
    assert fixture["anchor_frames"]["yellow_short"] == anchors
    result_info.update({"complete_records_recovered": 1, "complete_record_bytes": len(text[start:start+count].encode()),
                        "complete_record_candidate_count": len(record["candidates"])})
    tail = text[start + count:]
    position = tail.index("[", tail.index('"candidates"')) + 1
    by_id = {(c["source_image"], c["source_rank"]): c for c in record["candidates"]}
    matches = 0
    first_initial = None
    while True:
        try:
            candidate, count = reader.raw_decode(tail[position:])
        except json.JSONDecodeError:
            break
        original = by_id[(candidate["source_image"], candidate["source_rank"])]
        assert all(candidate[k] == original[k] for k in ["corners_px", "floor_scores", "net_scores", "camera_error", "metrics"])
        if first_initial is None:
            first_initial = {k: candidate[k] for k in ["source_image", "source_rank", "score"]}
        matches += 1
        position += count
        position += len(tail[position:]) - len(tail[position:].lstrip(", "))
    info = {
        "repository": "ahalp90/badminton_cv_annotator",
        "revision": "d0c9a12fb62eea64e1e4cec523d6f29a42e37a2a",
        "archive_path": "experiments/annotator/independent_court/recorded/player_guided/replay.zip",
        "archive_git_blob_sha_reported_by_connector": "8562dcaa93d48afbfcef30ccb5506854fede8adb",
        "whole_archive_git_blob_sha_verified": False,
        "whole_archive_recovered": False,
        "entries": {"joint_short.py": code_info, "people_short/yellow_short.json.gz": people_info,
                    "joint_short/results.json.gz": result_info},
        "initial_stage_complete_candidate_objects_crosschecked_against_floor_record": matches,
        "initial_stage_top_candidate_from_partial_record": first_initial,
        "frame_order_verified_from_complete_people_entry": anchors,
        "input_fixture_sha256": hashlib.sha256((ROOT / "data/yellow_floor_record.json").read_bytes()).hexdigest(),
        "modern_13_frame_records_fully_recovered": False,
        "repository_images_visually_inspected": False,
        "camera_stability_measured": False,
    }
    (ROOT / "results/recovery_checks.json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
