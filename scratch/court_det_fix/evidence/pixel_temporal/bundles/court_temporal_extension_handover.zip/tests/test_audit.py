"""Regression checks for the bounded saved-score audit, not detector validation."""
import copy
import gzip
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("audit", ROOT / "audit_saved_scores.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
PAYLOAD = json.loads((ROOT / "data/yellow_floor_record.json").read_text())
RECORD = PAYLOAD["records"][0]
FRAMES = PAYLOAD["anchor_frames"]["yellow_short"]
A = "yellow_short_frame_90#rank=0"
B = "yellow_short_frame_90#rank=2"
C = "yellow_short_frame_156#rank=0"


class AuditTests(unittest.TestCase):
    def test_complete_record_and_anchor_order(self):
        self.assertEqual(len(RECORD["candidates"]), 33)
        self.assertEqual(FRAMES, [14, 90, 156])
        audit.validate_record(RECORD, FRAMES)

    def test_exact_saved_scalar_replay(self):
        report = audit.analyse(RECORD, FRAMES)
        self.assertEqual(report["saved_floor_scalar_max_abs_replay_error"], 0.0)

    def test_matched_floor_selections(self):
        lock = audit.lock_selections(RECORD, FRAMES)
        self.assertEqual([lock["independent"]["floor"][str(t)]["candidate_id"] for t in FRAMES], [A, A, C])
        self.assertEqual(lock["shared"]["floor"]["candidate_id"], A)

    def test_matched_net_selections(self):
        lock = audit.lock_selections(RECORD, FRAMES)
        cue = "floor_plus_net_3_to_1"
        self.assertEqual([lock["independent"][cue][str(t)]["candidate_id"] for t in FRAMES], [A, B, B])
        self.assertEqual(lock["shared"][cue]["candidate_id"], B)
        self.assertAlmostEqual(lock["shared"][cue]["score"], 0.7885571420192717, places=15)

    def test_all_principal_winners_unique(self):
        lock = audit.lock_selections(RECORD, FRAMES)
        for cue in audit.CUES:
            self.assertEqual(lock["shared"][cue]["top_tie_count"], 1)
            for t in FRAMES:
                self.assertEqual(lock["independent"][cue][str(t)]["top_tie_count"], 1)

    def test_references_can_be_removed_for_selection(self):
        stripped = copy.deepcopy(RECORD)
        for c in stripped["candidates"]:
            del c["metrics"]
            del c["corners_px"]
        self.assertEqual(audit.lock_selections(stripped, FRAMES), audit.lock_selections(RECORD, FRAMES))

    def test_reference_mutation_cannot_select(self):
        changed = copy.deepcopy(RECORD)
        for i, c in enumerate(changed["candidates"]):
            for m in c["metrics"].values():
                m["corner_max_error_px"] = float(10000 - i)
                m["landmark_rms_px"] = float(i)
        self.assertEqual(audit.analyse(changed, FRAMES)["selection_lock"], audit.analyse(RECORD, FRAMES)["selection_lock"])

    def test_candidate_input_order_does_not_select(self):
        changed = copy.deepcopy(RECORD)
        changed["candidates"].reverse()
        self.assertEqual(audit.lock_selections(changed, FRAMES), audit.lock_selections(RECORD, FRAMES))

    def test_pareto_certificate(self):
        front, certificates = audit.floor_front(RECORD["candidates"])
        self.assertEqual(set(front), {A, C})
        self.assertEqual(len(certificates), 31)
        a = next(c for c in RECORD["candidates"] if audit.identity(c) == A)
        dominated = [c for c in RECORD["candidates"] if all(x > y for x, y in zip(a["floor_scores"], c["floor_scores"]))]
        self.assertEqual(len(dominated), 31)
        self.assertIn(B, [audit.identity(c) for c in dominated])

    def test_evaluation_uses_selected_candidate_at_each_anchor(self):
        report = audit.analyse(RECORD, FRAMES)
        table = {(x["cue"], x["mode"]): x for x in report["summary"]}
        self.assertAlmostEqual(table[("floor", "independent")]["worst_corner_error_px"], 1270.9971877531482)
        self.assertAlmostEqual(table[("floor", "shared")]["worst_corner_error_px"], 221.18928210388145)
        self.assertAlmostEqual(table[("floor_plus_net_3_to_1", "independent")]["worst_landmark_rms_px"], 59.399324887604536)
        self.assertAlmostEqual(table[("floor_plus_net_3_to_1", "shared")]["worst_corner_error_px"], 26.012341001608263)

    def test_origin_exclusion_is_a_distinct_population(self):
        lock = audit.lock_selections(RECORD, FRAMES)
        cue = "floor_plus_net_3_to_1"
        self.assertEqual(lock["score_leave_one_out"][cue]["90"]["candidate_id"], B)
        changed = lock["origin_excluded_score_leave_one_out"][cue]["90"]
        self.assertEqual(changed["population_size"], 19)
        self.assertEqual(changed["candidate_id"], "yellow_short_frame_156#rank=1")

    def test_negative_scores_are_preserved_not_treated_as_missing_successes(self):
        report = audit.analyse(RECORD, FRAMES)
        self.assertEqual(report["negative_floor_count_by_anchor"], [15, 0, 1])
        self.assertEqual(report["candidates_with_any_negative_floor"], 16)

    def test_loader_does_not_infer_anchor_order_from_reference_keys(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.json"
            path.write_text(json.dumps({"records": [RECORD]}))
            with self.assertRaises(ValueError):
                audit.read_input(path)

    def test_zip_loader_matches_bundled_excerpt(self):
        # A synthetic transport wrapper around the same excerpt, NOT the full original replay.
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "fixture.zip"
            with ZipFile(path, "w") as archive:
                archive.writestr("joint_short/results.json.gz", gzip.compress(json.dumps({"records": [RECORD]}).encode()))
                archive.writestr("people_short/yellow_short.json.gz", gzip.compress(json.dumps({"anchor_images": [{"frame_index": t} for t in FRAMES]}).encode()))
            data, frames = audit.read_input(path)
            self.assertEqual(data["records"], [RECORD])
            self.assertEqual(frames["yellow_short"], FRAMES)

    def test_refined_population_rejected(self):
        changed = {**RECORD, "stage": "refined"}
        with self.assertRaises(ValueError):
            audit.validate_record(changed, FRAMES)


if __name__ == "__main__":
    unittest.main()
