#!/usr/bin/env python3
"""Audit saved shared-court score tables without executing repository detector code.

Reads either the bundled complete-record excerpt or a local committed replay.zip.
Selection uses only saved scores and deterministic source-identity tie breaking.
Reference metrics are joined after the selection decisions have been locked.
Python 3.10+; standard library only. No network, inference, or repository writes.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
from statistics import median
from typing import Any, Sequence
from zipfile import ZipFile

Json = dict[str, Any]
CUES = ("floor", "floor_plus_net_3_to_1")


def identity(candidate: Json) -> str:
    return f"{candidate['source_image']}#rank={candidate['source_rank']}"


def read_input(path: Path) -> tuple[Json, dict[str, list[int]]]:
    """ZIP reads validate ZIP and gzip CRCs; JSON excerpts carry a scope declaration."""
    if not path.is_file():
        raise ValueError(f"Input does not exist: {path}")
    if path.suffix.lower() == ".zip":
        with ZipFile(path) as archive:
            payload = json.loads(gzip.decompress(archive.read("joint_short/results.json.gz")))
            frames = {}
            for window in sorted({r["window"] for r in payload["records"]}):
                people = json.loads(gzip.decompress(archive.read(f"people_short/{window}.json.gz")))
                frames[window] = [int(a["frame_index"]) for a in people["anchor_images"]]
        payload["scope"] = "Complete locally supplied archive; numerical saved-record audit only."
    else:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if "anchor_frames" not in payload:
            raise ValueError("JSON input must provide explicit anchor_frames; metric-key order is not inferred.")
        frames = payload["anchor_frames"]
    return payload, frames


def validate_record(record: Json, frames: list[int]) -> None:
    if record.get("stage") != "floor_only":
        raise ValueError("Use floor_only as the common unrefined saved population.")
    if not frames or len(frames) != len(set(frames)):
        raise ValueError("Anchor frames must be nonempty and unique.")
    candidates = record.get("candidates", [])
    if not candidates:
        raise ValueError("No saved candidates; this is not a successful selection case.")
    ids = [identity(c) for c in candidates]
    if len(ids) != len(set(ids)):
        raise ValueError("Source identities are not unique within the window.")
    for c in candidates:
        for key in ("floor_scores", "net_scores"):
            values = c[key]
            if len(values) != len(frames) or not all(math.isfinite(float(x)) for x in values):
                raise ValueError(f"Invalid {key} vector in {identity(c)}")
        if not math.isfinite(float(c["score"])):
            raise ValueError("Nonfinite saved floor score.")
        for frame in frames:
            if str(frame) not in c["metrics"]:
                raise ValueError(f"Missing evaluation metric for anchor {frame}")


def score(candidate: Json, columns: Sequence[int], cue: str) -> float:
    if not columns:
        raise ValueError("At least one scoring observation is required.")
    floor = float(median(candidate["floor_scores"][j] for j in columns))
    if cue == "floor":
        return floor
    if cue == "floor_plus_net_3_to_1":
        net = float(median(candidate["net_scores"][j] for j in columns))
        # Preserve joint_short.py: componentwise medians, then the historical 3:1 mixture.
        return (3.0 * floor + net) / 4.0
    raise ValueError(f"Unknown cue: {cue}")


def choose(candidates: list[Json], columns: Sequence[int], cue: str) -> Json:
    """Reference-blind selection. Negative floor sentinels remain as stored."""
    if not candidates:
        raise ValueError("Empty candidate population.")
    ordered = sorted(candidates, key=lambda c: (-score(c, columns, cue), identity(c)))
    best = ordered[0]
    best_score = score(best, columns, cue)
    return {
        "candidate_id": identity(best),
        "score": best_score,
        "top_tie_count": sum(score(c, columns, cue) == best_score for c in candidates),
        "runner_up_gap": None if len(ordered) < 2 else best_score - score(ordered[1], columns, cue),
    }


def floor_front(candidates: list[Json]) -> tuple[list[str], list[Json]]:
    front, certificates = [], []
    for target in candidates:
        dominators = []
        for source in candidates:
            margins = [a - b for a, b in zip(source["floor_scores"], target["floor_scores"])]
            if all(m >= 0 for m in margins) and any(m > 0 for m in margins):
                dominators.append((identity(source), margins))
        if not dominators:
            front.append(identity(target))
        else:
            source_id, margins = min(dominators, key=lambda x: x[0])
            certificates.append({"dominator": source_id, "target": identity(target),
                                 "margins_by_anchor": margins, "strict_in_every_anchor": all(m > 0 for m in margins)})
    return sorted(front), certificates


def lock_selections(record: Json, frames: list[int]) -> Json:
    """No read of corners, metrics, reference labels, or acceptance thresholds."""
    candidates = record["candidates"]
    all_columns = list(range(len(frames)))
    locked: Json = {"independent": {}, "shared": {}, "score_leave_one_out": {},
                    "origin_excluded_score_leave_one_out": {}}
    for cue in CUES:
        locked["independent"][cue] = {str(t): choose(candidates, [j], cue) for j, t in enumerate(frames)}
        locked["shared"][cue] = choose(candidates, all_columns, cue)
        locked["score_leave_one_out"][cue] = {}
        locked["origin_excluded_score_leave_one_out"][cue] = {}
        if len(frames) < 2:
            continue
        for held, frame in enumerate(frames):
            train = [j for j in all_columns if j != held]
            locked["score_leave_one_out"][cue][str(frame)] = choose(candidates, train, cue)
            # Sensitivity only: credited origin is incomplete after historical deduplication.
            excluded_origin = f"{record['window']}_frame_{frame}"
            subset = [c for c in candidates if c["source_image"] != excluded_origin]
            locked["origin_excluded_score_leave_one_out"][cue][str(frame)] = (
                {**choose(subset, train, cue), "population_size": len(subset), "excluded_origin": excluded_origin}
                if subset else {"candidate_id": None, "population_size": 0, "excluded_origin": excluded_origin}
            )
    return locked


def metric(candidate: Json, frame: int) -> Json:
    values = candidate["metrics"][str(frame)]
    return {"corner_max_error_px": float(values["corner_max_error_px"]),
            "landmark_rms_px": float(values["landmark_rms_px"])}


def analyse(record: Json, frames: list[int]) -> Json:
    validate_record(record, frames)
    candidates = record["candidates"]
    by_id = {identity(c): c for c in candidates}
    locked = lock_selections(record, frames)
    front, certificates = floor_front(candidates)
    # References enter only below this point, after the score-only decisions are fixed.
    rows, summaries = [], []
    for cue in CUES:
        for mode in ("independent", "shared"):
            local = []
            for frame in frames:
                choice = locked[mode][cue][str(frame)] if mode == "independent" else locked[mode][cue]
                row = {"window": record["window"], "cue": cue, "mode": mode,
                       "evaluation_frame": frame, **choice, **metric(by_id[choice["candidate_id"]], frame)}
                rows.append(row)
                local.append(row)
            summaries.append({"cue": cue, "mode": mode,
                              "worst_corner_error_px": max(r["corner_max_error_px"] for r in local),
                              "worst_landmark_rms_px": max(r["landmark_rms_px"] for r in local),
                              "candidate_ids_in_anchor_order": [r["candidate_id"] for r in local]})
    loo = []
    for method in ("score_leave_one_out", "origin_excluded_score_leave_one_out"):
        for cue in CUES:
            for key, choice in locked[method][cue].items():
                frame = int(key)
                if choice["candidate_id"] is None:
                    continue
                subset = candidates if method == "score_leave_one_out" else [
                    c for c in candidates if c["source_image"] != choice["excluded_origin"]]
                loo.append({"method": method, "cue": cue, "held_score_frame": frame, **choice,
                            **metric(by_id[choice["candidate_id"]], frame),
                            "winner_credited_to_held_frame": by_id[choice["candidate_id"]]["source_image"] == f"{record['window']}_frame_{frame}",
                            "evaluation_only_best_available_held_corner_px": min(metric(c, frame)["corner_max_error_px"] for c in subset),
                            "evaluation_only_best_available_worst_corner_px": min(
                                max(metric(c, t)["corner_max_error_px"] for t in frames) for c in subset)})
    front_details = []
    for cid in front:
        c = by_id[cid]
        front_details.append({"candidate_id": cid, "floor_scores": c["floor_scores"],
                              "worst_corner_error_px": max(metric(c, t)["corner_max_error_px"] for t in frames),
                              "worst_landmark_rms_px": max(metric(c, t)["landmark_rms_px"] for t in frames)})
    return {
        "window": record["window"], "source_stage": "floor_only", "anchor_frames": frames,
        "candidate_count": len(candidates), "selection_lock": locked,
        "saved_floor_scalar_max_abs_replay_error": max(abs(float(c["score"]) - score(c, range(len(frames)), "floor")) for c in candidates),
        "negative_floor_count_by_anchor": [sum(c["floor_scores"][j] < 0 for c in candidates) for j in range(len(frames))],
        "candidates_with_any_negative_floor": sum(any(x < 0 for x in c["floor_scores"]) for c in candidates),
        "summary": summaries, "evaluated_selections": rows,
        "floor_pareto_front": front_details, "floor_dominance_certificates": certificates,
        "leave_one_out_diagnostics_not_holdouts": loo,
        "limitations": [
            "Conditional on the shared-player-filtered, deduplicated, median-floor-surviving saved population.",
            "Not native per-frame generation, an acceptance decision, or camera-stability verification.",
            "Origin-excluded diagnostics do not reconstruct candidates removed by original deduplication.",
            "References evaluate locked outputs; no reference-based selection or new acceptance threshold.",
            "Development data only; score leave-one-out is not an independent held-out-frame experiment.",
        ],
    }


def write_csv(path: Path, rows: list[Json]) -> None:
    if not rows:
        return
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def run(input_path: Path, output: Path) -> Json:
    payload, frames = read_input(input_path)
    selected_records = [r for r in payload["records"] if r["stage"] == "floor_only"]
    if len({r["window"] for r in selected_records}) != len(selected_records):
        raise ValueError("Duplicate floor_only records for a window.")
    if not selected_records:
        raise ValueError("No complete floor_only record found.")
    result: Json = {
        "schema": "court-temporal-saved-score-audit/1",
        "input_sha256": hashlib.sha256(input_path.read_bytes()).hexdigest(),
        "input_scope": payload.get("scope", "Unspecified input scope"),
        "revision": payload.get("revision", "Read from local archive; revision not inferred"),
        "cue_weights": {"floor": 1.0, "floor_plus_net_3_to_1": [0.75, 0.25]},
        "repository_detector_code_executed": False, "new_model_inference": False,
        "court_acceptance_tested": False, "camera_stability_tested": False,
        "records": [analyse(r, frames[r["window"]]) for r in selected_records],
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "analysis.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    for key, name in [("evaluated_selections", "selections.csv"),
                      ("floor_dominance_certificates", "dominance_certificates.csv"),
                      ("leave_one_out_diagnostics_not_holdouts", "sensitivity_not_holdouts.csv")]:
        write_csv(output / name, [{"window": r["window"], **v} for r in result["records"] for v in r[key]])
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Complete-record JSON excerpt or local replay.zip")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = run(args.input, args.output)
    except (ValueError, KeyError, OSError, json.JSONDecodeError) as exc:
        parser.exit(2, f"Audit failed: {exc}\n")
    for record in result["records"]:
        print(record["window"], "candidates=", record["candidate_count"], "floor_replay_error=", record["saved_floor_scalar_max_abs_replay_error"])
        for summary in record["summary"]:
            print(" ", summary["cue"], summary["mode"], f"worst_corner={summary['worst_corner_error_px']:.6f}")


if __name__ == "__main__":
    main()
