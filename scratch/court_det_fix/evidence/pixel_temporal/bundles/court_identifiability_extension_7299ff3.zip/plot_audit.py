#!/usr/bin/env python3
"""Render the analytical camera figure from audit_results.json, without images."""
from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt

folder = Path(__file__).resolve().parent
scene = json.loads((folder/'results/audit_results.json').read_text())['scene19']
scales = np.linspace(.95, 1.05, 301)
errors = np.hypot(scene['cosine_at_fixed_focal'], scene['log_axis_norm_ratio_at_fixed_focal']-np.log(scales))
fig, ax = plt.subplots(figsize=(9, 4.8))
ax.plot(scales, errors, label='Camera error at the original, unchanged focal length')
ax.axhline(.1, linestyle='--', label='Existing camera-error bound')
for witness in scene['witnesses']:
    a = witness['longitudinal_scale_a']
    error = witness['camera_error_at_unchanged_focal']
    ax.plot(a, error, marker='o')
    ax.annotate(f"a = {a:.2f}\nCorner change: {witness['max_corner_displacement_working_px']:.1f} px",
                (a, error), xytext=(0, -39 if a == 1 else 12), textcoords='offset points',
                ha='left' if a < 1 else 'right' if a > 1 else 'center', fontsize=9)
ax.set(title='Scene19 false winner: a court-length ambiguity survives the camera bound',
       xlabel='Longitudinal scale a (analytical witnesses, not generated candidates)',
       ylabel='Camera-error objective', xlim=(.943, 1.057), ylim=(.049, .108))
ax.legend(loc='lower right', fontsize=9)
ax.grid(True, alpha=.25)
fig.text(.5, .01, 'At a = 0.95, 1.00 and 1.05, all five available clipped paint intervals are geometrically unchanged.\n'
         'Corner changes are relative to the saved false candidate, in 960 × 540 working pixels; no image scores were rerun.',
         ha='center', fontsize=9)
fig.tight_layout(rect=(0, .075, 1, 1))
fig.savefig(folder/'results/scene19_camera_ambiguity.png', dpi=180)
fig.savefig(folder/'results/scene19_camera_ambiguity.svg')
plt.close(fig)
