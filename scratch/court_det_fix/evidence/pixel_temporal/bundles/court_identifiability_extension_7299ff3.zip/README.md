# Read-only court identifiability extension

Start with **extension_report.md**. All evidence is pinned to `7299ff3`.

Reproduce numerical diagnostics using:

```bash
python audit.py --inputs inputs --out results
```

Requires NumPy and OpenCV. The script is an offline numerical audit, not detector code or a proposed selector. It does not rerun image scores or direction experiments. Analytical homographies are explicitly not claimed to belong to a generated candidate pool.

Complete compact gzip archives are verified against Git blob hashes; the detailed ranking file contains only four decoded entries from a partial archive and carries a separate access limitation. `source_access_manifest.json` documents that distinction.

`results/audit_results.json` contains all calculations. The PNG/SVG camera figure is analytical, not an image overlay. No new visual judgements were made.
