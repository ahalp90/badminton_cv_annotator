# Court ranking: a measured observability gap and a concrete support alias

## Evidence accessed for this extension

Repository: `ahalp90/badminton_cv_annotator`; evidence revision **`7299ff3f74bf51dc3bc59582c79190dbc81666ca`** (`7299ff3`), not the current branch head. The evidence guide identifies `b90518c` as the scientific basis.

I re-read the pinned guide and relevant method excerpts, and re-verified the complete local `measurements.json.gz` and `gx0_control_measurements.json.gz` against their committed Git blob hashes. The four previously recovered complete detailed ranking entries were cross-checked against the verified compact measurements. I additionally read the committed `net_geometry.py`, `stripe_observations.py`, `paint_geometry.py`, relevant `detector.py` and `assignment.py` sections, and `player_guided.py`.

The complete detailed ranking archive was **not** recovered. Its four decoded entries come from a partial gzip prefix; the whole archive's checksum has not been verified. Their saved scores, gates and corners match the verified compact archive exactly. This is recorded separately from complete-file verification in `source_access_manifest.json`.

I obtained the scene19 PNG header, establishing native dimensions **960 × 540**, but did not open its pixels or render either gallery. **No new visual judgement is claimed.** Existing approvals and rejections retain their exact candidate identities.

## Result

**Yes: the committed contents support two substantive extensions.** The scene19 false winner has an explicit one-parameter court-length ambiguity that preserves its available paint-sampling geometry while remaining below the existing camera-error bound. The all-eleven Amateur-2 false winner has a different, directly measurable problem: two nominal markings become subpixel-separated, and the saved fragment assignments show strong competition between those identities.

These are stronger conclusions than “missing paint might matter” or “backgrounds might imitate lines.” They identify a specific unconstrained geometric mode and a specific support alias. They do **not** establish a universal rejection or acceptance rule.

## 1. Scene19: the visible pattern leaves a court-length degree of freedom

### Recorded starting point

Identity: **`(shuttleset_03_scene_0019, automatic_all_camera, 165:6702)`**.

The committed paint score is 1.0; the existing visual judgement rejects it. Its available markings are left/right singles and doubles sidelines, plus far short service. The centre, both baselines, far long service, near short service and near long service are unavailable. The unavailable centre has two intervals. [S1–S4]

### Newly computed clipping audit

Reconstructing the homography from the verified saved corners and replaying the documented clipping geometry reproduces **all twelve saved availability flags**. In this candidate, all seven unavailable intervals have **no image intersection**; none is merely a short, intersecting interval below the existing 12-working-pixel limit.

| Available interval | Clipped span, working pixels | Endpoint evidence |
|---|---:|---|
| Left doubles | 959.032629 | Both visible ends are image clipping boundaries |
| Left singles | 959.032629 | Both visible ends are image clipping boundaries |
| Right singles | 959.032629 | Both visible ends are image clipping boundaries |
| Right doubles | 959.032629 | Both visible ends are image clipping boundaries |
| Far short service | 101.320419 | One clipped end and one projected model endpoint |

This does not establish physical occlusion or absence. It establishes exactly which finite model intervals contribute to the current observation and that the four longitudinal intervals supply **no observed baseline termination**.

### An explicit ambiguity, not a hypothetical missing-data penalty

Let `H` be this court-to-image homography and `y0 = 4.72 m`, the far short-service coordinate. The executable audit uses the source's float32 endpoint value. Define

\[
T_a=\begin{bmatrix}1&0&0\\0&a&(1-a)y_0\\0&0&1\end{bmatrix},\qquad H_a=HT_a,\quad a>0.
\]

This changes the longitudinal scale about the far short-service line. It leaves every constant-`x` supporting line unchanged as a line, and fixes `y=y0` pointwise. Its first two homography columns also keep the same vanishing directions, because only the second column's scale changes. When the sideline ends remain beyond the image, their clipped spans are unchanged too.

For the fixed witnesses **`a = 0.95, 1.00, 1.05`**, I verified the same availability mask and the same clipped endpoints to at most **9.1 × 10⁻¹³ working pixels**. Both centre intervals and all other unavailable intervals remain outside the image. Nevertheless, the maximum corner displacement from the saved false court is **397.739439 working pixels** at either non-unit witness.

This is not a distance from the true court, and the witnesses are **not claimed to be members of the generated candidate pool**. They are mathematical alternatives demonstrating what the available sampling geometry does not identify.

### The existing camera bound does not remove this mode

I replayed `net_geometry._camera_from_corners`'s float32/OpenCV reconstruction and focal-grid objective for the saved corners. It reproduces the committed camera error **exactly**: `0.06941643378323906`. [S7]

At the original best grid focal length, approximately **3.521953 image widths**, the objective is

\[
E(a)=\sqrt{c^2+(r-\log a)^2},
\]

because the first homography axis is unchanged and the second is multiplied by `a`. Here `c` is their calibrated-axis cosine and `r` their log norm ratio at that fixed focal length. The float64 geometric reconstruction gives `c = 0.0694124263` and `r = 0.0007449675`.

| Analytical scale `a` | Maximum corner change from the saved false candidate, working pixels | Camera error at the **unchanged** focal length |
|---|---:|---:|
| 0.95 | 397.739439 | 0.086753 |
| 1.00 | 0 | 0.069416 |
| 1.05 | 397.739439 | 0.084418 |

All three are below the **existing** 0.1 bound. This does not require choosing a new focal length for the witnesses. Passing this approximate objective is not proof that every witness is an exact physical camera calibration. The inequality at this focal alone allows approximately `0.931238 ≤ a ≤ 1.075441`. That is an analytically derived camera-compatibility interval, not a new acceptance threshold.

The float64 reconstruction used for the geometric proof differs from the source's float32 camera reconstruction by about `9.96e-9` in the baseline camera error. Both computations and the exact source replay are retained in the results. No pixel-profile scores were rerun; floating-point boundary handling prevents claiming bitwise identity of image-sampling outputs solely from sub-picopixel endpoint agreement.

### What distinguishes the remaining mode

The ideal named-line constraint matrix for these five supporting lines has **rank 7**, leaving one homography degree of freedom after homogeneous scale. Adding the centre supporting line alone leaves rank 7. Adding another distinct transverse marking raises the rank to 8. This is an algebraic information calculation, **not** an assumption of independent marking noise or a statistical confidence score.

A correctly identified second transverse line, or a genuine longitudinal endpoint at a known court coordinate different from `y0`, can break this mode. Image-crop endpoints cannot. Even the visible endpoint on far short service does not break the exhibited mode because that line is fixed pointwise.

The physical assumptions are important: the extra observation must belong to the named court marking, and an apparent termination must be physical rather than caused by a player, crop, weak paint or an occluder. A real cropped court showing these same five markings would be equally underdetermined by this evidence. **Rank deficiency is therefore an observability warning, not proof of a false court.** More precise independent camera information could also constrain the mode; the present bounded metric-consistency check does not.

Player observations, floor outcomes, net-depth checks and full generation eligibility were not replayed for these analytical witnesses. The demonstrated ambiguity is specifically in **available paint-sampling geometry plus the recorded camera-error objective**, not in every possible observation.

## 2. Amateur-2: eleven available profiles do not mean eleven distinct spatial observations

### Exact candidate and geometric result

Identity: **`(am2_window_01_frame_28019, automatic_all_camera, 184:4123)`**. Every one of its twelve intervals is available and passing, yielding eleven marking scores equal to one, despite the recorded gross rejection. [S2–S4]

The saved homography places the clipped near baseline only **0.378426–0.452247 working pixels** from the near long-service supporting line across the near baseline's in-image span. These are projected nominal line locations, not a new measurement of physical painted edges.

That separation is much smaller than the existing profile's normal-centre search offsets `[-4, -2, 0, 2, 4]` working pixels. The ridge predicate is local and does not make paint-support ownership exclusive across markings. The geometric audit therefore identifies a concrete opportunity for two expected markings to use nearly the same image neighbourhood. It does not establish which pixel ridge made either profile pass. [S4]

### The saved assignments expose actual identity competition

The detailed saved `stripe` evidence independently exposes the alias:

| Marking | `independent_per_marking` | `exclusive_per_marking` |
|---|---:|---:|
| Near baseline | 0.8077183990 | 6.27 × 10⁻¹⁹ |
| Near long service | 0.8350072396 | 0.8244762207 |
| Centre | 0.2453800454 | 0 |

Two exact entries of `stripe.assignments` are particularly informative:

| Zero-based assignment-array position | Chosen marking / position | Chosen reverse strength | Best alternative marking | Alternative reverse strength |
|---:|---|---:|---|---:|
| 133 | Near long service / negative edge | 0.9971234116 | Near baseline | 0.9733605228 |
| 174 | Near long service / negative edge | 0.8040646855 | Near baseline | 0.6967659000 |

These are **assignment-array positions, not claimed raw-fragment IDs**. Their pixel coordinates and physical object identities were not recovered. The strengths are descriptive responses, not probabilities.

`stripe_observations.resolve_fragments` selects one marking/position pair per fragment using maximum mean **reverse** support. `score_model` then restricts forward coverage to fragments assigned to that identity. Thus the near baseline's high nonexclusive coverage does not survive the recorded assignment, while near long service retains high coverage. [S8]

There is an important limitation: the assignment solves the separable reverse objective. It does **not** jointly optimise forward coverage. These records therefore demonstrate competition under the existing ownership convention, not that every possible exclusive assignment must lose the near baseline. Nor do they prove that the same two fragments supplied the binary pixel-profile passes.

### Comparison with the positive contrary example

Identity: **`(am2_window_00_frame_150, automatic_all_camera, 30:33)`**, the approved paint winner. It has the same complete all-one profile object as the false candidate. [S3–S4]

It also has a genuine contrary result for strict exclusivity: far long-service forward support drops from **0.1979269199** to **2.25 × 10⁻¹⁵** under the recorded assignment. Its predicted far long-service/baseline separation is **1.861547–2.243938 working pixels**, and assignment entries 58 and 84 prefer the far baseline while retaining far long service as their best alternative.

The aggregate independent-to-exclusive forward loss is:

| Exact case / candidate, all `automatic_all_camera` | Relative loss of independent forward support |
|---|---:|
| Amateur-2 frame150 / `30:30` — rejected mat-boundary fit | 7.47% |
| Amateur-2 frame150 / `30:33` — approved paint fit | 5.20% |
| Amateur-2 frame28019 / `16:1800` — rejected line fit | 7.29% |
| Amateur-2 frame28019 / `184:4123` — rejected all-eleven paint fit | 36.13% |

These are newly computed descriptions of **existing** forward fields, not a tuned replacement score. The much larger loss in `184:4123` supports an evidence-reuse diagnosis on this example. The other rejected fits have losses much closer to the positive candidate, so the table does not supply a general separator.

Requiring every marking to survive exclusive assignment would reject the approved `30:33`. A hard minimum image separation could also penalise a valid strongly foreshortened court; below-one-pixel projected spacing is not by itself physical impossibility. The current positive set does not establish a universal resolution cutoff.

The useful distinction is therefore **geometric availability versus separately attributable support**. An all-eleven count can coexist with unresolved marking identity. No new visual attribution to the net, wall or another background object is inferred, and no cause is assigned to apparent line bowing.

## The completed fixed-candidate audit

This extension performs one targeted observable-constraint audit on **nine exact candidates**: the four recovered Amateur-2 winners; scene19's line/paint pair; GX0 observed-bank controls 1864 and 5144; and supplied-direction comparator 89. The last three are distinct control/comparator populations, not additional automatic detections. All 17 distinct automatic compact winner records remain available in the unchanged summary, but the full 19-entry detailed export has not been audited.

| Candidates | Available intervals in geometry replay | Ideal supporting-line rank | Consequence |
|---|---:|---:|---|
| Scene19 false `165:6702` | 5 | 7 | Explicit longitudinal ambiguity |
| Scene19 usable `1:60` | 12 | 8 | This particular ambiguity is absent |
| Four Amateur-2 candidates, including approved `30:33` and false `184:4123` | 12 each | 8 each | Full ideal line rank is not court identity; correspondence quality still matters |
| GX0 observed-bank 1864/5144 and supplied-direction89 | 12 each | 8 each | Existing ideal approvals and floor rejections remain distinct from observability |

All nine also have same-sign, positive corner homogeneous denominators after the chosen normalisation. Since the denominator is affine over the court rectangle, none has a projective pole inside that rectangle. This rules out that particular geometric pathology for these examples; it does not confer usability.

The sampled candidates are not a complete negative population, and rank was evaluated on ideal line identities implied by their geometry, not newly annotated observed line correspondences. A rank-8 result only removes the exhibited structural deficiency under correct correspondence. It does not certify actual support or acceptance.

## What this changes in the evaluation

Without more annotations, the evidence now establishes: the exact geometric reason scene19's available pattern fails to constrain length; a concrete camera-compatible ambiguity witness; specific subpixel overlap and recorded assignment competition in the all-eleven false winner; and positive examples showing why indiscriminate completeness or exclusivity vetoes would be unsafe.

The conclusions requiring additional evidence remain separate. Identifying the actual ridges that passed the profiles needs accessible pixels and a sample-level ownership/contrast replay or visual judgement. Establishing that failed support means physically absent paint requires an observability judgement. Testing a ranking rule requires the relevant fixed full pool and candidate-specific quality judgements. The legacy floor scorer was read, but the complete archived wrapper/settings-to-export trace and all rejected candidates were not established, so no new floor-rejection cause is asserted.

**Candidate availability, ranking and acceptance have not been conflated:** the analytical homographies are not reported as generated alternatives; no winner is replaced; no new acceptance threshold is introduced; and no automatic success or readiness rate is claimed. The varied development views are not independent trials, and none is a designated holdout. The reserved hard videos and fixed independent direction protocol are untouched.

## Reproduction and assets

Run from the extracted handover directory:

```bash
python audit.py --inputs inputs --out results
```

The audit script requires Python 3.10 or newer, NumPy and OpenCV. `python plot_audit.py` regenerates the figure and additionally requires Matplotlib. It reads only bundled frozen evidence, verifies the two compact source blobs, cross-checks four detailed entries, writes the clipping/constraint/assignment audit, and exits on failed self-checks. Numerical reprojection tolerances are implementation checks, not court-quality thresholds.

- `results/audit_results.json`: all new calculations, identities, witnesses, per-interval reasons, assignment examples and self-checks.
- `results/unchanged_automatic_winner_summary.json`: 17 unique compact automatic winners with their unchanged recorded scores and gates.
- `results/scene19_camera_ambiguity.png` and `.svg`: analytical camera-error figure; neither is an image overlay or a new visual court judgement.
- `source_access_manifest.json`: source paths, pinned blobs, scope and access limitations.

### Source key

All paths below are pinned to the revision at the start. Let `E` denote `experiments/annotator/independent_court/recorded/player_guided/projective_patterns/` and `M` denote `experiments/annotator/independent_court/`.

[S1] `E/evaluation/README.md`, ranking/visibility and interpretation sections.

[S2] `E/measurements.json.gz`, `automatic_arms.all_camera` and `extreme_paint_winners`; complete verified archive.

[S3] `E/automatic_axes_visual_judgements.md`; `E/automatic_axes_results.md`; existing judgements only.

[S4] `E/evaluation/method_excerpts.md`: court intervals/mapping, `inspect_appearance.profiles`, `detector._visible_samples`, `detector._filter_painted_stripes`, `run_automatic.winner_ids`.

[S5] `E/evaluation/ranking_records.json.gz`; four completely decoded entries from a partially retrieved archive. Whole archive not verified; compact fields cross-checked.

[S6] `E/gx0_control_measurements.json.gz`; complete verified archive, native dimensions, coordinates and approvals.

[S7] `M/net_geometry.py`, especially `_camera_from_corners`; entire source read.

[S8] `M/stripe_observations.py`, especially `resolve_fragments`, `describe_assignment`, `score_model`; entire source read.

[S9] `M/paint_geometry.py` and relevant `M/detector.py` sections; existing positional hypotheses and ridge sampling definitions.

[S10] `E/images/scene_0019_frame_00040691_cached_view.png`; PNG header only, width/height verified; pixels not accessed.
