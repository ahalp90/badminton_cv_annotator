"""Verify committed bytes, replay the bounded GX0 audit, and validate the bound.

Usage: python verify_audit.py
Only local evidence is read. Outputs go next to this script. No network requests,
repository writes, image extraction, new court optimization or matcher execution.
Requires Python 3.10+ and NumPy.
"""
from pathlib import Path
import base64,gzip,hashlib,json,subprocess,sys,zlib
import numpy as np
from geometry_certificate import edge_bound,axis_bounds,set_bound

ROOT=Path(__file__).resolve().parent
E=ROOT/'evidence'
checks={}
expected={
 'gx0_control_measurements':'4d4da3984eb6b2d61b2aa0e30ab41cc7ab0d8ff5',
 'svd_fixed_measurements':'b16d7b2e0ab0a8a5cd4580474bba6812a77b88d7',
}
for name,sha in expected.items():
    blob=(E/(name+'.json.gz')).read_bytes()
    actual=hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()
    assert actual==sha,(name,actual)
    decoded=json.loads(gzip.decompress(blob))
    assert decoded==json.loads((E/(name+'.json')).read_text())
    checks[name]={'compressed_bytes':len(blob),'git_blob_sha1':actual,'gzip_crc_and_json_match':True}

# The large direction file is a PREFIX, not a full CRC-verified gzip download.
prefix=base64.b64decode((E/'direction_prefix.b64').read_text())
z=zlib.decompressobj(16+zlib.MAX_WBITS)
text=z.decompress(prefix).decode('utf-8')
assert not z.eof
assert text==(E/'direction_prefix.json.partial').read_text()
key='"direction_lines":'
start=text.index(key+'[[')+len(key)
lines,consumed=json.JSONDecoder().raw_decode(text[start:])
assert len(lines)==106
assert lines==json.loads((E/'gx0_lines.json').read_text())
checks['direction_records_prefix']={'compressed_prefix_bytes':len(prefix),'decoded_characters':len(text),'complete_gzip':False,'complete_GX0_line_rows':len(lines)}

for script in ['audit_gx0.py','incidence_certificate.py','audit_saved_sets.py']:
    subprocess.run([sys.executable,str(ROOT/script)],check=True,stdout=subprocess.DEVNULL)
B=np.load(ROOT/'gx0_bank_reconstructed.npz')
S=json.loads((E/'svd_fixed_measurements.json').read_text())
C=json.loads((E/'gx0_control_measurements.json').read_text())
c0=S['cases'][0];idx=B['retained_indices']
assert B['candidate_ids'][idx].tolist()==c0['original_candidate_ids']
working=B['points_normalised']@B['normalised_to_working'].T
assert np.array_equal(working[idx],np.array(c0['original_points_working']))
for i,g in enumerate(c0['refit_groups']):
    assert np.flatnonzero(B['masks'][idx[i]]).tolist()==g['support_line_ids']
for r in C['selected_direction_candidates']:
    j=int(np.flatnonzero(B['candidate_ids']==r['candidate_id'])[0])
    assert np.array_equal(B['points_normalised'][j],np.array(r['point_normalised']))
    assert int(B['counts'][j])==r['support_count']
    assert str(B['status'][j])==r['candidate_status']
checks['GX0_replay']={'minimum_absolute_angle_distance_from_1p5_degree_threshold':float(np.min(np.abs(B['angles_deg']-1.5))),'candidate_count':len(B['candidate_ids']),'all_16_original_ids_exact':True,'all_16_original_working_points_exact':True,'all_16_original_support_masks_exact':True,'both_control_points_counts_statuses_exact':True}

court=np.array([[0,0],[6.10,0],[6.10,13.40],[0,13.40]],np.float32).astype(float)
court=np.c_[court,np.ones(4)]
errs=[];direction_differences=[]
for case in S['cases']:
    target=np.array(case['control_corners_working_px'])
    for arm,key in [('baseline','original_points_working'),('fixed_membership_svd','refit_points_working'),('control_selected_svd','control_selected_points_working')]:
        fit=case['arms'][arm]['best_finite'];p=np.array(case[key]);h=np.array(fit['homography_working'])
        q=court@h.T;q=q[:,:2]/q[:,2:]
        e=float(np.linalg.norm(q-target,axis=1).max())
        assert e==fit['max_corner_working_px']
        lb,_=set_bound(target,p)
        assert lb<=e+1e-10
        for col,g in enumerate(fit['groups']):
            u=p[g]/np.linalg.norm(p[g]);v=h[:,col]/np.linalg.norm(h[:,col])
            difference=float(min(np.max(np.abs(u-v)),np.max(np.abs(u+v))))
            assert difference<1e-12
            direction_differences.append(difference)
        # A 180-degree court relabelling changes neither pair of opposite edges.
        x,y=axis_bounds(target,p);xr,yr=axis_bounds(target[[2,3,0,1]],p)
        assert np.allclose(x,xr,rtol=1e-12,atol=1e-10)
        assert np.allclose(y,yr,rtol=1e-12,atol=1e-10)
        errs.append({'case':case['case_id'],'arm':arm,'saved_error':e,'lower_bound':lb})
checks['saved_fits']={'nine_reprojected_max_corner_errors_exact':True,'all_bounds_below_saved_achieved_errors':True,'maximum_direction_column_difference':max(direction_differences),'180_degree_relabelling_invariance':True,'fits':errs}

# Independent synthetic checks: directly evaluate extremal normals instead of
# using the homogeneous formula; also approximate the full normal-angle search.
rng=np.random.default_rng(20260915)
theta=np.linspace(0,np.pi,200001,endpoint=False)
normals=np.c_[np.cos(theta),np.sin(theta)]
maximum_grid_excess=0.;exact_diffs=[]
for _ in range(80):
    a,b,p=rng.normal(size=(3,2))*4
    r=a-p;s=b-p
    candidates=[]
    for vector in [r+s,r-s]:
        if np.linalg.norm(vector)>1e-14:
            n=np.array([-vector[1],vector[0]])/np.linalg.norm(vector)
            candidates.append(max(abs(n@r),abs(n@s)))
    exact=min(candidates);formula=float(edge_bound(a,b,np.r_[p,1.])[0])
    assert np.isclose(exact,formula,rtol=2e-12,atol=2e-12)
    exact_diffs.append(abs(exact-formula))
    grid=np.maximum(np.abs(normals@r),np.abs(normals@s)).min()
    assert grid>=formula-1e-11
    assert grid-formula<.001
    maximum_grid_excess=max(maximum_grid_excess,float(grid-formula))
    # Coordinate-similarity covariance and homogeneous sign/scale invariance.
    angle=float(rng.uniform(-3,3));rot=np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])
    shift=rng.normal(size=2);scale=float(rng.uniform(.2,10))
    transformed=float(edge_bound(scale*rot@a+shift,scale*rot@b+shift,np.r_[scale*rot@p+shift,1.])[0])
    assert np.isclose(transformed,scale*formula,rtol=1e-10,atol=1e-10)
    for k in [-1e8,-1e-8,1e-8,1e8]:
        assert np.isclose(edge_bound(a,b,k*np.r_[p,1.])[0],formula,rtol=1e-10,atol=1e-10)
    direction=rng.normal(size=2);n=np.array([-direction[1],direction[0]])/np.linalg.norm(direction)
    infinity=abs(n@(a-b))/2
    assert np.isclose(edge_bound(a,b,np.r_[direction,0.])[0],infinity,rtol=1e-11,atol=1e-11)
    assert np.isclose(edge_bound(a,b,np.r_[a,1.])[0],0,atol=1e-11)
checks['synthetic_formula_checks']={'executed':True,'random_seed':20260915,'finite_configurations':80,'normal_angles_per_configuration':len(theta),'maximum_difference_from_explicit_extremal_normals':max(exact_diffs),'maximum_dense_grid_excess':maximum_grid_excess,'tested_infinite_VPs_VP_at_endpoint_scale_sign_and_coordinate_similarity':True}

# The union relaxation is deliberately more permissive than one-per-bucket R.
allocated=np.flatnonzero(np.isin(B['status'],['retained','redundant']))
target=np.array(c0['control_corners_working_px']);lx,ly=axis_bounds(target,working)
bound=max(float(lx[allocated].min()),float(ly[allocated].min()))
assert len(allocated)==542
assert bound>3.503
assert abs(bound-3.5035486225184806)<1e-9
checks['GX0_bucket_union_bound']={'candidate_count':542,'lower_bound_working_pixels':bound,'conservative_rounded_lower_bound':3.503,'not_a_fitted_or_attained_error':True}
(ROOT/'verification_results.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
