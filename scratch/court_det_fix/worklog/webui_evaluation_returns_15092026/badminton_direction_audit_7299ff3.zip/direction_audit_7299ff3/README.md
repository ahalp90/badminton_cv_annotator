# A bounded extension of the direction audit

Repository: `ahalp90/badminton_cv_annotator`  
Branch named by the user: `fix/court-det`  
All repository reads pinned to evidence commit: **`7299ff3`**  
Scientific checkpoint named by the evidence guide: `b90518c`

## Scope and result

This is a read-only analysis of existing evidence. No repository files were edited,
no image or fragment extraction was run, no new real-frame court fit or matcher
search was run, and none of the pending B/M/R/MR experiments was redesigned or run
end-to-end. The original GX0 selector was replayed; a known candidate's residual
rank within its original bucket was evaluated as a bounded survival trace. The
geometric bounds below evaluate saved VP sets analytically, not by fitting courts.

The main new result is that **all 542 candidates in GX0's original allocated
suppression buckets collectively have a fixed-direction maximum-corner-error lower
bound of 3.5035486 working pixels to approved candidate 89**. This even allows
oracle representative selection, ignores one-per-bucket restrictions, and ignores
camera/player gates. Thus the unrefitted R diagnostic cannot recover the saved
bank-control fit's 0.5094558-pixel closeness simply by choosing different candidates
inside those buckets. This does not define usability, predict a generated/ranked
winner, or constrain SVD outputs that leave the original bank.

A second result is a real saved-fit score reversal: the closer GX0 bank-control
pair has *worse* capped-angle scores on both masks of the best original pair. On
the shared support subsets, the closer pair actually scores better. Old-only
merged rows reverse the preference. This identifies a concrete support-dependent
failure, without claiming that those rows are false or that control-selected
memberships are ground truth.

A third result bounds the scope for a better control-fit solver with each of the
three cases' unchanged saved direction sets. It is especially restrictive on GX0
and Amateur-2. GX5 retains a large gap between its lower bound and saved achieved
error, so substantial solver/pair-coupling uncertainty remains there.

## What was actually recovered

Evidence root:
`experiments/annotator/independent_court/recorded/player_guided/projective_patterns/`

Read as text: `evaluation/README.md`, direction/SVD/error portions of
`evaluation/method_excerpts.md`, `followup_status.md` (previous turn), and
`methods.md`. Repository directories supplied blob metadata.

Completely recovered and checked against their Git blob SHA-1:

| File relative to evidence root | Bytes | Git blob SHA-1 |
|---|---:|---|
| `gx0_control_measurements.json.gz` | 1,671 | `4d4da3984eb6b2d61b2aa0e30ab41cc7ab0d8ff5` |
| `svd_fixed_measurements.json.gz` | 12,476 | `b16d7b2e0ab0a8a5cd4580474bba6812a77b88d7` |

The directory reports `evaluation/direction_records.json.gz` as 259,911 bytes,
blob `6de228abbd3ff31abff8779a5b630ea9900865e5`. Only its first **7,200 compressed
bytes** were recovered. That is a valid gzip prefix, not a complete gzip file; its
full Git hash and gzip CRC cannot be verified here. Its 13,443-character decoded
prefix contains the complete **106 GX0 merged-line rows** and settings. These
rows suffice to reconstruct the whole GX0 bank by the exact published construction.

Cross-checks against the independent, complete SVD/control files:

* All 16 original GX0 candidate IDs, working homogeneous points and support masks
  replay exactly.
* Both GX0 control candidate points, support counts and recorded statuses replay
  exactly.
* All nine saved best-fit maximum corner errors (three cases by three SVD-summary
  arms) reproduce exactly from their saved homographies with the source's float32
  metre-corner convention. Their direction columns match the saved group VPs up
  to scale/sign, to maximum component difference 1.11e-16 after normalization.

The complete three-case direction file, full 240-fit-per-arm records, and actual
fragment-to-merged-line memberships/midpoints were **not** recovered. The full SVD
summary contains direction sets and best fits, not every pair-fit record. No
claim about a per-pair regression frequency or every solver failure is made.

## Analytical lower bound

Let `a,b` be finite 2-D target endpoints and `P=(P_x,P_y,w)` a homogeneous VP.
Define

```
ell = cross([a_x,a_y,1], [b_x,b_y,1])
r_a = P[:2] - w*a
r_b = P[:2] - w*b
E(a,b;P) = abs(dot(ell,P)) / max(norm(r_a+r_b), norm(r_a-r_b))
```

`E` is the exact minimum, over image lines through `P`, of the maximum normal
distance of `a` and `b` to that line. For a finite VP `p`, this follows by
minimizing `max(abs(n·(a-p)), abs(n·(b-p)))` over unit line normals `n`. A
minimizing normal is perpendicular to one of `(a-p)+(b-p)` or `(a-p)-(b-p)`;
the smaller resulting value yields the displayed formula. Collinear and
VP-at-endpoint cases give zero. For `w=0`, the line orientation is fixed and the
optimal offset balances the endpoint distances, giving the same formula.

With court corners `[c0,c1,c2,c3] = [FL,FR,NR,NL]`, set

```
Lx(P) = max(E(c0,c1;P), E(c3,c2;P))
Ly(P) = max(E(c0,c3;P), E(c1,c2;P))
```

Every nondegenerate fixed-direction homography with x-VP `U` and y-VP `V` has
maximum corner displacement at least `max(Lx(U),Ly(V))`. Taking the minimum over
an allowed direction set gives a lower bound on its best possible court error.
It relaxes coupling between edges, court metric constraints and gates, so it is
not an achieved optimum. It supports finite/infinite VPs, is homogeneous
scale/sign invariant, and is unchanged by the allowed 180-degree relabelling.
It transforms covariantly with image-coordinate similarities.

This measure explicitly requires the saved target corners. It is **not a
label-free direction-quality objective or a proposed new selector**.

## Results

All errors below are in **960x540 working pixels**, against each case's exact
saved comparator (`control_source` in the source SVD summary). They are not
1280x720 display errors.

| Case | Direction set | Analytical lower bound | Saved achieved maximum error |
|---|---|---:|---:|
| GX0 | Original 16 | 6.022569 | 6.798367 |
| GX0 | Fixed-support SVD 16 | 3.268611 | 3.961121 |
| GX5 | Original 16 | 9.728733 | 23.800169 |
| GX5 | Fixed-support SVD 16 | 10.198761 | 22.502448 |
| Amateur-2 frame28019 | Original 16 | 2.590076 | 2.972162 |
| Amateur-2 frame28019 | Fixed-support SVD 16 | 1.217057 | 1.626036 |

Control-selected SVD alternatives (not ground-truth membership or ceilings):

| Case | Lower bound | Saved achieved error |
|---|---:|---:|
| GX0 | 0.715794 | 0.952369 |
| GX5 | 1.398416 | 2.540327 |
| Amateur-2 | 1.228211 | 1.440552 |

GX5's bound worsens while its saved achieved error improves after SVD. This is
not evidence that the true optimum worsens: the bounds are loose and constrain
only separate-edge incidence. It is a warning not to read every scalar as a
monotone measure of the same geometry.

### GX0 bucket exclusion

The exact replay reconstructs 5,671 candidates: 16 retained, 526 redundant, 5,115
capped, and 14 below-two-lines. The union of allocated buckets has 542 candidates.
Its minimum `Ly` is 3.5035486225 at candidate 854; the next-smallest is 6.0225693108
at candidate 4104. Its minimum `Lx` is 0.0722865936 at candidate 1111. Thus even a
relaxation allowing arbitrary choices anywhere in the union has lower bound
3.5035486225. The conservative rounded statement is **at least 3.503 pixels**.

Candidate 122 (saved bank-control y direction) remains outside the union. It
supports eight rows and its maximum IoU with any leader is 7/9, below the strict
`>0.8` suppression criterion. Its support rows are all covered after the ninth
leader. After 13 leaders all 106 rows are covered; the final three leaders add
zero coverage and win through the count/support tie-breaks. This is representational
loss despite complete observation coverage, not proof that more budget is needed.

Candidate 1183 (saved bank-control x direction) lies in leader 2152's bucket,
with IoU 15/18. On that leader's fixed mask, it ranks 27th of 74: its score is
0.5550153673 versus the leader's 0.4326354958. R cannot choose that exact candidate,
even though allocation made it available. Another representative may improve
geometry, but remains subject to the union bound when used without refitting.

### GX0 saved-fit score reversal

The saved original pair is `(737,4104)` and the saved bank-control pair is
`(1183,122)`. Their saved achieved errors are 6.798367 and 0.509456 respectively.
No new fit was performed.

| Fixed original mask | Original direction score | Bank-control direction score |
|---|---:|---:|
| x: candidate 737 mask, 17 rows | 0.476784605 | 0.506322241 |
| y: candidate 4104 mask, 8 rows | 0.675287308 | 0.742770862 |

Scores are `mean(min(angle_deg,1.5)**2)`, lower preferred. The geometrically
closer pair is worse on both original masks. On the control candidates' own
masks, both preferences reverse. Those masks are not claimed correct.

For x, on the 15 shared rows, summed capped losses are 5.948954 (original) and
4.107478 (control). Original-only rows 31 and 61 add 2.156385 versus 4.5, reversing
the ordering. For y, on the seven shared rows, sums are 5.402298 versus 3.692167;
original-only row 51 adds approximately 0 versus 2.25, again reversing the ordering.
Rows 31 and 51 are intersection-defining rows for original candidates 737 and 4104.
These are zero-based merged-line indices, **not raw fragment IDs**. Nothing here
establishes which row is physically wrong or why: orientation estimation,
anchor location, mixed structures and correspondence remain competing causes.

## Implications for the fixed pending experiments

* Unrefitted R on GX0 cannot obtain diagnostic error below 3.503 to candidate 89
  under the stated bucket contract. A reported smaller error would require
  auditing the target, units, direction preservation, allocation or this bound.
* Unrefitted M or MR below that value must use a y-direction outside the original
  bucket union. This is a specific, testable interpretation of changed allocation.
* SVD may leave the original candidate bank, so the 542-candidate union bound does
  not apply to its new VPs. Its saved 16-point set has its own bound above.
* Improvements, no change and regressions in generated/ranked courts must still
  be separated from these control diagnostics. No new visual judgement is made.

The bounded survival check suggested in the earlier response has now been
executed for GX0. No additional parameter search or new annotations are proposed.
The prescribed provenance replay is still necessary for M/MR. All nine views
remain development data from five videos, without a universal usability threshold,
general kNN gain, end-to-end SVD speedup or acceptance-rule validation.

## Reproduce

Unzip this directory and run:

```sh
python verify_audit.py
```

Requirements: Python 3.10+ and NumPy. No network or repository checkout is needed.
The command validates the two complete gzip blobs, extracts the complete GX0 line
array from the explicitly partial direction stream, regenerates the bank/selection,
checks exact saved-data replay, recomputes all bounds, and runs 80 synthetic formula
checks. The synthetic checks also compare against 200,001 normal angles each,
with random seed 20260915. They validate the formula, not real-frame performance.

Files:

- `geometry_certificate.py`: standalone reusable mathematical bound.
- `audit_gx0.py`: original bank/selector replay, known control survival, saved-fit
  score comparison and row-level decomposition.
- `incidence_certificate.py`: bounds for the original GX0 bank and bucket union.
- `audit_saved_sets.py`: bounds on the nine saved SVD-summary sets and reprojection
  of their saved best homographies.
- `verification_results.json`: executed validation results.
- `gx0_reconstructed_analysis.json`, `gx0_mask_score_decomposition.json`,
  `incidence_certificate_results.json`, `saved_direction_set_certificates.json`:
  full derived numbers and source keys.
- `evidence/`: the two complete small gzip records and their decoded JSON, the
  explicitly partial large-record prefix, and its extracted complete GX0 rows.

All derived results depend on the stated fixed revision and numerical source rows.
The large direction file's full checksum and full bank status arrays were not read;
exact 16-group and 2-control replay are strong independent consistency checks, not
an assertion that the full large blob was downloaded.
