"""Read-only analysis of committed GX0 line rows and saved control fits.
No fragment extraction, midpoint substitution, new court fit or matcher run.
"""
from pathlib import Path
from itertools import combinations
import json
import numpy as np

ROOT=Path(__file__).resolve().parent
lines_work=np.array(json.loads((ROOT/'evidence/gx0_lines.json').read_text()),float)
control=json.loads((ROOT/'evidence/gx0_control_measurements.json').read_text())
width,height=control['working_size']; diagonal=np.hypot(width,height)
T=np.array([[diagonal,0,width/2],[0,diagonal,height/2],[0,0,1.]])
lines=lines_work@T
pairs=np.array(list(combinations(range(len(lines)),2)),int)
raw=np.concatenate([np.cross(lines[pairs[:,0]],lines[pairs[:,1]]),
                    np.column_stack([lines[:,1],-lines[:,0],np.zeros(len(lines))])])
norms=np.linalg.norm(raw,axis=1)
ids=np.flatnonzero(norms>1e-12); points=raw[ids]/norms[ids,None]

def angular_residuals(L,P):
    normals=L[:,:2]
    feet=-L[:,2,None]*normals/np.sum(normals**2,axis=1)[:,None]
    tangents=np.stack((L[:,1],-L[:,0]),axis=1)
    rays=P[:,None,:2]-P[:,None,2:]*feet[None]
    dot=np.abs(np.einsum('pli,li->pl',rays,tangents))
    cross=np.abs(rays[...,0]*tangents[:,1]-rays[...,1]*tangents[:,0])
    angles=np.degrees(np.arctan2(cross,dot))
    return np.where(np.linalg.norm(rays,axis=2)>1e-12,angles,90.)

angles=np.concatenate([angular_residuals(lines,points[k:k+256]) for k in range(0,len(points),256)])
masks=angles<=1.5; counts=masks.sum(axis=1);supports=np.maximum(0,1-angles/1.5).sum(axis=1)
eligible=counts>=2; status=np.where(eligible,'capped','below_two_lines').astype('U16')
covered=np.zeros(len(lines),bool);retained=[];buckets=[];trace=[]
for step in range(16):
    indices=np.flatnonzero(eligible)
    if not len(indices): break
    novelty=(masks[indices]&~covered).sum(axis=1)
    order=np.lexsort((ids[indices],-supports[indices],-counts[indices],-novelty))
    leader=indices[order[0]]
    row={'step':step,'leader_id':int(ids[leader]),'leader_count':int(counts[leader]),
         'leader_novelty':int((masks[leader]&~covered).sum()),'covered_before':int(covered.sum()),
         'control_candidates':[]}
    for cid in [1183,122]:
        k=int(np.flatnonzero(ids==cid)[0])
        row['control_candidates'].append({'id':cid,'eligible':bool(eligible[k]),
             'novelty':int((masks[k]&~covered).sum()),'position_in_current_priority_order':
             int(np.flatnonzero(indices[order]==k)[0])+1 if eligible[k] else None})
    covered|=masks[leader]
    union=(masks[indices]|masks[leader]).sum(axis=1)
    intersection=(masks[indices]&masks[leader]).sum(axis=1)
    bucket=indices[intersection/union>0.8]
    eligible[bucket]=False;status[bucket]='redundant';status[leader]='retained'
    retained.append(int(leader));buckets.append(bucket);trace.append(row)

unit=lambda X:X/np.linalg.norm(X,axis=-1,keepdims=True)
checks={'bank_count':len(points),'degenerate_count':len(raw)-len(points),'control_points':[]}
for r in control['selected_direction_candidates']:
    cid=r['candidate_id']; i=int(np.flatnonzero(ids==cid)[0]); ref=np.array(r['point_normalised'])
    checks['control_points'].append({'id':cid,'point_max_abs_error_up_to_sign':float(min(abs(points[i]-ref).max(),abs(points[i]+ref).max())),
         'count_replay':int(counts[i]),'count_saved':r['support_count'],
         'status_replay':str(status[i]),'status_saved':r['candidate_status']})
H=np.array(control['best_retained_pair_fit']['homography_working'])
for col,g in enumerate(control['best_retained_pair_fit']['pencils']):
    P=unit(points[retained[g]]@T.T); ref=unit(H[:,col])
    checks[f'best_retained_fit_column_{col}_point_error']=float(min(abs(P-ref).max(),abs(P+ref).max()))

results={'checks':checks,'retained_candidate_ids':ids[retained].tolist(),
         'status_counts':{k:int((status==k).sum()) for k in np.unique(status)},'trace':trace,
         'control_survival':[]}
for cid in [1183,122]:
    i=int(np.flatnonzero(ids==cid)[0]); r={'id':cid,'line_pair':pairs[cid].tolist(),'count':int(counts[i]),
       'support_line_ids':np.flatnonzero(masks[i]).tolist(),'support_score':float(supports[i]),'status':str(status[i]),
       'own_mask_mean_square_angle':float(np.mean(angles[i,masks[i]]**2)),
       'own_mask_max_angle':float(angles[i,masks[i]].max()),
       'covered_support_ids_after_16':np.flatnonzero(masks[i]&covered).tolist()}
    matches=[g for g,b in enumerate(buckets) if i in b]
    if matches:
        g=matches[0];lead=retained[g];b=buckets[g];lm=masks[lead]
        scores=np.minimum(angles[b][:,lm],1.5)**2;scores=scores.mean(axis=1)
        order=np.lexsort((ids[b],scores));rank=int(np.flatnonzero(b[order]==i)[0])+1
        r.update(bucket_group=g,leader_id=int(ids[lead]),bucket_size=len(b),
                 leader_count=int(counts[lead]),leader_support_score=float(supports[lead]),
                 residual_rank_on_leader_mask=rank,residual_on_leader_mask=float(scores[b==i][0]),
                 leader_residual_on_leader_mask=float(scores[b==lead][0]),
                 identical_to_leader_mask=bool(np.array_equal(masks[i],lm)),
                 leader_iou=float((masks[i]&lm).sum()/(masks[i]|lm).sum()))
    ious=np.array([(masks[i]&masks[j]).sum()/(masks[i]|masks[j]).sum() for j in retained])
    r['max_iou_to_leaders']=float(ious.max());r['max_iou_leader_ids']=ids[np.array(retained)[ious==ious.max()]].tolist()
    results['control_survival'].append(r)

# Evaluate only the EXISTING saved fits, not a new fit or parameter search.
Ulines=lines/np.linalg.norm(lines[:,:2],axis=1)[:,None]
fit_rows=[]
for fit_key in ['best_retained_pair_fit','best_bank_fit']:
    fit=control[fit_key]; H=np.array(fit['homography_working'])
    vs=unit((np.linalg.inv(T)@H[:,:2]).T)
    row={'fit_key':fit_key,'saved_max_corner_working_px':fit['max_corner_working_px'],
         'directions':[]}
    for col,P in enumerate(vs):
        ar=angular_residuals(lines,P[None])[0]
        ref_id=[1183,122][col];refmask=masks[np.flatnonzero(ids==ref_id)[0]]
        originalmask=masks[retained[control['best_retained_pair_fit']['pencils'][col]]]
        rr={'axis':col,'saved_control_candidate_id':ref_id}
        for label,mask in [('control_candidate_mask',refmask),('best_retained_direction_mask',originalmask)]:
            rr[label]={'line_count':int(mask.sum()),'capped_angle_mean_square':float(np.mean(np.minimum(ar[mask],1.5)**2)),
              'uncapped_angle_mean_square':float(np.mean(ar[mask]**2)),
              'algebraic_rms':float(np.sqrt(np.mean((Ulines[mask]@P)**2)))}
        row['directions'].append(rr)
    fit_rows.append(row)
results['saved_fit_objectives']=fit_rows

# Decompose the score reversal without changing or fitting any support group.
decomposition=[]
for axis,old,new in [('x',737,1183),('y',4104,122)]:
    i=int(np.flatnonzero(ids==old)[0]);j=int(np.flatnonzero(ids==new)[0])
    row={'axis':axis,'old_id':old,'control_id':new,'partitions':[]}
    for name,mask in [('common',masks[i]&masks[j]),('original_only',masks[i]&~masks[j]),('control_only',masks[j]&~masks[i])]:
        rows=np.flatnonzero(mask)
        row['partitions'].append({'name':name,'count':len(rows),'line_ids':rows.tolist(),
          'old_capped_sum':float((np.minimum(angles[i,mask],1.5)**2).sum()),
          'control_capped_sum':float((np.minimum(angles[j,mask],1.5)**2).sum()),
          'lines':[{'merged_line':int(k),'old_angle':float(angles[i,k]),'control_angle':float(angles[j,k]),
            'capped_sq_control_minus_old':float(min(angles[j,k],1.5)**2-min(angles[i,k],1.5)**2)} for k in rows]})
    decomposition.append(row)
(ROOT/'gx0_mask_score_decomposition.json').write_text(json.dumps(decomposition,indent=2))

# Each bit of source masks and covariates can be audited independently.
(ROOT/'gx0_reconstructed_analysis.json').write_text(json.dumps(results,indent=2))
np.savez_compressed(ROOT/'gx0_bank_reconstructed.npz',line_rows=lines_work,normalised_to_working=T,
 candidate_ids=ids,points_normalised=points,angles_deg=angles,masks=masks,counts=counts,supports=supports,
 status=status,retained_indices=retained,covered=covered)
if __name__=='__main__':
    print(json.dumps(results,indent=2))
