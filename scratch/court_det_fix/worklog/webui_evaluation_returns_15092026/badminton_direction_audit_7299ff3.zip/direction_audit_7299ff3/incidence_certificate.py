"""Necessary corner-error bounds for existing candidate VPs; no court optimisation.
An analytic certificate conditional on the saved reference corners, NOT a new
label-free objective, generated court, or matcher/control-fit run.
"""
from pathlib import Path
import numpy as np,json
ROOT=Path(__file__).resolve().parent
B=np.load(ROOT/'gx0_bank_reconstructed.npz')
C=json.loads((ROOT/'evidence/gx0_control_measurements.json').read_text())
points=B['points_normalised']@B['normalised_to_working'].T
ids=B['candidate_ids'];ret=B['retained_indices'];status=B['status']
corners=np.array(C['approved_corners_native_px'])/2.


def edge_bound(a,b,points):
    """Exact min over lines through VP of max endpoint normal displacement.
    Homogeneous scale/sign invariant, and finite/infinite VPs supported.
    """
    points=np.atleast_2d(points)
    line=np.cross(np.r_[a,1.],np.r_[b,1.])
    ra=points[:,:2]-points[:,2:]*a
    rb=points[:,:2]-points[:,2:]*b
    denom=np.maximum(np.linalg.norm(ra+rb,axis=1),np.linalg.norm(ra-rb,axis=1))
    return np.abs(points@line)/denom

ex=np.column_stack([edge_bound(corners[0],corners[1],points),edge_bound(corners[3],corners[2],points)])
ey=np.column_stack([edge_bound(corners[0],corners[3],points),edge_bound(corners[1],corners[2],points)])
lx=ex.max(axis=1);ly=ey.max(axis=1)
records=[]
for group,idx in enumerate(ret):
    records.append({'group':int(group),'candidate_id':int(ids[idx]),'Lx':float(lx[idx]),'Ly':float(ly[idx])})
# Relaxation ignores all constraints except separate incidence at each edge.
# Taking minima gives a valid lower bound, not a fit or an achieved optimum.
bestx=int(ret[np.argmin(lx[ret])]);besty=int(ret[np.argmin(ly[ret])])
out={'units':'960x540 working pixels','reference':'approved candidate89',
     'retained_direction_bounds':records,
     'retained_set_lower_bound':max(float(lx[bestx]),float(ly[besty])),
     'best_axis_bound_ids':[int(ids[bestx]),int(ids[besty])],
     'saved_fit_comparisons':[]}
for key,cids in [('best_retained_pair_fit',[737,4104]),('best_bank_fit',[1183,122])]:
    ii=[int(np.flatnonzero(ids==cid)[0]) for cid in cids]
    fit=C[key];H=np.array(fit['homography_working'])
    court=np.array([[0,0,1],[6.10,0,1],[6.10,13.40,1],[0,13.40,1]])
    projected=court@H.T; projected=projected[:,:2]/projected[:,2:]
    dist=np.linalg.norm(projected-corners,axis=1)
    # Also reproduce the float32 court convention used in the actual source.
    court32=court.astype(np.float32).astype(float);q=court32@H.T;q=q[:,:2]/q[:,2:]
    out['saved_fit_comparisons'].append({'key':key,'candidate_ids':cids,
      'Lx':float(lx[ii[0]]),'Ly':float(ly[ii[1]]),'bound':max(float(lx[ii[0]]),float(ly[ii[1]])),
      'saved_max_corner_working_px':fit['max_corner_working_px'],
      'recomputed_max_from_saved_H_float32_court':float(np.linalg.norm(q-corners,axis=1).max()),
      'corner_errors_exact_metre_input':dist.tolist()})
# Broad, optimistic relaxation over already allocated buckets. It ignores one
# representative per bucket, residual preference and distinct-pair constraints.
allocated=np.flatnonzero(np.isin(status,['retained','redundant']))
ax=int(allocated[np.argmin(lx[allocated])]);ay=int(allocated[np.argmin(ly[allocated])])
out['allocated_union_optimistic_lower_bound']={
 'candidate_count':len(allocated),'min_Lx':float(lx[ax]),'min_Ly':float(ly[ay]),
 'bound':max(float(lx[ax]),float(ly[ay])),'minimising_axis_ids':[int(ids[ax]),int(ids[ay])]}
# How a named capped candidate can be genuinely distinct even from its closest mask.
for cid in [1183,122,2152,4104]:
 i=int(np.flatnonzero(ids==cid)[0]);out.setdefault('named_candidates',[]).append(
 {'id':cid,'Lx':float(lx[i]),'Ly':float(ly[i]),'x_edge_bounds':ex[i].tolist(),'y_edge_bounds':ey[i].tolist()})
(ROOT/'incidence_certificate_results.json').write_text(json.dumps(out,indent=2))
np.savez_compressed(ROOT/'incidence_bounds.npz',candidate_ids=ids,Lx=lx,Ly=ly,x_edges=ex,y_edges=ey)
print(json.dumps(out,indent=2))
