"""Analytic evaluation of saved SVD-summary direction sets and saved homographies.
No new court fit is performed; every reported achieved error comes from a
committed fit, independently reprojected with the source's float32 metre corners.
"""
from pathlib import Path
import json,itertools
import numpy as np
ROOT=Path(__file__).resolve().parent
S=json.loads((ROOT/'evidence/svd_fixed_measurements.json').read_text())

def edge_bound(a,b,points):
    P=np.atleast_2d(points)
    ell=np.cross(np.r_[a,1.],np.r_[b,1.])
    ra=P[:,:2]-P[:,2:]*a; rb=P[:,:2]-P[:,2:]*b
    den=np.maximum(np.linalg.norm(ra+rb,axis=1),np.linalg.norm(ra-rb,axis=1))
    return np.abs(P@ell)/den

def bounds(C,P):
    ex=np.column_stack([edge_bound(C[0],C[1],P),edge_bound(C[3],C[2],P)])
    ey=np.column_stack([edge_bound(C[0],C[3],P),edge_bound(C[1],C[2],P)])
    return ex.max(axis=1),ey.max(axis=1)

out={'source_revision':'7299ff3','units':'960x540 working pixels','cases':[]}
court=np.array([[0,0],[6.10,0],[6.10,13.40],[0,13.40]],dtype=np.float32).astype(float)
court=np.c_[court,np.ones(4)]
for c in S['cases']:
    C=np.array(c['control_corners_working_px']);row={'case_id':c['case_id'],'control_source':c['control_source'],'sets':[]}
    for arm,pointkey in [('baseline','original_points_working'),('fixed_membership_svd','refit_points_working'),('control_selected_svd','control_selected_points_working')]:
        P=np.array(c[pointkey]);lx,ly=bounds(C,P);perm=np.array(list(itertools.permutations(range(len(P)),2)))
        pairlb=np.maximum(lx[perm[:,0]],ly[perm[:,1]]);idx=int(np.argmin(pairlb));lower=float(pairlb[idx]);best=c['arms'][arm]['best_finite']
        h=np.array(best['homography_working']);Q=court@h.T;Q=Q[:,:2]/Q[:,2:];err=np.linalg.norm(Q-C,axis=1)
        r={'arm':arm,'direction_count':len(P),'set_corner_error_lower_bound':lower,
           'bound_minimising_groups':perm[idx].tolist(),'saved_best_groups':best['groups'],
           'saved_best_corner_error':best['max_corner_working_px'],
           'recomputed_saved_error':float(err.max()),'reprojection_error_difference':float(err.max()-best['max_corner_working_px']),
           'saved_best_converged':best['converged'],
           'possible_improvement_below_saved_best_at_most':float(best['max_corner_working_px']-lower),
           'per_direction_bounds':[{'group':i,'Lx':float(x),'Ly':float(y)} for i,(x,y) in enumerate(zip(lx,ly))]}
        row['sets'].append(r)
    row['previous_bank_fit']=c['previous_best_bank_fit']
    out['cases'].append(row)
out['validation_saved']=S['validation']
(ROOT/'saved_direction_set_certificates.json').write_text(json.dumps(out,indent=2))
for r in out['cases']:
 print(r['case_id'])
 for x in r['sets']:
  print(x['arm'], 'LB',x['set_corner_error_lower_bound'],'saved',x['saved_best_corner_error'],
        'bound groups',x['bound_minimising_groups'],'saved groups',x['saved_best_groups'],
        'error check',x['reprojection_error_difference'])
print('validation',S['validation'])
